import json
import logging
import requests
from config import Config
from database.db import get_db_connection

logger = logging.getLogger("CampusAgentAI")

def retrieve_grounded_context_from_db(query):
    """
    Retrieves real records from SQLite database to ground AI responses
    and prevent AI hallucination or fabricated opportunities.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    q = query.lower()
    items = []
    
    if any(k in q for k in ["internship", "job", "stipend"]):
        cursor.execute("SELECT title, organization, stipend_or_reward, deadline, eligibility FROM opportunities WHERE category = 'Internships' AND is_expired = 0 LIMIT 4")
        items = [dict(r) for r in cursor.fetchall()]
    elif any(k in q for k in ["scholarship", "epass", "vidya"]):
        cursor.execute("SELECT title, organization, stipend_or_reward, deadline, eligibility FROM opportunities WHERE category = 'Scholarships' AND is_expired = 0 LIMIT 4")
        items = [dict(r) for r in cursor.fetchall()]
    elif any(k in q for k in ["hackathon", "event", "contest", "saturday"]):
        cursor.execute("SELECT title, organization, location, deadline, eligibility FROM opportunities WHERE category IN ('Hackathons', 'Events') AND is_expired = 0 LIMIT 4")
        items = [dict(r) for r in cursor.fetchall()]
    elif any(k in q for k in ["placement", "package", "cbit", "vnr"]):
        cursor.execute("SELECT college_name, highest_package_lpa, average_package_lpa, placement_rate_pct FROM college_placements LIMIT 3")
        items = [dict(r) for r in cursor.fetchall()]
    else:
        cursor.execute("SELECT title, organization, category, deadline FROM opportunities WHERE is_expired = 0 LIMIT 3")
        items = [dict(r) for r in cursor.fetchall()]

    conn.close()
    return items

def generate_ai_response(user_input, language="en", context=None):
    """
    Centralized Multilingual AI Agent Response Generator.
    Supports English, Telugu (తెలుగు), and Hindi (हिन्दी).
    Grounds output with real SQLite opportunities data.
    """
    if not user_input or not user_input.strip():
        return "Please ask a question regarding internships, scholarships, hackathons, college placements, or programming notes."

    db_context = retrieve_grounded_context_from_db(user_input)
    context_str = json.dumps(db_context, indent=2) if db_context else "No active matching records."

    system_prompt = (
        f"You are the AI Campus Opportunity Agent, an expert student career assistant.\n"
        f"Selected Language: {language.upper()} (en: English, te: Telugu - తెలుగు, hi: Hindi - हिन्दी).\n"
        f"STRICT RULES:\n"
        f"1. Respond ONLY in the selected language ({language}). Use authentic native script for Telugu and Hindi.\n"
        f"2. Base all opportunity and college information ONLY on this verified database context:\n{context_str}\n"
        f"3. NEVER fabricate or invent opportunities, scholarships, or deadlines.\n"
        f"4. If answering programming questions (Python, Java, C), provide concise, crystal-clear code snippets.\n"
        f"5. Maintain an encouraging, professional, and student-friendly tone."
    )

    # Attempt OpenRouter API if key is present
    if Config.OPENROUTER_API_KEY:
        try:
            payload = {
                "model": Config.OPENROUTER_MODEL,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ],
                "temperature": 0.4,
                "max_tokens": 700
            }
            headers = {
                "Authorization": f"Bearer {Config.OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "http://localhost:5000",
                "X-Title": "AI Campus Opportunity Agent"
            }
            resp = requests.post(
                f"{Config.OPENROUTER_BASE_URL}/chat/completions",
                headers=headers,
                json=payload,
                timeout=12
            )
            if resp.status_code == 200:
                res_data = resp.json()
                ai_text = res_data["choices"][0]["message"]["content"].strip()
                return ai_text
        except Exception as e:
            logger.warning(f"OpenRouter API request failed: {e}. Utilizing deterministic grounded fallback.")

    # High-Quality Grounded Deterministic Fallback
    q = user_input.lower()
    
    if language == "te":
        if any(w in q for w in ["internship", "ఇంటర్న్‌షిప్", "జాబ్"]):
            opp_list = "\n".join([f"• **{item['title']}** ({item['organization']}) - స్టైపెండ్: {item.get('stipend_or_reward', 'లభిస్తుంది')}, గడువు: {item.get('deadline')}" for item in db_context[:3]])
            return f"నమస్కారం! మీ ప్రొఫైల్ మరియు డేటాబేస్ ఆధారంగా ప్రస్తుతం అందుబాటులో ఉన్న ముఖ్యమైన ఇంటర్న్‌షిప్‌లు:\n\n{opp_list}\n\nమరిన్ని వివరాల కోసం డాష్‌బోర్డ్‌లోని Apply బటన్‌ను క్లిక్ చేయండి."
        elif any(w in q for w in ["scholarship", "స్కాలర్‌షిప్", "epass", "ఫీజు"]):
            return f"తెలంగాణ మరియు జాతీయ స్థాయిలో ప్రస్తుతం **Telangana ePASS RTF/MTF**, **Dr. B.R. Ambedkar Overseas Vidya Nidhi**, మరియు **Vidyadhan Scholarship** దరఖాస్తులు అందుబాటులో ఉన్నాయి. పూర్తి అర్హత వివరాలు స్కాలర్‌షిప్స్ విభాగంలో చూడవచ్చు."
        elif any(w in q for w in ["python", "పైథాన్", "జావా", "java", "c program"]):
            return f"ప్రోగ్రామింగ్ నేర్చుకోవడానికి మా 'Learn Programming' విభాగంలో Python, Java, మరియు C నోట్స్ అందుబాటులో ఉన్నాయి. మీరు ఏ అంశంపై సందేహాలు ఉన్నా అడగవచ్చు!"
        else:
            return f"నమస్కారం! నేను మీ AI క్యాంపస్ కెరీర్ అడ్వైజర్‌ని. ఇంటర్న్‌షిప్‌లు, స్కాలర్‌షిప్‌లు, హ్యాకథాన్‌లు, కాలేజీ ప్లేస్‌మెంట్స్ మరియు ప్రోగ్రామింగ్ నోట్స్ గురించి మీకు సహాయం చేయడానికి సిద్ధంగా ఉన్నాను."

    elif language == "hi":
        if any(w in q for w in ["internship", "इंटरर्नशिप", "नौकरी"]):
            opp_list = "\n".join([f"• **{item['title']}** ({item['organization']}) - स्टाइपेंड: {item.get('stipend_or_reward', 'उपलब्ध')}, अंतिम तिथि: {item.get('deadline')}" for item in db_context[:3]])
            return f"नमस्ते! आपके प्रोफाइल के आधार पर वर्तमान में उपलब्ध सत्यापित इंटर्नशिप अवसर:\n\n{opp_list}\n\nआवेदन करने के लिए डैशबोर्ड में अवसर कार्ड पर जाएं।"
        elif any(w in q for w in ["scholarship", "छात्रवृत्ति", "epass"]):
            return f"वर्तमान में **Telangana ePASS**, **Ambedkar Overseas Vidya Nidhi**, और **Reliance Foundation Scholarship** के आवेदन सक्रिय हैं। विवरण छात्रवृत्ति सेक्शन में देखें।"
        elif any(w in q for w in ["python", "पायथन", "java", "जावा", "c "]):
            return f"प्रोग्रामिंग सीखने के लिए 'Learn Programming' सेक्शन में Python, Java और C के नोट्स उपलब्ध हैं। आप किसी भी विषय पर प्रश्न पूछ सकते हैं!"
        else:
            return f"नमस्ते! मैं आपका AI कैंपस करियर असिस्टेंट हूं। इंटर्नशिप, स्कॉलरशिप, कॉलेज प्लेसमेंट और प्रोग्रामिंग नोट्स में आपकी सहायता के लिए तैयार हूं।"

    else:  # English
        if any(w in q for w in ["internship", "job", "stipend"]):
            opp_list = "\n".join([f"• **{item['title']}** at **{item['organization']}** (Stipend: {item.get('stipend_or_reward', 'Provided')}, Deadline: {item.get('deadline')})" for item in db_context[:3]])
            return f"Hello! Based on our verified live database, here are current top matching internships for you:\n\n{opp_list}\n\nYou can review eligibility and submit your application with 1-click on your dashboard."
        elif any(w in q for w in ["scholarship", "epass", "grant", "fee"]):
            return f"Active verified scholarships include **Telangana ePASS RTF & MTF Fee Reimbursement**, **Ambedkar Overseas Vidya Nidhi**, and **Reliance Foundation UG Scholarship**. Deadlines and criteria are updated in the Scholarships tab."
        elif any(w in q for w in ["python", "java", "c ", "pointer", "loop", "oop"]):
            return f"Explore our dedicated **Learn Programming** studio for complete chapters, cheatsheets, and top placement interview questions across Python, Java, and C Programming."
        else:
            return f"Hello! I am your AI Campus Opportunity Assistant. Ask me anything about live internships, Telangana scholarships, Saturday hackathons, college placements, or Python/Java/C learning roadmaps."
