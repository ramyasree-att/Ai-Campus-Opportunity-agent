import re

def calculate_personalized_match(opportunity, student_profile):
    """
    Computes a personalized opportunity match score (0 - 100) and
    generates tailored 'Why this matches you' explanations in English, Telugu, or Hindi.
    """
    if not student_profile:
        return {
            "match_score": 60,
            "match_label": "ELIGIBLE",
            "reasons": ["Open to all undergraduate students", "Verified opportunity"],
            "reasons_te": ["అండర్ గ్రాడ్యుయేట్ విద్యార్థులందరికీ అందుబాటులో ఉంది", "ధృవీకరించబడిన అవకాశం"],
            "reasons_hi": ["सभी स्नातक छात्रों के लिए खुला है", "सत्यापित अवसर"]
        }

    score = 40  # Base eligible score
    reasons_en = []
    reasons_te = []
    reasons_hi = []

    # Student Data
    student_branch = (student_profile.get("branch") or "").lower()
    student_course = (student_profile.get("course") or "b.tech").lower()
    student_year = (student_profile.get("academic_year") or "").lower()
    student_skills = [s.lower() for s in (student_profile.get("skills") or [])]
    student_langs = [l.lower() for l in (student_profile.get("programming_languages") or [])]
    all_student_skills = set(student_skills + student_langs)
    student_goal = (student_profile.get("career_goal") or "").lower()

    # Opportunity Data
    opp_title = (opportunity.get("title") or "").lower()
    opp_desc = (opportunity.get("description") or "").lower()
    opp_eligibility = (opportunity.get("eligibility") or "").lower()
    opp_req_skills_raw = (opportunity.get("required_skills") or "").lower()
    opp_skills = [s.strip() for s in re.split(r"[,;/]+", opp_req_skills_raw) if s.strip()]
    opp_mode = (opportunity.get("mode") or opportunity.get("work_mode") or "Online").lower()
    opp_category = (opportunity.get("category") or "").lower()

    # 1. Branch & Course Relevance (+20 pts)
    matched_branch = False
    if "cse" in student_branch or "computer" in student_branch or "information" in student_branch or "it" in student_branch:
        if any(k in opp_desc + opp_eligibility for k in ["cse", "it", "software", "computer", "coding", "developer"]):
            score += 20
            matched_branch = True
            reasons_en.append(f"Directly matches your {student_profile.get('branch', 'Engineering')} background")
            reasons_te.append(f"మీ {student_profile.get('branch', 'ఇంజనీరింగ్')} విభాగానికి సరిగ్గా సరిపోతుంది")
            reasons_hi.append(f"आपकी {student_profile.get('branch', 'इंजीनियरिंग')} स्ट्रीम के लिए बिल्कुल उपयुक्त है")
    elif "pharm" in student_branch:
        if any(k in opp_desc + opp_eligibility for k in ["pharm", "clinical", "health", "biotech"]):
            score += 25
            matched_branch = True
            reasons_en.append("Custom-curated for Pharmacy & Healthcare students")
            reasons_te.append("ఫార్మసీ మరియు హెల్త్‌కేర్ విద్యార్థుల కోసం ప్రత్యేకంగా సరిపోతుంది")
            reasons_hi.append("फार्मेसी और हेल्थकेयर छात्रों के लिए विशेष रूप से उपयुक्त है")
    else:
        score += 10

    # 2. Skill Overlap (+25 pts)
    matched_skills = []
    for skill in opp_skills:
        for s_skill in all_student_skills:
            if s_skill in skill or skill in s_skill:
                matched_skills.append(skill.title())
                break

    if matched_skills:
        skill_boost = min(len(matched_skills) * 8, 25)
        score += skill_boost
        skills_preview = ", ".join(matched_skills[:3])
        reasons_en.append(f"Matches your verified skills: {skills_preview}")
        reasons_te.append(f"మీ ధృవీకరించబడిన స్కిల్స్ తో సరిపోలుతుంది: {skills_preview}")
        reasons_hi.append(f"आपके सत्यापित कौशल से मेल खाता है: {skills_preview}")

    # 3. Career Goal & Interests (+10 pts)
    if student_goal and any(w in opp_title + opp_desc for w in student_goal.split()):
        score += 10
        reasons_en.append(f"Aligned with your career goal: {student_profile.get('career_goal')}")
        reasons_te.append(f"మీ కెరీర్ లక్ష్యమైన '{student_profile.get('career_goal')}' కు అనుకూలంగా ఉంది")
        reasons_hi.append(f"आपके करियर लक्ष्य '{student_profile.get('career_goal')}' के अनुकूल है")

    # 4. Work Mode / Location (+5 pts)
    if "remote" in opp_mode or "online" in opp_mode:
        score += 5
        reasons_en.append("Remote / Online work mode available")
        reasons_te.append("రిమోట్ / ఆన్‌లైన్ వర్క్ మోడ్ అందుబాటులో ఉంది")
        reasons_hi.append("रिमोट / ऑनलाइन वर्क मोड उपलब्ध है")

    # Cap score between 35 and 98
    final_score = min(max(score, 35), 98)

    if final_score >= 80:
        match_label = "HIGHLY RECOMMENDED 🌟"
    elif final_score >= 60:
        match_label = "ELIGIBLE MATCH ✅"
    else:
        match_label = "PARTIALLY MATCHED ⚠️"

    if not reasons_en:
        reasons_en = ["Meets general educational eligibility criteria", "Verified opportunity"]
        reasons_te = ["సాధారణ విద్యార్హత ప్రమాణాలను కలిగి ఉంది", "ధృవీకరించబడిన అవకాశం"]
        reasons_hi = ["सामान्य शैक्षिक पात्रता मानदंडों को पूरा करता है", "सत्यापित अवसर"]

    lang = student_profile.get("preferred_language", "en")
    active_reasons = reasons_te if lang == "te" else (reasons_hi if lang == "hi" else reasons_en)

    return {
        "match_score": final_score,
        "match_label": match_label,
        "reasons": active_reasons,
        "reasons_en": reasons_en,
        "reasons_te": reasons_te,
        "reasons_hi": reasons_hi,
        "matched_skills": matched_skills
    }
