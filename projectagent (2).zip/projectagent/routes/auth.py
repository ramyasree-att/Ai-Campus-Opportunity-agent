"""
Authentication routes including Google OAuth 2.0 and profile authentication.
"""
from flask import Blueprint, request, jsonify, session, redirect, url_for
from auth.google_oauth import get_google_auth_url, handle_google_callback, is_google_oauth_configured

auth_bp = Blueprint("auth_bp", __name__)

@auth_bp.route("/auth/google/url", methods=["GET"])
def google_auth_url():
    url = get_google_auth_url()
    return jsonify({
        "success": bool(url),
        "configured": is_google_oauth_configured(),
        "url": url,
        "message": "Google OAuth authorization URL generated." if url else "Google OAuth is not configured with client credentials."
    })

@auth_bp.route("/auth/google", methods=["GET"])
def google_auth_redirect():
    url = get_google_auth_url()
    if url:
        return redirect(url)
    return redirect("/?error=google_oauth_unconfigured")

@auth_bp.route("/auth/google/callback", methods=["GET"])
def google_callback():
    code = request.args.get("code")
    if not code:
        error = request.args.get("error", "missing_code")
        return redirect(f"/?error={error}")

    result = handle_google_callback(code)
    if result.get("success"):
        session["user_id"] = result["user"]["id"]
        return redirect("/?auth=success")
    else:
        return redirect(f"/?error={result.get('message', 'oauth_failed')}")
