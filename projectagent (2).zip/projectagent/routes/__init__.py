"""
Routes package for Campus Opportunity Agent.
"""
from flask import Blueprint

admin_bp = Blueprint("admin_bp", __name__, url_prefix="/api/admin")

from routes.admin import *
