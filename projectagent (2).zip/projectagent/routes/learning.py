"""
Learning notes, cheatsheets, and interactive programming curricula routes.
"""
from flask import Blueprint, request, jsonify
from learning import ALL_LANGUAGES, get_notes_for_language, search_notes
from services.learning_service import generate_7day_learning_plan

learning_bp = Blueprint("learning_bp", __name__, url_prefix="/api/learning")

@learning_bp.route("/languages", methods=["GET"])
def get_languages():
    langs = []
    for k, v in ALL_LANGUAGES.items():
        langs.append({
            "key": k,
            "language": v["language"],
            "icon": v["icon"],
            "tagline": v["tagline"],
            "topic_count": len(v["topics"])
        })
    return jsonify({"success": True, "languages": langs})

@learning_bp.route("/notes/<language>", methods=["GET"])
def get_language_notes(language):
    notes = get_notes_for_language(language)
    if not notes:
        return jsonify({"success": False, "message": f"Notes for '{language}' not found. Available: python, java, c."}), 404
    return jsonify({"success": True, "data": notes})

@learning_bp.route("/search", methods=["GET"])
def search_learning_notes():
    query = request.args.get("q", "").strip()
    lang = request.args.get("lang")
    if not query:
        return jsonify({"success": True, "results": []})
    results = search_notes(query, lang)
    return jsonify({"success": True, "count": len(results), "results": results})

@learning_bp.route("/plan", methods=["POST"])
def generate_custom_plan():
    data = request.get_json() or {}
    skill = data.get("skill", "Python")
    goal = data.get("goal", "Full-Stack Development")
    plan = generate_7day_learning_plan(skill, goal)
    return jsonify({"success": True, "plan": plan})
