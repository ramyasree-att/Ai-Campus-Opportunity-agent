"""
Admin Dashboard & System Management API routes.
Provides role-protected endpoints for User Management, Telangana Colleges,
Opportunity Moderation, Crawler Controls, Interval Configuration, and Automation Logs.
"""
from functools import wraps
from datetime import datetime
from flask import request, jsonify, session
from database.db import get_db_connection
from automation.scheduler import run_all_collectors_cycle
from automation.deadline_checker import update_expired_deadlines
from routes import admin_bp

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = session.get("user_id")
        if not user_id:
            return jsonify({"success": False, "message": "Authentication required."}), 401
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        conn.close()

        if not user or user["role"] != "ADMIN":
            return jsonify({"success": False, "message": "Admin privileges required to access this resource."}), 403
            
        return f(*args, **kwargs)
    return decorated_function

# ----------------- ADMIN DASHBOARD OVERVIEW STATS -----------------
@admin_bp.route("/stats", methods=["GET"])
@admin_required
def admin_stats():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) AS total_users FROM users")
    total_users = cursor.fetchone()["total_users"]

    cursor.execute("SELECT COUNT(*) AS total_colleges FROM colleges")
    total_colleges = cursor.fetchone()["total_colleges"]

    cursor.execute("SELECT COUNT(*) AS total_opps, status FROM opportunities GROUP BY status")
    opp_stats = {row["status"]: row["total_opps"] for row in cursor.fetchall()}

    cursor.execute("SELECT COUNT(*) AS total_apps FROM applications")
    total_apps = cursor.fetchone()["total_apps"]

    try:
        cursor.execute("SELECT * FROM automation_logs ORDER BY id DESC LIMIT 10")
        crawler_runs = [dict(r) for r in cursor.fetchall()]
    except Exception:
        crawler_runs = []

    conn.close()

    return jsonify({
        "success": True,
        "stats": {
            "total_users": total_users,
            "total_colleges": total_colleges,
            "opportunities": opp_stats,
            "total_applications": total_apps
        },
        "recent_crawler_runs": crawler_runs
    })

# ----------------- USER MANAGEMENT -----------------
@admin_bp.route("/users", methods=["GET"])
@admin_required
def admin_list_users():
    search = request.args.get("search", "").strip()
    role_filter = request.args.get("role", "")
    
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        SELECT u.id, u.email, u.role,
               p.name AS full_name, p.college_name, p.branch, p.academic_year, p.cgpa, p.contact_number
        FROM users u
        LEFT JOIN profiles p ON u.id = p.user_id
        WHERE 1=1
    """
    params = []

    if search:
        query += " AND (u.email LIKE ? OR p.name LIKE ? OR p.college_name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])
    if role_filter:
        query += " AND u.role = ?"
        params.append(role_filter)

    query += " ORDER BY u.id DESC"
    cursor.execute(query, params)
    users = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return jsonify({"success": True, "count": len(users), "users": users})

@admin_bp.route("/users/<int:user_id>/role", methods=["POST"])
@admin_required
def admin_update_user_role(user_id):
    data = request.get_json() or {}
    new_role = data.get("role")
    if new_role not in ["USER", "ADMIN", "MODERATOR"]:
        return jsonify({"success": False, "message": "Invalid role. Allowed: USER, ADMIN, MODERATOR."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"User #{user_id} role updated to {new_role}."})

@admin_bp.route("/users/<int:user_id>/toggle-status", methods=["POST"])
@admin_required
def admin_toggle_user_status(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    u = cursor.fetchone()
    if not u:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    current_status = u["is_active"] if "is_active" in u.keys() and u["is_active"] is not None else 1
    new_status = 0 if current_status == 1 else 1
    cursor.execute("UPDATE users SET is_active = ? WHERE id = ?", (new_status, user_id))
    conn.commit()
    conn.close()

    status_str = "Active" if new_status == 1 else "Suspended"
    return jsonify({"success": True, "message": f"User #{user_id} account status changed to {status_str}.", "is_active": new_status})

# ----------------- TELANGANA COLLEGES MANAGEMENT -----------------
@admin_bp.route("/colleges", methods=["GET"])
@admin_required
def admin_list_colleges():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT *, name AS college_name FROM colleges ORDER BY nirf_rank ASC, name ASC")
    colleges = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return jsonify({"success": True, "count": len(colleges), "colleges": colleges})

@admin_bp.route("/colleges", methods=["POST"])
@admin_required
def admin_create_college():
    data = request.get_json() or {}
    name = (data.get("college_name") or data.get("name") or "").strip()
    if not name:
        return jsonify({"success": False, "message": "College name is required."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO colleges (
            name, code, location, district, nirf_rank, website_url,
            average_package_lpa, highest_package_lpa, placement_rate_pct
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            name,
            data.get("code") or data.get("short_code"),
            data.get("location") or data.get("city", "Hyderabad"),
            data.get("district", "Hyderabad"),
            data.get("nirf_rank"),
            data.get("website_url"),
            data.get("average_package_lpa") or data.get("avg_package_lpa", 6.5),
            data.get("highest_package_lpa", 32.0),
            data.get("placement_rate_pct") or data.get("placement_percentage", 85)
        )
    )
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"College '{name}' created successfully.", "college_id": new_id})

@admin_bp.route("/colleges/<int:college_id>", methods=["PUT", "PATCH"])
@admin_required
def admin_update_college(college_id):
    data = request.get_json() or {}
    name = data.get("name") or data.get("college_name")
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE colleges
        SET name = COALESCE(?, name),
            code = COALESCE(?, code),
            location = COALESCE(?, location),
            nirf_rank = COALESCE(?, nirf_rank),
            website_url = COALESCE(?, website_url),
            average_package_lpa = COALESCE(?, average_package_lpa),
            highest_package_lpa = COALESCE(?, highest_package_lpa),
            placement_rate_pct = COALESCE(?, placement_rate_pct)
        WHERE id = ?
        """,
        (
            name,
            data.get("code"),
            data.get("location"),
            data.get("nirf_rank"),
            data.get("website_url"),
            data.get("average_package_lpa"),
            data.get("highest_package_lpa"),
            data.get("placement_rate_pct"),
            college_id
        )
    )
    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": f"College #{college_id} updated successfully."})

@admin_bp.route("/colleges/<int:college_id>", methods=["DELETE"])
@admin_required
def admin_delete_college(college_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM colleges WHERE id = ?", (college_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": f"College #{college_id} deleted successfully."})

# ----------------- OPPORTUNITIES MODERATION -----------------
@admin_bp.route("/opportunities", methods=["GET"])
@admin_required
def admin_list_opportunities():
    category = request.args.get("category", "")
    status = request.args.get("status", "")
    search = request.args.get("search", "").strip()

    conn = get_db_connection()
    cursor = conn.cursor()

    query = "SELECT *, organization AS company, source AS source_name FROM opportunities WHERE 1=1"
    params = []

    if category and category != "all":
        query += " AND category = ?"
        params.append(category)
    if status and status != "all":
        query += " AND status = ?"
        params.append(status)
    if search:
        query += " AND (title LIKE ? OR organization LIKE ? OR source LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])

    query += " ORDER BY id DESC"
    cursor.execute(query, params)
    opps = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return jsonify({"success": True, "count": len(opps), "opportunities": opps})

@admin_bp.route("/opportunities", methods=["POST"])
@admin_required
def admin_create_opportunity():
    data = request.get_json() or {}
    title = (data.get("title") or "").strip()
    company = (data.get("company") or data.get("organization") or "").strip()

    if not title or not company:
        return jsonify({"success": False, "message": "Title and company are required."}), 400

    from automation.deduplication import generate_opportunity_hash
    opp_hash = generate_opportunity_hash(title, company, data.get("source_url", ""), data.get("deadline", ""))

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO opportunities (
            hash, title, organization, category, description,
            eligibility, required_skills, location, mode, deadline,
            stipend_or_reward, application_url, source, verification_status, status, is_expired
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Verified ✅', ?, 0)
        """,
        (
            opp_hash,
            title,
            company,
            data.get("category", "Internships"),
            data.get("description", ""),
            data.get("eligibility", "All branches eligible"),
            data.get("required_skills", "Python, SQL"),
            data.get("location", "Hyderabad / Remote"),
            data.get("mode", "Remote"),
            data.get("deadline"),
            data.get("stipend", "Competitive"),
            data.get("application_url", "https://campusagent.org/apply"),
            data.get("source_name", "Admin Manual Entry"),
            data.get("status", "ACTIVE")
        )
    )
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"Opportunity '{title}' added successfully.", "id": new_id})

@admin_bp.route("/opportunities/<int:opp_id>/status", methods=["POST"])
@admin_required
def admin_update_opp_status(opp_id):
    data = request.get_json() or {}
    new_status = data.get("status")
    if new_status not in ["ACTIVE", "EXPIRING_SOON", "EXPIRED", "CLOSED", "UNVERIFIED"]:
        return jsonify({"success": False, "message": "Invalid status."}), 400

    is_expired_val = 1 if new_status in ["EXPIRED", "CLOSED"] else 0
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE opportunities SET status = ?, is_expired = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (new_status, is_expired_val, opp_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"Opportunity #{opp_id} status updated to {new_status}."})

@admin_bp.route("/opportunities/<int:opp_id>", methods=["DELETE"])
@admin_required
def admin_delete_opportunity(opp_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM opportunities WHERE id = ?", (opp_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": f"Opportunity #{opp_id} deleted successfully."})

# ----------------- AUTOMATION & COLLECTOR CONTROLS -----------------
@admin_bp.route("/automation/trigger", methods=["POST"])
@admin_required
def admin_trigger_crawler():
    results = run_all_collectors_cycle()
    update_expired_deadlines()
    return jsonify({"success": True, "message": "Manual data collection and deadline cycle completed.", "results": results})

@admin_bp.route("/automation/intervals", methods=["GET"])
@admin_required
def admin_get_intervals():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT setting_key, setting_value, description FROM admin_settings WHERE setting_key LIKE '%interval%'")
    settings = {r["setting_key"]: {"value": r["setting_value"], "description": r["description"]} for r in cursor.fetchall()}
    conn.close()
    return jsonify({"success": True, "intervals": settings})

@admin_bp.route("/automation/intervals", methods=["POST"])
@admin_required
def admin_update_interval():
    data = request.get_json() or {}
    key = data.get("key")
    value = str(data.get("value", ""))

    if not key or not value:
        return jsonify({"success": False, "message": "Setting key and value are required."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE admin_settings SET setting_value = ?, updated_at = CURRENT_TIMESTAMP WHERE setting_key = ?",
        (value, key)
    )
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": f"Scheduler interval '{key}' updated to {value}."})

@admin_bp.route("/sources", methods=["GET"])
@admin_required
def admin_get_sources():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT *, source_type AS category FROM source_registry ORDER BY source_type ASC, source_name ASC")
    sources = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return jsonify({"success": True, "count": len(sources), "sources": sources})

@admin_bp.route("/sources/<int:source_id>/toggle", methods=["POST"])
@admin_required
def admin_toggle_source(source_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT is_enabled, source_name FROM source_registry WHERE id = ?", (source_id,))
    s = cursor.fetchone()
    if not s:
        conn.close()
        return jsonify({"success": False, "message": "Source not found."}), 404

    new_val = 0 if s["is_enabled"] == 1 else 1
    cursor.execute("UPDATE source_registry SET is_enabled = ? WHERE id = ?", (new_val, source_id))
    conn.commit()
    conn.close()

    status_str = "Enabled" if new_val == 1 else "Disabled"
    return jsonify({"success": True, "message": f"Source '{s['source_name']}' is now {status_str}.", "is_enabled": new_val})

# ----------------- SYSTEM LOGS & AUDIT -----------------
@admin_bp.route("/logs", methods=["GET"])
@admin_required
def admin_get_logs():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM automation_logs ORDER BY id DESC LIMIT 50")
        crawler_logs = [dict(r) for r in cursor.fetchall()]
    except Exception:
        crawler_logs = []

    conn.close()

    return jsonify({
        "success": True,
        "crawler_logs": crawler_logs,
        "audit_logs": []
    })
