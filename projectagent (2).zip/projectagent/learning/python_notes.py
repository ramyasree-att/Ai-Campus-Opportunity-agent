"""
Python Programming Complete Study Notes & Placement Prep.
Contains 17 comprehensive chapters with syntax explanations, code examples, and placement interview questions.
"""

PYTHON_OVERVIEW = """Python is a dynamically typed, interpreted, high-level programming language created by Guido van Rossum in 1991. 
Renowned for its clean syntax, rapid development capabilities, and vast ecosystem, Python powers Artificial Intelligence, Machine Learning, Data Science, Web Development (Django, Flask, FastAPI), Automation, and Cloud Infrastructure. 
It is one of the most widely tested programming languages in technical interviews and campus placements across India."""

PYTHON_CHEATSHEET = [
    {"command": "print(f'Hello, {name}!')", "desc": "Formatted string literal (f-string interpolation)"},
    {"command": "nums = [x**2 for x in range(10) if x % 2 == 0]", "desc": "List comprehension with filtering"},
    {"command": "with open('data.txt', 'r') as f:\n    content = f.read()", "desc": "Safe context manager for file I/O"},
    {"command": "sq = lambda x: x * x", "desc": "Anonymous one-line lambda function"},
    {"command": "merged = {**dict_a, **dict_b}", "desc": "Dictionary unpacking and merging"},
    {"command": "a, *b, c = [1, 2, 3, 4, 5]", "desc": "Extended iterable unpacking (b becomes [2, 3, 4])"},
    {"command": "isinstance(obj, (int, float))", "desc": "Type check against multiple valid classes"},
    {"command": "import json; data = json.loads(json_str)", "desc": "Parse JSON string to Python dictionary"}
]

PYTHON_TOPICS = [
    {
        "id": "py_01_intro_setup",
        "title": "1. Python Introduction & Environment Setup",
        "content": """### 1.1 What is Python?
Python is an interpreted, high-level, dynamically typed language emphasizing code readability and simplicity.

### 1.2 Installation & Virtual Environments
- Install Python 3.10+ from python.org
- Create a virtual environment to isolate project dependencies:
```bash
python -m venv venv
# Activate on Windows:
venv\\Scripts\\activate
# Activate on Linux/macOS:
source venv/bin/activate
```
- Install and manage packages:
```bash
pip install requests flask
pip freeze > requirements.txt
```
### 1.3 Interactive REPL vs Script Execution
```python
# Script execution: python main.py
print("Hello, Campus Agent!")
```"""
    },
    {
        "id": "py_02_variables_datatypes_operators",
        "title": "2. Variables, Data Types & Operators",
        "content": """### 2.1 Core Built-in Data Types
- **Numeric**: `int` (arbitrary precision), `float` (64-bit IEEE 754), `complex` (`3 + 4j`)
- **Boolean**: `True`, `False`
- **Sequences**: `str`, `list`, `tuple`, `range`
- **Mappings**: `dict`
- **Sets**: `set`, `frozenset`
- **NoneType**: `None`

### 2.2 Operators
- Arithmetic: `+`, `-`, `*`, `/`, `//` (floor division), `%`, `**` (exponent)
- Comparison: `==`, `!=`, `<`, `>`, `<=`, `>=`
- Logical: `and`, `or`, `not`
- Identity & Membership: `is`, `is not`, `in`, `not in`

```python
x = 17 // 5  # 3 (integer floor)
y = 17 % 5   # 2 (remainder)
z = 2 ** 8   # 256 (power)

skills = ["Python", "SQL"]
print("Python" in skills)  # True
```"""
    },
    {
        "id": "py_03_control_flow",
        "title": "3. Control Flow (Conditionals & Loops)",
        "content": """### 3.1 If-Elif-Else & Ternary Operator
```python
score = 88
if score >= 90:
    grade = "A"
elif score >= 75:
    grade = "B"
else:
    grade = "C"

# Ternary expression
status = "Eligible" if score >= 70 else "Not Eligible"
```

### 3.2 Loops & Loop Control
```python
# For loop with enumerate and zip
companies = ["Google", "Microsoft", "Amazon"]
stipends = [100000, 90000, 85000]

for idx, (comp, stip) in enumerate(zip(companies, stipends), start=1):
    print(f"{idx}. {comp} pays ₹{stip}/mo")

# While loop with break/continue/else
count = 0
while count < 3:
    count += 1
else:
    print("Loop finished without break")
```"""
    },
    {
        "id": "py_04_functions_lambdas",
        "title": "4. Functions & Lambda Expressions",
        "content": """### 4.1 Function Definition, Default Parameters & *args/**kwargs
```python
def calculate_match(student_name, *skills, base_score=50, **meta):
    total = base_score + len(skills) * 10
    print(f"Candidate: {student_name}, Metadata: {meta}")
    return min(100, total)

score = calculate_match("Srija", "Python", "Flask", "SQL", year=2026, college="CBIT")
```

### 4.2 Lambdas and Higher-Order Functions
```python
# Lambda
multiply = lambda a, b: a * b

# map, filter, sorted with key
numbers = [1, 2, 3, 4, 5, 6]
evens = list(filter(lambda x: x % 2 == 0, numbers))
doubled = list(map(lambda x: x * 2, numbers))

students = [{"name": "A", "cgpa": 8.5}, {"name": "B", "cgpa": 9.2}]
sorted_students = sorted(students, key=lambda s: s["cgpa"], reverse=True)
```"""
    },
    {
        "id": "py_05_data_structures",
        "title": "5. Data Structures: Lists, Tuples, Sets & Dictionaries",
        "content": """### 5.1 Lists (Mutable, Ordered)
```python
lst = [10, 20, 30]
lst.append(40)
lst.insert(1, 15)
lst.pop()
lst.sort(reverse=True)
```

### 5.2 Tuples (Immutable, Ordered)
```python
coord = (17.3850, 78.4867)  # Hyderabad coordinates
lat, lon = coord  # Unpacking
```

### 5.3 Sets (Unique, Unordered)
```python
student_skills = {"Python", "SQL", "Git"}
job_requirements = {"SQL", "AWS", "Docker", "Python"}

matched = student_skills.intersection(job_requirements)
missing = job_requirements.difference(student_skills)
```

### 5.4 Dictionaries (Key-Value Pairs)
```python
profile = {"name": "Ravi", "branch": "CSE", "year": 3}
profile["college"] = "VNR VJIET"
branch = profile.get("branch", "Unknown")

for key, value in profile.items():
    print(f"{key} -> {value}")
```"""
    },
    {
        "id": "py_06_strings_methods",
        "title": "6. Strings & String Manipulation Methods",
        "content": """### 6.1 Immutability & Slicing
```python
s = "CampusOpportunityAgent"
reversed_s = s[::-1]
prefix = s[:6]  # "Campus"
```

### 6.2 Essential String Methods
```python
text = "  Hyderabad, Telangana  "
clean = text.strip()  # "Hyderabad, Telangana"
city, state = clean.split(", ")

words = ["Learn", "Python", "Fast"]
sentence = " ".join(words)

is_num = "12345".isdigit()
is_alpha = "Python".isalpha()
```"""
    },
    {
        "id": "py_07_file_io_context_managers",
        "title": "7. File I/O & Context Managers",
        "content": """### 7.1 Reading and Writing Files
```python
# Writing
with open("students.txt", "w", encoding="utf-8") as f:
    f.write("Srija,CSE,8.9\n")
    f.write("Rahul,ECE,8.4\n")

# Reading lines safely
with open("students.txt", "r", encoding="utf-8") as f:
    for line in f:
        name, branch, cgpa = line.strip().split(",")
        print(f"Student {name} from {branch} has CGPA {cgpa}")
```

### 7.2 Custom Context Managers
```python
from contextlib import contextmanager
import time

@contextmanager
def timer(label):
    start = time.time()
    yield
    print(f"{label} took {time.time() - start:.4f}s")

with timer("Opportunity Match Engine"):
    sum(range(1000000))
```"""
    },
    {
        "id": "py_08_oop",
        "title": "8. Object-Oriented Programming (OOP) in Python",
        "content": """### 8.1 Classes, Objects, __init__ & Dunder Methods
```python
class Opportunity:
    def __init__(self, title: str, company: str, stipend: int):
        self.title = title
        self.company = company
        self._stipend = stipend  # Protected attribute

    def __str__(self):
        return f"{self.title} at {self.company} (₹{self._stipend}/mo)"

    def __eq__(self, other):
        return self.title == other.title and self.company == other.company

# Inheritance & super()
class TechInternship(Opportunity):
    def __init__(self, title: str, company: str, stipend: int, tech_stack: list):
        super().__init__(title, company, stipend)
        self.tech_stack = tech_stack

    def get_details(self):
        return f"{self.title} @ {self.company} | Skills: {', '.join(self.tech_stack)}"

opp = TechInternship("SDE Intern", "Google", 120000, ["Python", "Algorithms"])
print(opp.get_details())
```"""
    },
    {
        "id": "py_09_exception_handling",
        "title": "9. Exception Handling (Try / Except / Else / Finally)",
        "content": """### 9.1 Exception Architecture
```python
try:
    num = int("123a")
except ValueError as e:
    print(f"Conversion error: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")
else:
    print("Executed if no exception occurred")
finally:
    print("Always executed (resource cleanup)")
```

### 9.2 Custom Exceptions
```python
class DeadlineExpiredError(Exception):
    def __init__(self, opp_name, deadline):
        super().__init__(f"Opportunity '{opp_name}' expired on {deadline}")
```"""
    },
    {
        "id": "py_10_modules_packages_venv",
        "title": "10. Modules, Packages & Virtual Environments",
        "content": """### 10.1 Structuring Packages
```
my_agent/
│── __init__.py
│── models.py
│── collectors/
│   │── __init__.py
│   └── scraper.py
```
- `__name__ == '__main__'` pattern for executable modules.
- Relative imports (`from .scraper import BaseScraper`)."""
    },
    {
        "id": "py_11_iterators_generators_decorators",
        "title": "11. Iterators, Generators & Decorators",
        "content": """### 11.1 Generators & Yield (Memory-Efficient)
```python
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

for val in fibonacci(8):
    print(val, end=" ")  # 0 1 1 2 3 5 8 13
```

### 11.2 Decorators (Function Wrappers)
```python
from functools import wraps

def require_auth(func):
    @wraps(func)
    def wrapper(user, *args, **kwargs):
        if not user.get("is_authenticated"):
            raise PermissionError("User is not logged in!")
        return func(user, *args, **kwargs)
    return wrapper

@require_auth
def view_dashboard(user):
    return f"Welcome, {user['name']}"
```"""
    },
    {
        "id": "py_12_comprehensions_functional",
        "title": "12. List Comprehensions & Functional Tools",
        "content": """### 12.1 Comprehensions (List, Set, Dict)
```python
# List comprehension
squares = [x**2 for x in range(10) if x % 2 == 0]

# Dict comprehension
skills = ["Python", "Java", "C++"]
skill_lens = {s: len(s) for s in skills}

# Set comprehension
unique_branches = {s["branch"].upper() for s in students_data}
```

### 12.2 functools & itertools
```python
from functools import reduce
total_stipend = reduce(lambda acc, x: acc + x, [50000, 60000, 75000], 0)

from itertools import chain, combinations
all_tags = list(chain(["AI", "ML"], ["Backend", "DevOps"]))
```"""
    },
    {
        "id": "py_13_regex",
        "title": "13. Regular Expressions (re module)",
        "content": r"""### 13.1 Pattern Matching & Extraction
```python
import re

text = "Contact support@campusagent.org or 9876543210 for deadline alerts."

# Email extraction
email = re.search(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", text).group(0)

# Phone number
phone = re.search(r"\b[6-9]\d{9}\b", text).group(0)

# Substitution & cleanup
cleaned = re.sub(r"[^\w\s]", "", text)
```"""
    },
    {
        "id": "py_14_json_csv_apis",
        "title": "14. Working with JSON, CSV & REST APIs (requests)",
        "content": """### 14.1 JSON Serialization & Deserialization
```python
import json

data = {"user": "Srija", "role": "STUDENT", "score": 95}
json_str = json.dumps(data, indent=2)
parsed = json.loads(json_str)
```

### 14.2 HTTP Requests with `requests`
```python
import requests

response = requests.get("https://api.github.com/users/octocat", timeout=10)
if response.status_code == 200:
    user_info = response.json()
    print("User Name:", user_info["name"])
```"""
    },
    {
        "id": "py_15_concurrency",
        "title": "15. Multithreading & Multiprocessing",
        "content": """### 15.1 ThreadPoolExecutor vs ProcessPoolExecutor
- **Multithreading**: Ideal for I/O-bound tasks (web scraping, API calls, file downloads).
- **Multiprocessing**: Ideal for CPU-bound tasks (data processing, ML inference, mathematical computations).

```python
from concurrent.futures import ThreadPoolExecutor

urls = ["https://site1.com", "https://site2.com", "https://site3.com"]

def fetch_url(url):
    return requests.get(url, timeout=5).status_code

with ThreadPoolExecutor(max_workers=3) as executor:
    results = list(executor.map(fetch_url, urls))
```"""
    },
    {
        "id": "py_16_databases_sqlite",
        "title": "16. Databases with SQLite & SQLAlchemy",
        "content": """### 16.1 Native SQLite in Python
```python
import sqlite3

conn = sqlite3.connect("campus_agent.db")
cursor = conn.cursor()

# Parameterized query to prevent SQL Injection
cursor.execute("SELECT id, title, company FROM opportunities WHERE status = ?", ("ACTIVE",))
rows = cursor.fetchall()
for r in rows:
    print(r)

conn.close()
```"""
    },
    {
        "id": "py_17_interview_problems",
        "title": "17. Top 30 Placement Interview Coding Problems & Solutions",
        "content": """### Problem 1: Two Sum (LeetCode #1)
Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`.
```python
def two_sum(nums, target):
    seen = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in seen:
            return [seen[complement], i]
        seen[num] = i
    return []
# Time Complexity: O(n), Space Complexity: O(n)
```

### Problem 2: Reverse a Linked List
```python
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def reverse_list(head):
    prev = None
    curr = head
    while curr:
        nxt = curr.next
        curr.next = prev
        prev = curr
        curr = nxt
    return prev
```

### Problem 3: Valid Parentheses (Stack)
```python
def is_valid(s: str) -> bool:
    stack = []
    mapping = {")": "(", "}": "{", "]": "["}
    for char in s:
        if char in mapping:
            top = stack.pop() if stack else '#'
            if mapping[char] != top:
                return False
        else:
            stack.append(char)
    return not stack
```

### Problem 4: Longest Substring Without Repeating Characters
```python
def length_of_longest_substring(s: str) -> int:
    char_map = {}
    max_len = 0
    start = 0
    for end, ch in enumerate(s):
        if ch in char_map and char_map[ch] >= start:
            start = char_map[ch] + 1
        char_map[ch] = end
        max_len = max(max_len, end - start + 1)
    return max_len
```

### Problem 5: Group Anagrams
```python
from collections import defaultdict

def group_anagrams(strs):
    ans = defaultdict(list)
    for s in strs:
        ans[tuple(sorted(s))].append(s)
    return list(ans.values())
```"""
    }
]
