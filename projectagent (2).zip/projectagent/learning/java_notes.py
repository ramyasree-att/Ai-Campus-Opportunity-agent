"""
Java Programming Complete Study Notes & Placement Prep.
Contains 20 comprehensive chapters with JVM architecture, OOP concepts, Streams API, Spring Boot basics, and top interview questions.
"""

JAVA_OVERVIEW = """Java is a class-based, object-oriented, strictly typed language designed by James Gosling at Sun Microsystems in 1995. 
With its 'Write Once, Run Anywhere' (WORA) philosophy powered by the Java Virtual Machine (JVM), Java is the industry standard for large-scale enterprise backends, Android application development, banking systems, and microservices architecture."""

JAVA_CHEATSHEET = [
    {"command": "public static void main(String[] args)", "desc": "Java application entry point method signature"},
    {"command": "List<String> list = new ArrayList<>();", "desc": "Instantiate generic dynamic array list"},
    {"command": "list.stream().filter(s -> s.startsWith(\"A\")).collect(Collectors.toList());", "desc": "Java 8 Streams filter and collect"},
    {"command": "try (BufferedReader br = new BufferedReader(new FileReader(\"file.txt\"))) { ... }", "desc": "Try-with-resources automatic closing"},
    {"command": "Map<String, Integer> map = new HashMap<>(); map.put(\"key\", 100);", "desc": "Create and insert key-value pair in HashMap"},
    {"command": "@Override public String toString() { return ...; }", "desc": "Override default Object string representation"},
    {"command": "Optional.ofNullable(user).map(User::getName).orElse(\"Guest\");", "desc": "Null-safe value extraction using Optional"}
]

JAVA_TOPICS = [
    {
        "id": "java_01_jvm_architecture",
        "title": "1. Java Introduction & JVM/JRE/JDK Architecture",
        "content": """### 1.1 JDK vs JRE vs JVM
- **JDK (Java Development Kit)**: Complete development environment with compiler (`javac`), archiver (`jar`), and JRE.
- **JRE (Java Runtime Environment)**: Provides libraries (`rt.jar`) and JVM to run compiled `.class` bytecode files.
- **JVM (Java Virtual Machine)**: Abstract machine that executes bytecode. It contains:
  - ClassLoader (Loading, Linking, Initialization)
  - Memory Areas (Heap, Stack, Method Area, PC Registers, Native Method Stack)
  - Execution Engine (Interpreter, JIT Compiler, Garbage Collector)

```java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Welcome to Java Campus Prep!");
    }
}
```"""
    },
    {
        "id": "java_02_datatypes_operators",
        "title": "2. Variables, Data Types & Operators",
        "content": """### 2.1 Primitive Data Types (8 types)
- `byte` (8-bit), `short` (16-bit), `int` (32-bit), `long` (64-bit with `L` suffix)
- `float` (32-bit with `f`), `double` (64-bit)
- `char` (16-bit Unicode), `boolean` (`true`/`false`)

### 2.2 Autoboxing & Unboxing
Automatic conversion between primitive types and their corresponding Wrapper classes (`int` <-> `Integer`).

```java
int a = 10;
Integer boxed = a; // Autoboxing
int unboxed = boxed; // Unboxing
```"""
    },
    {
        "id": "java_03_control_statements",
        "title": "3. Control Statements & Loops",
        "content": """### 3.1 Switch Statements & Enhanced Switch (Java 14+)
```java
int day = 3;
String dayName = switch (day) {
    case 1 -> "Monday";
    case 2 -> "Tuesday";
    case 3 -> "Wednesday";
    default -> "Weekend";
};
```

### 3.2 Loops (for, while, do-while, enhanced for-each)
```java
String[] skills = {"Java", "Spring", "SQL"};
for (String skill : skills) {
    System.out.println("Required skill: " + skill);
}
```"""
    },
    {
        "id": "java_04_oop_principles",
        "title": "4. Object-Oriented Programming (OOP) Principles",
        "content": """### 4.1 Four Pillars of OOP
1. **Encapsulation**: Bundling data and methods; keeping fields `private` and exposing public getters/setters.
2. **Inheritance**: Code reuse via `extends` keyword.
3. **Polymorphism**: Compile-time (Method Overloading) and Runtime (Method Overriding with dynamic method dispatch).
4. **Abstraction**: Hiding internal implementation details using `abstract` classes and `interface`.

```java
class Student {
    private String name;
    private double cgpa;

    public Student(String name, double cgpa) {
        this.name = name;
        this.cgpa = cgpa;
    }

    public String getName() { return name; }
    public double getCgpa() { return cgpa; }
}
```"""
    },
    {
        "id": "java_05_constructors_super_this",
        "title": "5. Constructors & this / super Keywords",
        "content": """### 5.1 Constructor Chaining & `super()`
- `this()` invokes another constructor in the same class.
- `super()` invokes the parent constructor; MUST be the first statement in a constructor.

```java
class PlacementDrive {
    String company;
    int minCgpa;

    public PlacementDrive(String company) {
        this(company, 7); // Constructor chaining
    }

    public PlacementDrive(String company, int minCgpa) {
        this.company = company;
        this.minCgpa = minCgpa;
    }
}
```"""
    },
    {
        "id": "java_06_interfaces_abstract_classes",
        "title": "6. Interfaces & Abstract Classes",
        "content": """### 6.1 Differences & Default Methods (Java 8+)
- Abstract classes can have state (instance variables) and constructors.
- Interfaces achieve 100% abstract contract and allow multiple interface inheritance (`implements A, B`).
- Java 8 introduced `default` and `static` methods in interfaces.

```java
public interface NotificationSender {
    void sendNotification(String recipient, String message);

    default void logAlert(String msg) {
        System.out.println("[AUDIT LOG] " + msg);
    }
}
```"""
    },
    {
        "id": "java_07_packages_access_modifiers",
        "title": "7. Packages & Access Modifiers",
        "content": """### 7.1 Access Modifier Matrix
| Modifier | Same Class | Same Package | Subclass (Other Pkg) | World |
|---|---|---|---|---|
| `private` | Yes | No | No | No |
| `default` | Yes | Yes | No | No |
| `protected`| Yes | Yes | Yes | No |
| `public` | Yes | Yes | Yes | Yes |"""
    },
    {
        "id": "java_08_exception_handling",
        "title": "8. Exception Handling & Custom Exceptions",
        "content": """### 8.1 Checked vs Unchecked Exceptions
- **Checked (Compile-time)**: Inherit from `Exception` (e.g. `IOException`, `SQLException`).
- **Unchecked (Runtime)**: Inherit from `RuntimeException` (e.g. `NullPointerException`, `ArrayIndexOutOfBoundsException`).

```java
public class OpportunityNotFoundException extends RuntimeException {
    public OpportunityNotFoundException(String message) {
        super(message);
    }
}
```"""
    },
    {
        "id": "java_09_strings_stringbuilder",
        "title": "9. String, StringBuilder & StringBuffer",
        "content": """### 9.1 String Constant Pool (SCP) & Immutability
`String` is immutable in Java for security, thread-safety, and caching in the SCP.
- `StringBuilder`: Mutable and high performance (not thread-safe).
- `StringBuffer`: Mutable and thread-safe (`synchronized` methods).

```java
StringBuilder sb = new StringBuilder();
sb.append("Telangana").append(" Campus").append(" Portal");
String result = sb.toString();
```"""
    },
    {
        "id": "java_10_collections_framework",
        "title": "10. Java Collections Framework (JCF)",
        "content": """### 10.1 Hierarchy Overview
- **List**: `ArrayList` (fast random access), `LinkedList` (fast insertions/deletions).
- **Set**: `HashSet` (O(1) lookups, un-ordered), `TreeSet` (Red-Black tree, sorted O(log n)), `LinkedHashSet` (insertion order).
- **Map**: `HashMap` (key-value hash table), `TreeMap` (sorted keys), `ConcurrentHashMap` (thread-safe bucket locks).
- **Queue**: `PriorityQueue`, `ArrayDeque`.

```java
Map<String, Integer> stipendMap = new HashMap<>();
stipendMap.put("Google", 120000);
stipendMap.put("Microsoft", 100000);

stipendMap.forEach((company, stipend) -> {
    System.out.println(company + " -> ₹" + stipend);
});
```"""
    },
    {
        "id": "java_11_generics",
        "title": "11. Generics & Type Safety",
        "content": """### 11.1 Generic Classes & Wildcards (`? extends T`, `? super T`)
```java
public class MatchResult<T> {
    private T item;
    private double score;

    public MatchResult(T item, double score) {
        this.item = item;
        this.score = score;
    }
    public T getItem() { return item; }
    public double getScore() { return score; }
}
```"""
    },
    {
        "id": "java_12_multithreading",
        "title": "12. Multithreading & Concurrency",
        "content": """### 12.1 Thread Creation & ExecutorService
```java
import java.util.concurrent.*;

public class CollectorThreadPool {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        
        executor.submit(() -> {
            System.out.println("Running background internship scanner...");
        });
        
        executor.shutdown();
    }
}
```"""
    },
    {
        "id": "java_13_file_io_serialization",
        "title": "13. File I/O & Object Serialization",
        "content": """### 13.1 Java NIO & Files API (Modern I/O)
```java
import java.nio.file.*;
import java.io.IOException;

public class FileUtil {
    public static void readFile() throws IOException {
        Path path = Paths.get("data.txt");
        Files.lines(path).forEach(System.out::println);
    }
}
```"""
    },
    {
        "id": "java_14_java8_streams_lambdas",
        "title": "14. Java 8+ Features: Lambdas, Streams & Optional",
        "content": """### 14.1 Streams API (Filter, Map, Reduce, Collect)
```java
List<String> colleges = List.of("CBIT", "VNR VJIET", "JNTUH", "OU CE");

List<String> filtered = colleges.stream()
    .filter(c -> c.startsWith("V") || c.startsWith("C"))
    .map(String::toUpperCase)
    .sorted()
    .toList();
```"""
    },
    {
        "id": "java_15_gc_memory",
        "title": "15. Memory Management & Garbage Collection",
        "content": """### 15.1 Young Gen, Old Gen & Metaspace
- **Eden Space & Survivor Spaces (S0, S1)**: Short-lived objects (Minor GC).
- **Tenured (Old Gen)**: Long-lived objects (Major / Full GC).
- Modern GCs: G1GC (Garbage-First), ZGC (Ultra-low latency sub-millisecond pauses)."""
    },
    {
        "id": "java_16_jdbc",
        "title": "16. JDBC & Database Connectivity",
        "content": """### 16.1 PreparedStatement & Connection Pooling
```java
import java.sql.*;

public class DBClient {
    public static void queryOpportunities() throws SQLException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:campus_agent.db");
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM opportunities WHERE status = ?")) {
            ps.setString(1, "ACTIVE");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("title"));
            }
        }
    }
}
```"""
    },
    {
        "id": "java_17_design_patterns",
        "title": "17. Core Java Design Patterns",
        "content": """### 17.1 Singleton & Factory Patterns
```java
// Thread-safe Bill Pugh Singleton Pattern
public class DBConnectionManager {
    private DBConnectionManager() {}
    private static class Helper {
        private static final DBConnectionManager INSTANCE = new DBConnectionManager();
    }
    public static DBConnectionManager getInstance() {
        return Helper.INSTANCE;
    }
}
```"""
    },
    {
        "id": "java_18_spring_boot_basics",
        "title": "18. Spring Boot Basics & RESTful APIs",
        "content": """### 18.1 Spring Boot REST Controller
```java
@RestController
@RequestMapping("/api/v1/opportunities")
public class OpportunityController {

    @GetMapping("/active")
    public ResponseEntity<List<Opportunity>> getActiveOpportunities() {
        return ResponseEntity.ok(opportunityService.fetchActive());
    }
}
```"""
    },
    {
        "id": "java_19_junit5_testing",
        "title": "19. Unit Testing with JUnit 5 & Mockito",
        "content": """### 19.1 Writing Test Assertions
```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RecommendationEngineTest {
    @Test
    void testScoreComputation() {
        int score = calculateMatch(List.of("Java", "SQL"), List.of("Java", "SQL", "Spring"));
        assertTrue(score >= 70);
    }
}
```"""
    },
    {
        "id": "java_20_interview_questions",
        "title": "20. Top 30 Java Placement Interview Questions & Answers",
        "content": """### Q1: Why is Java not purely object-oriented?
Because it supports 8 primitive data types (`int`, `char`, `float`, etc.) which are not objects.

### Q2: What is the contract between `equals()` and `hashCode()`?
If two objects are equal according to `equals(Object)`, they MUST have the same integer `hashCode()`. However, if two objects have the same hashcode, they are not necessarily equal.

### Q3: Difference between `HashMap` and `ConcurrentHashMap`?
`HashMap` is non-synchronized and not thread-safe. `ConcurrentHashMap` uses segment-level locking (bucket level locks in Java 8) and does not lock the whole map during writes.

### Q4: What happens if an exception occurs in a `try` block before reaching `finally`?
The `finally` block ALWAYS executes, even if an unhandled exception or return statement is encountered (unless `System.exit(0)` is called)."""
    }
]
