"""
Learning Module for Campus Opportunity Agent.
Provides complete structured chapters, code examples, cheatsheets, and interview prep
for Python (17 topics), Java (20 topics), and C (16 topics).
"""
from learning.python_notes import PYTHON_TOPICS, PYTHON_CHEATSHEET, PYTHON_OVERVIEW
from learning.java_notes import JAVA_TOPICS, JAVA_CHEATSHEET, JAVA_OVERVIEW
from learning.c_notes import C_TOPICS, C_CHEATSHEET, C_OVERVIEW

ALL_LANGUAGES = {
    "python": {
        "language": "Python",
        "icon": "🐍",
        "tagline": "Modern, Readable & Versatile High-Level Language",
        "overview": PYTHON_OVERVIEW,
        "cheatsheet": PYTHON_CHEATSHEET,
        "topics": PYTHON_TOPICS
    },
    "java": {
        "language": "Java",
        "icon": "☕",
        "tagline": "Enterprise-Grade, Robust & Object-Oriented Standard",
        "overview": JAVA_OVERVIEW,
        "cheatsheet": JAVA_CHEATSHEET,
        "topics": JAVA_TOPICS
    },
    "c": {
        "language": "C",
        "icon": "⚡",
        "tagline": "High-Performance, Systems-Level Foundation of Computing",
        "overview": C_OVERVIEW,
        "cheatsheet": C_CHEATSHEET,
        "topics": C_TOPICS
    }
}

def get_notes_for_language(lang: str):
    return ALL_LANGUAGES.get(lang.lower().strip())

def search_notes(query: str, lang: str = None):
    results = []
    q = query.lower().strip()
    langs_to_search = [lang.lower().strip()] if lang and lang.lower().strip() in ALL_LANGUAGES else list(ALL_LANGUAGES.keys())

    for l_key in langs_to_search:
        data = ALL_LANGUAGES[l_key]
        for topic in data["topics"]:
            if q in topic["title"].lower() or q in topic["content"].lower():
                results.append({
                    "language": data["language"],
                    "topic_id": topic["id"],
                    "title": topic["title"],
                    "snippet": topic["content"][:250] + "..."
                })
    return results
