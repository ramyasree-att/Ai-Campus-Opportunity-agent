"""
C Programming Complete Study Notes & Placement Prep.
Contains 16 comprehensive chapters with pointers, dynamic memory allocation, structs, bitwise operations, and top interview questions.
"""

C_OVERVIEW = """C is a procedural, imperative, statically typed systems programming language developed by Dennis Ritchie between 1969 and 1973 at Bell Labs.
Known as the 'Mother of All Modern Programming Languages', C provides direct memory manipulation through pointers, exceptional runtime performance, and minimal overhead. It remains foundational for Operating Systems (Linux, Windows kernel), embedded systems, device drivers, and database engines."""

C_CHEATSHEET = [
    {"command": "printf(\"Format: %d, %s, %.2f\\n\", num, str, flt);", "desc": "Standard formatted print output"},
    {"command": "int *ptr = (int *)malloc(n * sizeof(int));", "desc": "Dynamic heap memory allocation for n integers"},
    {"command": "free(ptr); ptr = NULL;", "desc": "Deallocate memory and reset dangling pointer to NULL"},
    {"command": "struct Student { char name[50]; float cgpa; };", "desc": "User-defined composite structure definition"},
    {"command": "FILE *fp = fopen(\"data.txt\", \"r\"); if (fp) { ... fclose(fp); }", "desc": "Safe file open, read, and close sequence"},
    {"command": "int is_set = (num & (1 << k)) != 0;", "desc": "Check if the k-th bit is set using bitwise AND"}
]

C_TOPICS = [
    {
        "id": "c_01_intro_compilation",
        "title": "1. Introduction to C & GCC Compilation Process",
        "content": """### 1.1 The 4 Stages of C Compilation
1. **Preprocessing (`gcc -E`)**: Expands `#include`, `#define` macros, removes comments. Produces `.i` file.
2. **Compilation (`gcc -S`)**: Translates preprocessed C code into Assembly instructions. Produces `.s` file.
3. **Assembly (`gcc -c`)**: Translates Assembly code into machine code (object file). Produces `.o` file.
4. **Linking (`gcc -o`)**: Combines object files with system library code (libc) into the final executable.

```c
#include <stdio.h>

int main() {
    printf("Hello from C Language!\\n");
    return 0;
}
```"""
    },
    {
        "id": "c_02_datatypes_variables",
        "title": "2. Basic Syntax, Data Types, Variables & Constants",
        "content": """### 2.1 Primitive Data Types & Sizes
- `char`: 1 byte (-128 to 127)
- `short int`: 2 bytes
- `int`: 4 bytes (-2,147,483,648 to 2,147,483,647)
- `long long int`: 8 bytes
- `float`: 4 bytes (6 decimal digits precision)
- `double`: 8 bytes (15 decimal digits precision)

```c
#include <stdio.h>

int main() {
    const double PI = 3.1415926535;
    int roll_no = 101;
    float cgpa = 8.75f;
    char grade = 'A';

    printf("Roll: %d | CGPA: %.2f | Grade: %c\\n", roll_no, cgpa, grade);
    return 0;
}
```"""
    },
    {
        "id": "c_03_operators_expressions",
        "title": "3. Operators & Expressions",
        "content": """### 3.1 Operator Precedence & Associativity
- Unary: `++`, `--`, `!`, `~`, `sizeof`, `(type)`
- Multiplicative: `*`, `/`, `%`
- Additive: `+`, `-`
- Relational: `<`, `<=`, `>`, `>=`
- Equality: `==`, `!=`
- Logical: `&&`, `||`
- Assignment: `=`, `+=`, `-=`

```c
int a = 5, b = 10, c;
c = ++a + b--; // a becomes 6, c = 6 + 10 = 16, b becomes 9
```"""
    },
    {
        "id": "c_04_control_flow",
        "title": "4. Control Flow (Conditionals & Loops)",
        "content": """### 4.1 Switch Case & Fallthrough
```c
#include <stdio.h>

int main() {
    int choice = 2;
    switch (choice) {
        case 1:
            printf("View Active Internships\\n");
            break;
        case 2:
            printf("View Telangana Scholarships\\n");
            break;
        default:
            printf("Invalid Option\\n");
    }
    return 0;
}
```"""
    },
    {
        "id": "c_05_functions_recursion",
        "title": "5. Functions, Parameter Passing & Recursion",
        "content": """### 5.1 Call by Value vs Call by Reference
In C, everything is strictly pass-by-value. Pass-by-reference is simulated by passing pointer addresses.

```c
#include <stdio.h>

// Pass by reference using pointers
void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

// Recursion: Factorial
long long factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}
```"""
    },
    {
        "id": "c_06_arrays_multidimensional",
        "title": "6. Arrays & Multidimensional Arrays",
        "content": """### 6.1 Contiguous Memory & Array Name as Pointer
`arr[i]` is evaluated by compiler as `*(arr + i)`.

```c
#include <stdio.h>

int main() {
    int matrix[2][3] = {
        {1, 2, 3},
        {4, 5, 6}
    };
    
    for (int r = 0; r < 2; r++) {
        for (int c = 0; c < 3; c++) {
            printf("%d ", matrix[r][c]);
        }
        printf("\\n");
    }
    return 0;
}
```"""
    },
    {
        "id": "c_07_strings_string_h",
        "title": "7. Strings & String Manipulation Functions",
        "content": """### 7.1 Null-Terminated Strings (`\\0`)
```c
#include <stdio.h>
#include <string.h>

int main() {
    char str1[50] = "Telangana";
    char str2[] = " State";

    strcat(str1, str2); // Appends str2 to str1
    printf("Length: %zu, Combined: %s\\n", strlen(str1), str1);
    
    if (strcmp(str1, "Telangana State") == 0) {
        printf("Strings match exactly!\\n");
    }
    return 0;
}
```"""
    },
    {
        "id": "c_08_pointers_pointer_arithmetic",
        "title": "8. Pointers & Pointer Arithmetic",
        "content": """### 8.1 Pointer Basics
A pointer is a variable that stores the memory address of another variable.

```c
#include <stdio.h>

int main() {
    int val = 42;
    int *ptr = &val;
    int **dptr = &ptr; // Pointer to pointer

    printf("Value: %d | Address: %p | Via Dptr: %d\\n", val, (void*)ptr, **dptr);
    
    // Pointer arithmetic
    int arr[3] = {10, 20, 30};
    int *p = arr;
    printf("First: %d, Second: %d\\n", *p, *(p + 1));
    return 0;
}
```"""
    },
    {
        "id": "c_09_dynamic_memory_allocation",
        "title": "9. Dynamic Memory Allocation (malloc, calloc, realloc, free)",
        "content": """### 9.1 Heap Memory Management (`stdlib.h`)
- `malloc(size)`: Allocates uninitialized memory.
- `calloc(num, size)`: Allocates and initializes memory to zero.
- `realloc(ptr, new_size)`: Resizes previously allocated memory.
- `free(ptr)`: Releases heap block.

```c
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n = 5;
    int *arr = (int *)calloc(n, sizeof(int));
    if (arr == NULL) {
        fprintf(stderr, "Memory allocation failed!\\n");
        return 1;
    }

    for (int i = 0; i < n; i++) arr[i] = (i + 1) * 10;
    
    free(arr);
    arr = NULL; // Avoid dangling pointer
    return 0;
}
```"""
    },
    {
        "id": "c_10_structures_unions_enums",
        "title": "10. Structures, Unions & Enums",
        "content": """### 10.1 Structs vs Unions
- `struct`: Each member has its own separate memory location.
- `union`: All members share the same memory location (size = size of largest member).

```c
#include <stdio.h>

typedef struct {
    char title[100];
    char company[50];
    int stipend;
} Internship;

typedef enum {
    ACTIVE,
    EXPIRING_SOON,
    EXPIRED
} OppStatus;

int main() {
    Internship opp = {"Software Intern", "Microsoft", 90000};
    OppStatus status = ACTIVE;
    printf("Role: %s at %s\\n", opp.title, opp.company);
    return 0;
}
```"""
    },
    {
        "id": "c_11_file_io",
        "title": "11. File I/O Operations (fopen, fread, fwrite, fscanf, fprintf)",
        "content": """### 11.1 Reading & Writing Text/Binary Files
```c
#include <stdio.h>

int main() {
    FILE *fp = fopen("output.txt", "w");
    if (!fp) return 1;

    fprintf(fp, "Student_ID: %d, Match_Score: %.1f\\n", 101, 94.5);
    fclose(fp);

    // Reading
    fp = fopen("output.txt", "r");
    char line[128];
    while (fgets(line, sizeof(line), fp)) {
        printf("Read: %s", line);
    }
    fclose(fp);
    return 0;
}
```"""
    },
    {
        "id": "c_12_preprocessor_macros",
        "title": "12. Preprocessor Directives & Macros",
        "content": """### 12.1 `#define`, `#ifdef`, `#ifndef`, `#pragma once`
```c
#include <stdio.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define DEBUG 1

int main() {
#ifdef DEBUG
    printf("Debug mode active\\n");
#endif
    printf("Max of 20 and 50 is: %d\\n", MAX(20, 50));
    return 0;
}
```"""
    },
    {
        "id": "c_13_bitwise_operations",
        "title": "13. Bitwise Operators & Bit Manipulation",
        "content": """### 13.1 Bitwise Tricks for Placement Interviews
- Check if power of 2: `(n & (n - 1)) == 0`
- XOR Swap: `a ^= b; b ^= a; a ^= b;`
- Count set bits (Brian Kernighan’s Algorithm):
```c
int count_set_bits(int n) {
    int count = 0;
    while (n) {
        n &= (n - 1);
        count++;
    }
    return count;
}
```"""
    },
    {
        "id": "c_14_command_line_args",
        "title": "14. Command Line Arguments (`argc`, `argv`)",
        "content": """### 14.1 Reading CLI Arguments
```c
#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("Program name: %s\\n", argv[0]);
    printf("Total arguments passed: %d\\n", argc - 1);
    for (int i = 1; i < argc; i++) {
        printf("Argument %d: %s\\n", i, argv[i]);
    }
    return 0;
}
```"""
    },
    {
        "id": "c_15_memory_leaks_debugging",
        "title": "15. Memory Leaks & Debugging with GDB and Valgrind",
        "content": """### 15.1 Common Memory Bugs
1. **Dangling Pointer**: Accessing memory after it has been `free()`-d.
2. **Memory Leak**: Allocating memory without freeing it before lost references.
3. **Buffer Overflow**: Writing past the boundary of allocated array.

Compile with debug symbols:
```bash
gcc -g -Wall program.c -o program
valgrind --leak-check=full ./program
```"""
    },
    {
        "id": "c_16_interview_questions",
        "title": "16. Top 30 C Placement Interview Questions & Answers",
        "content": """### Q1: What is a `void *` pointer?
A generic pointer that has no associated data type. It can hold the address of any type and can be typecast to any other pointer type.

### Q2: Difference between `const char *p` and `char * const p`?
- `const char *p`: Pointer to a constant character (cannot change the character value, but can change pointer address).
- `char * const p`: Constant pointer to a character (can change the character value, but pointer address is fixed).

### Q3: What is a segmentation fault (SIGSEGV)?
Occurs when a program attempts to access a memory location that it is not allowed to access (e.g. dereferencing a NULL or wild pointer, stack overflow).

### Q4: Why is `sizeof` an operator and not a function?
`sizeof` is evaluated at compile-time (except for C99 Variable Length Arrays), so it generates a constant expression with zero runtime overhead."""
    }
]
