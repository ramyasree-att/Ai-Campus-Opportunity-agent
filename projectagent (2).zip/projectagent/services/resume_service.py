import os
import re
from pathlib import Path
from pypdf import PdfReader
from config import Config

COMMON_SKILLS_KEYWORDS = [
    "Python", "Java", "C", "C++", "C#", "JavaScript", "TypeScript", "HTML", "CSS", "SQL",
    "PostgreSQL", "MySQL", "MongoDB", "SQLite", "React", "Node.js", "Express", "Flask",
    "Django", "Spring Boot", "Git", "GitHub", "Docker", "Kubernetes", "AWS", "Azure",
    "GCP", "Linux", "Machine Learning", "Deep Learning", "TensorFlow", "PyTorch",
    "Scikit-Learn", "Pandas", "NumPy", "Data Science", "Computer Vision", "NLP",
    "Natural Language Processing", "REST API", "GraphQL", "TailwindCSS", "Bootstrap",
    "Data Structures", "Algorithms", "Object Oriented Programming", "OOP",
    "Clinical Research", "Clinical Pharmacy", "Pharmacology", "Pharmacovigilance",
    "Good Clinical Practice", "GCP", "Biostatistics", "Medical Writing",
    "Communication", "Leadership", "Teamwork", "Problem Solving", "Agile", "Scrum"
]

def extract_text_from_file(file_path):
    """
    Extracts text content from PDF, DOCX, or plain text files.
    """
    p = Path(file_path)
    ext = p.suffix.lower()
    text = ""

    if ext == ".pdf":
        try:
            reader = PdfReader(str(file_path))
            for page in reader.pages:
                t = page.extract_text()
                if t:
                    text += t + "\n"
        except Exception as e:
            # Fallback
            text = f"[PDF Extraction Error: {str(e)}]"
    elif ext in [".txt", ".md"]:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception as e:
            text = f"[Text Extraction Error: {str(e)}]"
    elif ext in [".docx", ".doc"]:
        try:
            # Attempt to read docx or fallback to text decoding
            with open(file_path, "rb") as f:
                raw = f.read()
                # Simple extraction for xml/text chunks
                clean = re.sub(rb"[^\x20-\x7E\n\r\t]", b" ", raw)
                text = clean.decode("utf-8", errors="ignore")
        except Exception as e:
            text = f"[DOCX Extraction Error: {str(e)}]"
    else:
        text = ""

    return text.strip()

def parse_resume_content(text, target_career_goal=""):
    """
    Parses extracted resume text to identify skills, email, phone, education,
    and returns a structured analysis profile.
    """
    if not text:
        return {
            "success": False,
            "message": "Resume content was empty or unreadable.",
            "skills": [],
            "programming_languages": [],
            "score": 0,
            "summary": "No readable content found in resume."
        }

    # Extract email
    email_match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", text)
    email = email_match.group(0) if email_match else ""

    # Extract phone
    phone_match = re.search(r"(\+?\d{1,3}[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}", text)
    phone = phone_match.group(0) if phone_match else ""

    # Detect skills
    detected_skills = []
    detected_langs = []
    text_lower = text.lower()

    programming_lang_names = ["python", "java", "c", "c++", "c#", "javascript", "typescript", "sql", "html", "css", "php", "ruby", "go", "rust"]

    for kw in COMMON_SKILLS_KEYWORDS:
        kw_lower = kw.lower()
        # Word boundary search
        pattern = r"(?:^|[\s,;./()\-])" + re.escape(kw_lower) + r"(?:$|[\s,;./()\-])"
        if re.search(pattern, text_lower):
            if kw_lower in programming_lang_names:
                if kw not in detected_langs:
                    detected_langs.append(kw)
            else:
                if kw not in detected_skills:
                    detected_skills.append(kw)

    # Detect CGPA
    cgpa_val = None
    cgpa_match = re.search(r"(?:cgpa|gpa|percentage)[:\s]+([0-9]+(?:\.[0-9]+)?)", text_lower)
    if cgpa_match:
        try:
            cgpa_val = float(cgpa_match.group(1))
        except Exception:
            pass

    # Calculate Resume Strength Score (out of 100)
    score = 40  # baseline for uploaded resume
    if len(detected_skills) >= 3:
        score += 20
    elif len(detected_skills) >= 1:
        score += 10

    if len(detected_langs) >= 2:
        score += 20
    elif len(detected_langs) >= 1:
        score += 10

    if email:
        score += 10
    if len(text) > 300:
        score += 10

    score = min(100, score)

    # Generate Summary
    skills_summary = ", ".join((detected_langs + detected_skills)[:6]) if (detected_langs or detected_skills) else "General profile"
    summary_text = f"Resume parsed successfully! Identified competencies in: {skills_summary}. Resume Strength: {score}/100."

    return {
        "success": True,
        "email": email,
        "phone": phone,
        "cgpa": cgpa_val,
        "skills": detected_skills,
        "programming_languages": detected_langs,
        "all_skills": detected_langs + detected_skills,
        "resume_score": score,
        "summary": summary_text,
        "raw_text_snippet": text[:400] + ("..." if len(text) > 400 else "")
    }

def process_uploaded_resume(file_path, user_id=None, target_career_goal=""):
    """
    Reads resume file, parses content, and updates student profile in database.
    """
    text = extract_text_from_file(file_path)
    parsed = parse_resume_content(text, target_career_goal)
    return parsed
