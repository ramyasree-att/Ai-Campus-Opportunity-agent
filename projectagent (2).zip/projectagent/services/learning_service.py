import json
from database import get_db_connection

CURATED_PLANS = {
    "python": {
        "title": "Python — 7-Day Fast-Track Mastery Plan",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": "Python Basics & Syntax", "details": "Variables, data types (int, str, float), input/output, and operators.", "completed": False},
            {"day": 2, "topic": "Control Flow & Iterations", "details": "If-else conditions, match statements, for loops, and while loops.", "completed": False},
            {"day": 3, "topic": "Functions & Modular Code", "details": "Defining functions, *args/**kwargs, lambda expressions, and scope.", "completed": False},
            {"day": 4, "topic": "Core Data Structures", "details": "Lists, Tuples, Dictionaries, Sets, and list comprehensions.", "completed": False},
            {"day": 5, "topic": "Object-Oriented Programming & File I/O", "details": "Classes, methods, inheritance, reading/writing JSON & CSV files.", "completed": False},
            {"day": 6, "topic": "Hands-on Mini Project", "details": "Build an Automated Opportunity Scraper or CLI Expense Tracker.", "completed": False},
            {"day": 7, "topic": "Interview Prep & Coding Practice", "details": "Solve 5 LeetCode Easy/Medium problems & review common Python interview questions.", "completed": False}
        ]
    },
    "java": {
        "title": "Java — 7-Day Object-Oriented Blueprint",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": "Java Syntax & JVM Basics", "details": "JDK setup, primitive types, conditional operators, and memory model.", "completed": False},
            {"day": 2, "topic": "Control Structures & Loops", "details": "If-else statements, switch-case, for/while loops, and methods.", "completed": False},
            {"day": 3, "topic": "Core OOP Principles", "details": "Encapsulation, Inheritance, Polymorphism, and Abstract classes.", "completed": False},
            {"day": 4, "topic": "Java Collections Framework", "details": "ArrayList, HashMap, HashSet, Iterators, and Generics.", "completed": False},
            {"day": 5, "topic": "Exception Handling & Streams API", "details": "Try-catch-finally, custom exceptions, lambda expressions, and Stream map/filter.", "completed": False},
            {"day": 6, "topic": "Mini Project: Student Management System", "details": "Build a CLI/GUI application with CRUD operations using collections.", "completed": False},
            {"day": 7, "topic": "Top 10 Java Interview Questions", "details": "Practice String immutability, equal vs ==, collections complexity, and OOP design.", "completed": False}
        ]
    },
    "sql": {
        "title": "SQL — 7-Day Relational Database & Queries Plan",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": "RDBMS Fundamentals & SELECT Queries", "details": "Database concepts, tables, SELECT, WHERE, DISTINCT, and ORDER BY.", "completed": False},
            {"day": 2, "topic": "Filtering, LIKE & Aggregate Functions", "details": "COUNT, SUM, AVG, MIN, MAX, GROUP BY, and HAVING clauses.", "completed": False},
            {"day": 3, "topic": "Table Joins Mastery", "details": "INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL OUTER JOIN, and Self Joins.", "completed": False},
            {"day": 4, "topic": "Subqueries & Common Table Expressions (CTEs)", "details": "Correlated subqueries, WITH clauses, and nested queries.", "completed": False},
            {"day": 5, "topic": "Data Definition & Modification (DDL/DML)", "details": "CREATE, ALTER, INSERT, UPDATE, DELETE, Foreign Keys, and Constraints.", "completed": False},
            {"day": 6, "topic": "Window Functions & Indexes", "details": "ROW_NUMBER(), RANK(), DENSE_RANK(), PARTITION BY, and indexing for speed.", "completed": False},
            {"day": 7, "topic": "Hands-on Query Practice & Interview Challenges", "details": "Solve top 10 SQL placement interview problems on HackerRank / LeetCode.", "completed": False}
        ]
    },
    "machine learning": {
        "title": "Machine Learning — 7-Day Applied AI Foundation",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": "Data Preprocessing with Pandas & NumPy", "details": "Data loading, handling missing values, feature scaling, and one-hot encoding.", "completed": False},
            {"day": 2, "topic": "Supervised Learning: Regression", "details": "Linear Regression, Ridge/Lasso, and evaluating RMSE / R2 metrics.", "completed": False},
            {"day": 3, "topic": "Supervised Learning: Classification", "details": "Logistic Regression, Decision Trees, Random Forests, and Confusion Matrix.", "completed": False},
            {"day": 4, "topic": "Unsupervised Learning & Clustering", "details": "K-Means clustering, PCA dimensionality reduction, and visualization with Seaborn.", "completed": False},
            {"day": 5, "topic": "Model Evaluation & Hyperparameter Tuning", "details": "K-Fold Cross Validation, GridSearchCV, and avoiding Overfitting/Underfitting.", "completed": False},
            {"day": 6, "topic": "End-to-End ML Project", "details": "Build a Student Placement Predictor or Housing Price Estimation model.", "completed": False},
            {"day": 7, "topic": "ML Interview Fundamentals & Deployment Intro", "details": "Explain Bias-Variance tradeoff, precision/recall, and export model using joblib.", "completed": False}
        ]
    },
    "javascript": {
        "title": "JavaScript — 7-Day Modern ES6+ Acceleration Plan",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": "Variables, Scoping & Data Types", "details": "let, const, primitive types, template literals, and truthy/falsy rules.", "completed": False},
            {"day": 2, "topic": "Functions & Arrow Functions", "details": "Higher-order functions, callbacks, closures, and default parameters.", "completed": False},
            {"day": 3, "topic": "Arrays & Modern Methods", "details": "map(), filter(), reduce(), find(), spread/rest operators, and destructuring.", "completed": False},
            {"day": 4, "topic": "DOM Manipulation & Event Handling", "details": "querySelector, addEventListener, dynamic styling, and form handling.", "completed": False},
            {"day": 5, "topic": "Asynchronous JS: Promises & Async/Await", "details": "Fetch API, handling JSON responses, async/await syntax, and error try/catch.", "completed": False},
            {"day": 6, "topic": "Interactive Project: Dynamic Opportunity Filter", "details": "Build a searchable and filterable client-side card catalog with LocalStorage.", "completed": False},
            {"day": 7, "topic": "JS Engine & Placement Interview Questions", "details": "Event loop, hoisting, Event Bubbling, and common coding puzzles.", "completed": False}
        ]
    },
    "clinical pharmacy": {
        "title": "Clinical Pharmacy & Research — 7-Day Practical Guide",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": "Good Clinical Practice (GCP) & Ethics", "details": "ICH-GCP guidelines, Belmont Report principles, and Institutional Review Boards.", "completed": False},
            {"day": 2, "topic": "Clinical Trial Phases & Protocol Design", "details": "Phases I to IV, randomized controlled trials (RCT), and inclusion/exclusion criteria.", "completed": False},
            {"day": 3, "topic": "Medication Therapy Management (MTM)", "details": "Drug interaction screening, renal dosage adjustments, and therapeutic drug monitoring.", "completed": False},
            {"day": 4, "topic": "Pharmacovigilance & ADR Reporting", "details": "Adverse drug reaction mechanisms, causality assessment (Naranjo scale), and MedDRA.", "completed": False},
            {"day": 5, "topic": "Biostatistics & Evidence-Based Medicine", "details": "p-values, odds ratios, relative risk, confidence intervals, and Kaplan-Meier curves.", "completed": False},
            {"day": 6, "topic": "Clinical Case Study Analysis", "details": "Review real-world hospital patient charts and prepare clinical intervention notes.", "completed": False},
            {"day": 7, "topic": "Clinical Research Interview & Presentation Prep", "details": "Key trial terminology, standard operating procedures (SOP), and clinical communication.", "completed": False}
        ]
    }
}

def generate_7day_learning_plan(skill_name, career_goal=""):
    """
    Generates a structured 7-day beginner-to-competent learning plan.
    """
    norm_skill = skill_name.strip().lower()

    for key, plan in CURATED_PLANS.items():
        if key in norm_skill or norm_skill in key:
            return json.loads(json.dumps(plan))

    # Generic realistic 7-day structure for custom skills
    formatted_name = skill_name.strip().title()
    return {
        "title": f"{formatted_name} — 7-Day Fast-Track Mastery Plan",
        "duration_days": 7,
        "days": [
            {"day": 1, "topic": f"{formatted_name} Fundamentals & Architecture", "details": f"Core concepts, syntax, environment setup, and basic principles of {formatted_name}.", "completed": False},
            {"day": 2, "topic": "Key Building Blocks & Patterns", "details": f"Fundamental structures, workflows, and standard conventions in {formatted_name}.", "completed": False},
            {"day": 3, "topic": "Practical Operations & Core Tools", "details": f"Hands-on commands, standard library features, and configuration in {formatted_name}.", "completed": False},
            {"day": 4, "topic": "Integration & Real-world Workflows", "details": f"Connecting {formatted_name} with databases, APIs, or external frameworks.", "completed": False},
            {"day": 5, "topic": "Error Handling, Testing & Best Practices", "details": f"Debugging techniques, edge cases, and performance optimization for {formatted_name}.", "completed": False},
            {"day": 6, "topic": "Capstone Mini Project", "details": f"Build and document a functional project highlighting your {formatted_name} skills.", "completed": False},
            {"day": 7, "topic": "Interview Preparation & Skill Validation", "details": f"Review top industry interview questions and prepare portfolio talking points.", "completed": False}
        ]
    }

def create_or_get_learning_plan(user_id, skill_name, career_goal=""):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM learning_plans WHERE user_id = ? AND LOWER(skill_name) = LOWER(?)", (user_id, skill_name.strip()))
    existing = cursor.fetchone()

    if existing:
        plan_dict = dict(existing)
        plan_dict["plan_json"] = json.loads(plan_dict["plan_json"])
        conn.close()
        return plan_dict

    # Generate new plan
    plan_data = generate_7day_learning_plan(skill_name, career_goal)
    cursor.execute("""
    INSERT INTO learning_plans (user_id, skill_name, title, duration_days, plan_json, progress_percentage)
    VALUES (?, ?, ?, ?, ?, 0)
    """, (
        user_id,
        skill_name.strip().title(),
        plan_data["title"],
        plan_data["duration_days"],
        json.dumps(plan_data["days"])
    ))
    new_id = cursor.lastrowid
    conn.commit()

    cursor.execute("SELECT * FROM learning_plans WHERE id = ?", (new_id,))
    new_plan = dict(cursor.fetchone())
    new_plan["plan_json"] = json.loads(new_plan["plan_json"])
    conn.close()

    return new_plan

def get_user_learning_plans(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM learning_plans WHERE user_id = ? ORDER BY id DESC", (user_id,))
    rows = cursor.fetchall()
    plans = []
    for row in rows:
        p = dict(row)
        p["plan_json"] = json.loads(p["plan_json"])
        plans.append(p)

    conn.close()
    return plans

def update_day_status(user_id, plan_id, day_number, is_completed):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM learning_plans WHERE id = ? AND user_id = ?", (plan_id, user_id))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return {"success": False, "message": "Learning plan not found."}

    days = json.loads(row["plan_json"])
    for d in days:
        if d["day"] == int(day_number):
            d["completed"] = bool(is_completed)

    completed_count = sum(1 for d in days if d.get("completed", False))
    progress = round((completed_count / len(days)) * 100) if days else 0

    cursor.execute("""
    UPDATE learning_plans SET plan_json = ?, progress_percentage = ? WHERE id = ?
    """, (json.dumps(days), progress, plan_id))

    conn.commit()
    conn.close()

    return {
        "success": True,
        "progress_percentage": progress,
        "days": days
    }
