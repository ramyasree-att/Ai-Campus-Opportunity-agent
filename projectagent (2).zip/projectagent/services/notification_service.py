from datetime import datetime, date
from database import get_db_connection

def calculate_deadline_badge(deadline_str):
    if not deadline_str:
        return {
            "days_left": None,
            "badge_text": "Rolling Basis",
            "badge_class": "badge-neutral",
            "is_urgent": False
        }

    try:
        deadline_date = datetime.strptime(str(deadline_str).split("T")[0], "%Y-%m-%d").date()
        today = date.today()
        diff = (deadline_date - today).days

        if diff < 0:
            return {
                "days_left": diff,
                "badge_text": "Deadline Passed",
                "badge_class": "badge-expired",
                "is_urgent": False,
                "level": "expired"
            }
        elif diff == 0:
            return {
                "days_left": 0,
                "badge_text": "🔴 DEADLINE TODAY",
                "badge_class": "badge-danger",
                "is_urgent": True,
                "level": "today"
            }
        elif diff == 1:
            return {
                "days_left": 1,
                "badge_text": "🔴 DEADLINE TOMORROW",
                "badge_class": "badge-danger",
                "is_urgent": True,
                "level": "tomorrow"
            }
        elif diff <= 3:
            return {
                "days_left": diff,
                "badge_text": f"🟠 {diff} DAYS LEFT",
                "badge_class": "badge-warning",
                "is_urgent": True,
                "level": "urgent"
            }
        elif diff <= 7:
            return {
                "days_left": diff,
                "badge_text": f"🟡 {diff} DAYS LEFT",
                "badge_class": "badge-info",
                "is_urgent": False,
                "level": "approaching"
            }
        else:
            return {
                "days_left": diff,
                "badge_text": f"🟢 {diff} DAYS LEFT",
                "badge_class": "badge-success",
                "is_urgent": False,
                "level": "normal"
            }
    except Exception:
        return {
            "days_left": None,
            "badge_text": str(deadline_str),
            "badge_class": "badge-neutral",
            "is_urgent": False
        }

def get_user_notifications(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT * FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 20
    """, (user_id,))
    rows = cursor.fetchall()
    notifications = [dict(r) for r in rows]

    cursor.execute("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0", (user_id,))
    unread_count = cursor.fetchone()["count"]

    conn.close()
    return {
        "notifications": notifications,
        "unread_count": unread_count
    }

def mark_notification_as_read(user_id, notification_id=None):
    conn = get_db_connection()
    cursor = conn.cursor()

    if notification_id and str(notification_id).lower() != "all":
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", (notification_id, user_id))
    else:
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ?", (user_id,))

    conn.commit()
    conn.close()
    return {"success": True}

def generate_proactive_alerts(profile, opportunities):
    """
    Generates proactive AI alerts for the student dashboard.
    """
    alerts = []

    # 1. Profile Completion Alert
    if profile and "completion" in profile:
        comp = profile["completion"]
        if comp["percentage"] < 100:
            missing_text = ", ".join(comp["missing_fields"][:3])
            alerts.append({
                "type": "profile",
                "icon": "⚠️",
                "title": f"Your profile is {comp['percentage']}% complete",
                "message": f"Missing: {missing_text}. Completing your profile helps me find more accurate opportunities for you.",
                "action_text": "Complete Profile",
                "action_target": "complete_info"
            })

    # 2. Urgent Deadlines Alert
    urgent_deadlines = []
    for opp in opportunities:
        d_badge = calculate_deadline_badge(opp.get("deadline"))
        if d_badge.get("is_urgent") and d_badge.get("days_left", 999) >= 0:
            urgent_deadlines.append(f"{opp['title']} ({d_badge['badge_text']})")

    if urgent_deadlines:
        alerts.append({
            "type": "deadline",
            "icon": "🔴",
            "title": f"{len(urgent_deadlines)} Urgent Deadline{'s' if len(urgent_deadlines) > 1 else ''} Approaching!",
            "message": " • ".join(urgent_deadlines[:2]),
            "action_text": "View Deadlines",
            "action_target": "opportunities"
        })

    # 3. High Match Opportunities Alert
    high_matches = [opp for opp in opportunities if opp.get("match_score", 0) >= 80]
    if high_matches:
        alerts.append({
            "type": "match",
            "icon": "🎯",
            "title": f"Good news! Found {len(high_matches)} top-matching opportunities",
            "message": f"Top match: {high_matches[0]['title']} ({high_matches[0]['match_score']}% Match)",
            "action_text": "Explore Matches",
            "action_target": "internships"
        })

    return alerts
