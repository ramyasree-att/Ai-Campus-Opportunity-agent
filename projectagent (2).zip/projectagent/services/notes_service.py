"""
Comprehensive Interactive Learning Notes and Cheatsheets for Python, Java, and C.
Available anytime for college students with syntax guides, code snippets, and top placement interview questions.
"""
from learning import ALL_LANGUAGES, get_notes_for_language as get_lang_notes

PROGRAMMING_NOTES = ALL_LANGUAGES

def get_all_notes():
    return ALL_LANGUAGES

def get_notes_for_language(language):
    lang_key = (language or "").strip().lower()
    return get_lang_notes(lang_key)
