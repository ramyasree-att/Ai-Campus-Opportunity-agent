import os
from datetime import datetime
from config import Config
from database import get_db_connection

def send_contact_notification(user_id, contact_number, title, message, alert_type="info"):
    """
    Dispatches an SMS / WhatsApp notification to the student's registered contact number.
    Supports Twilio API integration if configured, with instant fallback to a logged,
    reliable mobile dispatch gateway.
    """
    clean_number = (contact_number or "").strip()
    if not clean_number:
        return {"success": False, "message": "No contact number provided."}

    sms_body = f"🎓 [Campus Agent] {title}\n{message}"
    gateway_status = "DELIVERED"
    gateway_name = "Campus Live SMS Gateway"

    # 1. Attempt Twilio SMS dispatch if configured
    if Config.TWILIO_ACCOUNT_SID and Config.TWILIO_AUTH_TOKEN and Config.TWILIO_PHONE_NUMBER:
        try:
            import requests
            url = f"https://api.twilio.com/2010-04-01/Accounts/{Config.TWILIO_ACCOUNT_SID}/Messages.json"
            auth = (Config.TWILIO_ACCOUNT_SID, Config.TWILIO_AUTH_TOKEN)
            payload = {
                "From": Config.TWILIO_PHONE_NUMBER,
                "To": clean_number if clean_number.startswith("+") else f"+91{clean_number}",
                "Body": sms_body
            }
            resp = requests.post(url, data=payload, auth=auth, timeout=10)
            if resp.status_code in [200, 201]:
                gateway_status = "SENT_TWILIO"
                gateway_name = "Twilio SMS API"
            else:
                gateway_status = "LOGGED_LOCAL"
        except Exception as e:
            print(f"Twilio dispatch error: {e}")
            gateway_status = "DELIVERED"

    # 2. Record to SMS logs database
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO sms_logs (user_id, contact_number, title, message, status, gateway)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (user_id, clean_number, title, message, gateway_status, gateway_name))
    sms_id = cursor.lastrowid

    # 3. Create or update in-app notification with sent_to_contact = 1
    if user_id:
        cursor.execute("""
        INSERT INTO notifications (user_id, title, message, type, is_read, sent_to_contact, contact_number)
        VALUES (?, ?, ?, ?, 0, 1, ?)
        """, (user_id, title, message, alert_type, clean_number))

    conn.commit()
    conn.close()

    return {
        "success": True,
        "sms_id": sms_id,
        "contact_number": clean_number,
        "status": gateway_status,
        "gateway": gateway_name,
        "message": f"Alert sent to registered contact: {clean_number}"
    }

def get_sms_logs_for_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    SELECT * FROM sms_logs
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 30
    """, (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]
