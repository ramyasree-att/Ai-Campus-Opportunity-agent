import html
import time
import re
from functools import wraps
from flask import request, jsonify, g
from config import Config

# In-memory sliding window rate limiter
RATE_LIMIT_STORE = {}

def sanitize_input(text):
    """
    Sanitizes user input to prevent XSS and malicious script injection
    while preserving standard ampersands and punctuation.
    """
    if not isinstance(text, str):
        return text
    # Strip dangerous HTML tags and script injections
    clean = re.sub(r"<\s*script[^>]*>.*?<\s*/\s*script\s*>", "", text, flags=re.IGNORECASE | re.DOTALL)
    clean = re.sub(r"<\s*img[^>]*onerror[^>]*>", "", clean, flags=re.IGNORECASE)
    clean = re.sub(r"<\s*iframe[^>]*>.*?<\s*/\s*iframe\s*>", "", clean, flags=re.IGNORECASE | re.DOTALL)
    # Strip < and > to prevent tag injection
    clean = clean.replace("<", "").replace(">", "")
    return clean.strip()

def sanitize_dict_inputs(d):
    """
    Recursively sanitizes dictionary strings.
    """
    if not isinstance(d, dict):
        return d
    sanitized = {}
    for k, v in d.items():
        if isinstance(v, str):
            sanitized[k] = sanitize_input(v)
        elif isinstance(v, dict):
            sanitized[k] = sanitize_dict_inputs(v)
        elif isinstance(v, list):
            sanitized[k] = [sanitize_input(i) if isinstance(i, str) else i for i in v]
        else:
            sanitized[k] = v
    return sanitized

def rate_limit(limit=60, window_seconds=60):
    """
    Decorator to enforce rate limiting per client IP to prevent brute-force attacks and abuse.
    Default: 60 requests per minute per IP.
    """
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "127.0.0.1")
            client_ip = client_ip.split(",")[0].strip()
            endpoint_key = f"{client_ip}:{request.endpoint}"

            now = time.time()
            cutoff = now - window_seconds

            timestamps = RATE_LIMIT_STORE.get(endpoint_key, [])
            timestamps = [ts for ts in timestamps if ts > cutoff]

            if len(timestamps) >= limit:
                return jsonify({
                    "success": False,
                    "error": "Rate limit exceeded",
                    "message": f"Too many requests from your IP. Please wait a moment before trying again."
                }), 429

            timestamps.append(now)
            RATE_LIMIT_STORE[endpoint_key] = timestamps
            return f(*args, **kwargs)
        return wrapped
    return decorator

def apply_security_headers(response):
    """
    Applies defense-in-depth HTTP security headers to all responses.
    """
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(self), geolocation=()"
    
    csp_policy = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://accounts.google.com https://apis.google.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://accounts.google.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data: https:; "
        "connect-src 'self' https://openrouter.ai https://accounts.google.com; "
        "frame-src https://accounts.google.com;"
    )
    response.headers["Content-Security-Policy"] = csp_policy
    return response

def validate_uploaded_file(file_obj, max_size_mb=10):
    """
    Validates uploaded file size and extension to prevent malicious file uploads.
    """
    if not file_obj or not file_obj.filename:
        return False, "No file uploaded."
    
    filename = file_obj.filename
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    
    allowed = Config.ALLOWED_EXTENSIONS | Config.ALLOWED_IMAGE_EXTENSIONS | Config.ALLOWED_RESUME_EXTENSIONS
    if ext not in allowed:
        return False, f"File type '.{ext}' is not permitted for security reasons."
    
    file_obj.seek(0, 2)
    size_bytes = file_obj.tell()
    file_obj.seek(0)
    
    if size_bytes > max_size_mb * 1024 * 1024:
        return False, f"File size ({size_bytes / (1024*1024):.1f}MB) exceeds the maximum allowed limit of {max_size_mb}MB."
    
    return True, "Valid"
