from database import get_db_connection

def get_opportunities(user_id=None, category=None, search_query=None, mode=None, location=None, verification_status=None, sort_by="deadline"):
    conn = get_db_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM opportunities WHERE 1=1"
    params = []

    if category and category.lower() != "all":
        query += " AND LOWER(category) = ?"
        params.append(category.lower())

    if mode and mode.lower() != "all":
        query += " AND LOWER(mode) = ?"
        params.append(mode.lower())

    if verification_status and verification_status.lower() != "all":
        if "verified" in verification_status.lower() and "not" not in verification_status.lower():
            query += " AND verification_status LIKE '%Verified%'"
        elif "not" in verification_status.lower():
            query += " AND verification_status LIKE '%Not%'"

    if location and location.strip():
        query += " AND (LOWER(location) LIKE ? OR LOWER(location) LIKE '%remote%')"
        params.append(f"%{location.lower().strip()}%")

    if search_query and search_query.strip():
        search_terms = search_query.strip().lower().split()
        for term in search_terms:
            query += """ AND (
                LOWER(title) LIKE ? OR
                LOWER(organization) LIKE ? OR
                LOWER(description) LIKE ? OR
                LOWER(required_skills) LIKE ? OR
                LOWER(eligibility) LIKE ? OR
                LOWER(category) LIKE ? OR
                LOWER(location) LIKE ?
            )"""
            pattern = f"%{term}%"
            params.extend([pattern, pattern, pattern, pattern, pattern, pattern, pattern])

    # Sorting
    if sort_by == "deadline":
        query += " ORDER BY CASE WHEN deadline >= DATE('now') THEN 0 ELSE 1 END, deadline ASC"
    elif sort_by == "recent":
        query += " ORDER BY created_at DESC"
    else:
        query += " ORDER BY id DESC"

    cursor.execute(query, params)
    rows = cursor.fetchall()
    opportunities = [dict(row) for row in rows]

    # If user_id is provided, attach is_saved and is_applied flags
    if user_id:
        cursor.execute("SELECT opportunity_id FROM saved_opportunities WHERE user_id = ?", (user_id,))
        saved_ids = {r["opportunity_id"] for r in cursor.fetchall()}

        cursor.execute("SELECT opportunity_id, status FROM applications WHERE user_id = ?", (user_id,))
        applied_map = {r["opportunity_id"]: r["status"] for r in cursor.fetchall()}

        for opp in opportunities:
            opp["is_saved"] = opp["id"] in saved_ids
            opp["application_status"] = applied_map.get(opp["id"], None)
            opp["is_applied"] = opp["id"] in applied_map

    conn.close()
    return opportunities

def get_opportunity_by_id(opportunity_id, user_id=None):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM opportunities WHERE id = ?", (opportunity_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None

    opp = dict(row)

    if user_id:
        cursor.execute("SELECT id FROM saved_opportunities WHERE user_id = ? AND opportunity_id = ?", (user_id, opportunity_id))
        opp["is_saved"] = cursor.fetchone() is not None

        cursor.execute("SELECT status, applied_at, notes, prepared_data_json FROM applications WHERE user_id = ? AND opportunity_id = ?", (user_id, opportunity_id))
        app_row = cursor.fetchone()
        if app_row:
            opp["is_applied"] = True
            opp["application_status"] = app_row["status"]
            opp["applied_at"] = app_row["applied_at"]
        else:
            opp["is_applied"] = False
            opp["application_status"] = None

    conn.close()
    return opp

def toggle_save_opportunity(user_id, opportunity_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id FROM saved_opportunities WHERE user_id = ? AND opportunity_id = ?", (user_id, opportunity_id))
    existing = cursor.fetchone()

    if existing:
        cursor.execute("DELETE FROM saved_opportunities WHERE user_id = ? AND opportunity_id = ?", (user_id, opportunity_id))
        conn.commit()
        conn.close()
        return {"success": True, "saved": False, "message": "Opportunity removed from saved list."}
    else:
        cursor.execute("INSERT INTO saved_opportunities (user_id, opportunity_id) VALUES (?, ?)", (user_id, opportunity_id))
        conn.commit()
        conn.close()
        return {"success": True, "saved": True, "message": "Opportunity saved to My Saved list! 📌"}

def get_saved_opportunities(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT o.*, s.saved_at
    FROM opportunities o
    JOIN saved_opportunities s ON o.id = s.opportunity_id
    WHERE s.user_id = ?
    ORDER BY CASE WHEN o.deadline >= DATE('now') THEN 0 ELSE 1 END, o.deadline ASC
    """, (user_id,))

    rows = cursor.fetchall()
    saved = [dict(row) for row in rows]

    cursor.execute("SELECT opportunity_id, status FROM applications WHERE user_id = ?", (user_id,))
    applied_map = {r["opportunity_id"]: r["status"] for r in cursor.fetchall()}

    for item in saved:
        item["is_saved"] = True
        item["application_status"] = applied_map.get(item["id"], None)
        item["is_applied"] = item["id"] in applied_map

    conn.close()
    return saved
