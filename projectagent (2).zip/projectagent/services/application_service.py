import json
from database import get_db_connection
from services.profile_service import get_profile_by_user_id
from services.opportunity_service import get_opportunity_by_id

def prepare_application_data(user_id, opportunity_id):
    """
    Step 1 of Two-Click Application Flow:
    Extracts student's stored profile details and prepares an Application Preview.
    """
    profile = get_profile_by_user_id(user_id)
    opp = get_opportunity_by_id(opportunity_id, user_id)

    if not profile or not opp:
        return {"success": False, "message": "Profile or opportunity not found."}

    skills_str = ", ".join(profile.get("skills", []))
    langs_str = ", ".join(profile.get("programming_languages", []))
    all_skills = [s for s in [skills_str, langs_str] if s]

    preview = {
        "opportunity_id": opp["id"],
        "opportunity_title": opp["title"],
        "organization": opp["organization"],
        "category": opp["category"],
        "application_url": opp["application_url"],
        "source": opp["source"],
        "verification_status": opp["verification_status"],
        "student_details": {
            "name": profile.get("name", ""),
            "email": profile.get("email", ""),
            "contact_number": profile.get("contact_number", ""),
            "father_name": profile.get("father_name", ""),
            "college_name": profile.get("college_name", ""),
            "branch": profile.get("branch", ""),
            "academic_year": profile.get("academic_year", ""),
            "cgpa": profile.get("cgpa", ""),
            "skills": ", ".join(all_skills),
            "career_goal": profile.get("career_goal", ""),
            "preferred_location": profile.get("preferred_location", ""),
            "additional_notes": f"Enthusiastic applicant with background in {profile.get('branch', 'academics')} targeting {profile.get('career_goal', 'excellence')}."
        }
    }

    return {
        "success": True,
        "preview": preview
    }

def confirm_and_submit_application(user_id, opportunity_id, verified_data=None):
    """
    Step 2 of Two-Click Application Flow:
    Executes ONLY after explicit user confirmation.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM opportunities WHERE id = ?", (opportunity_id,))
    opp = cursor.fetchone()
    if not opp:
        conn.close()
        return {"success": False, "message": "Opportunity not found."}

    opp_dict = dict(opp)
    data_json = json.dumps(verified_data) if verified_data else "{}"

    # Check if already applied
    cursor.execute("SELECT id FROM applications WHERE user_id = ? AND opportunity_id = ?", (user_id, opportunity_id))
    existing = cursor.fetchone()

    if existing:
        cursor.execute("""
        UPDATE applications SET status = 'Applied', prepared_data_json = ?, applied_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """, (data_json, existing["id"]))
    else:
        cursor.execute("""
        INSERT INTO applications (user_id, opportunity_id, status, prepared_data_json)
        VALUES (?, ?, 'Applied', ?)
        """, (user_id, opportunity_id, data_json))

    # Add system notification
    cursor.execute("""
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (?, ?, ?, 'info')
    """, (
        user_id,
        f"Application Submitted: {opp_dict['title']} ✅",
        f"Your application for {opp_dict['title']} at {opp_dict['organization']} has been recorded. Continue to the verified portal if external steps are required."
    ))

    conn.commit()
    conn.close()

    return {
        "success": True,
        "message": "Application submitted successfully! ✅",
        "opportunity_title": opp_dict["title"],
        "organization": opp_dict["organization"],
        "application_url": opp_dict["application_url"],
        "status": "Applied"
    }

def get_my_applications(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT a.id as application_id, a.status, a.applied_at, a.notes, a.prepared_data_json,
           o.id as opportunity_id, o.title, o.organization, o.category, o.deadline,
           o.location, o.mode, o.application_url, o.source, o.verification_status
    FROM applications a
    JOIN opportunities o ON a.opportunity_id = o.id
    WHERE a.user_id = ?
    ORDER BY a.applied_at DESC
    """, (user_id,))

    rows = cursor.fetchall()
    apps = [dict(row) for row in rows]
    conn.close()

    stats = {
        "total": len(apps),
        "applied": sum(1 for a in apps if a["status"] == "Applied"),
        "shortlisted": sum(1 for a in apps if a["status"] == "Shortlisted"),
        "interviews": sum(1 for a in apps if a["status"] == "Interview"),
        "selected": sum(1 for a in apps if a["status"] == "Selected"),
        "rejected": sum(1 for a in apps if a["status"] == "Rejected")
    }

    return {
        "applications": apps,
        "stats": stats
    }

def update_application_status(user_id, application_id, new_status, notes=None):
    valid_statuses = ["Saved", "Application Prepared", "Applied", "Shortlisted", "Interview", "Selected", "Rejected"]
    if new_status not in valid_statuses:
        return {"success": False, "message": f"Invalid status. Must be one of: {', '.join(valid_statuses)}"}

    conn = get_db_connection()
    cursor = conn.cursor()

    if notes is not None:
        cursor.execute("UPDATE applications SET status = ?, notes = ? WHERE id = ? AND user_id = ?", (new_status, notes, application_id, user_id))
    else:
        cursor.execute("UPDATE applications SET status = ? WHERE id = ? AND user_id = ?", (new_status, application_id, user_id))

    conn.commit()
    conn.close()

    return {"success": True, "message": f"Status updated to {new_status}."}
