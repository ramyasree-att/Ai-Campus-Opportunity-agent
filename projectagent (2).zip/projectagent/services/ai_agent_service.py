import re
import json
import requests
from config import Config

def normalize_text_list(text_or_list):
    if not text_or_list:
        return []
    if isinstance(text_or_list, list):
        items = text_or_list
    else:
        items = [s.strip() for s in text_or_list.replace(";", ",").split(",") if s.strip()]
    return [i.strip() for i in items if i.strip()]

def check_eligibility(profile, opportunity):
    """
    Compares student's profile (branch, year, CGPA, qualifications) against opportunity requirements.
    Returns: status ('ELIGIBLE ✅', 'PARTIALLY ELIGIBLE ⚠️', 'NOT ELIGIBLE ❌') and explanation reason.
    """
    # If opportunity deadline is expired, flag it immediately
    if opportunity.get("is_expired"):
        return {
            "status": "DEADLINE EXPIRED ❌",
            "badge_class": "badge-danger",
            "reason": "This opportunity deadline has passed. Applications are no longer accepted."
        }

    if not profile:
        return {
            "status": "PARTIALLY ELIGIBLE ⚠️",
            "badge_class": "badge-warning",
            "reason": "Complete your profile details to get an exact eligibility verification."
        }

    branch = (profile.get("branch") or "").lower()
    year = (profile.get("academic_year") or "").lower()
    cgpa = profile.get("cgpa")
    eligibility_text = (opportunity.get("eligibility") or "").lower()

    branch_match = True
    year_match = True
    cgpa_match = True
    reasons = []

    # 1. Branch check
    tech_branches = ["cse", "computer science", "it", "information technology", "ai", "ds", "data science", "ece", "electronics"]
    pharma_branches = ["pharmd", "pharmacy", "b.pharm", "m.pharm", "biotechnology", "bioinformatics", "life sciences"]

    if any(b in eligibility_text for b in ["cse", "computer science", "it", "engineering", "b.tech", "be"]):
        if not any(b in branch for b in tech_branches) and "all" not in eligibility_text:
            branch_match = False
            reasons.append("requires Engineering/Computer Science background")

    if any(b in eligibility_text for b in ["pharmd", "pharmacy", "b.pharm", "healthcare", "medical"]):
        if not any(b in branch for b in pharma_branches) and "all" not in eligibility_text:
            branch_match = False
            reasons.append("requires Pharmacy/Healthcare/Life Sciences background")

    # 2. Year check
    if "final year" in eligibility_text or "4th year" in eligibility_text or "graduating" in eligibility_text:
        if not any(y in year for y in ["4th", "final", "4", "5th", "6th", "graduating", "pg"]):
            year_match = False
            reasons.append("requires final-year students")
    elif "1st" in eligibility_text or "2nd" in eligibility_text:
        if not any(y in year for y in ["1st", "2nd", "3rd", "1", "2", "3"]):
            year_match = False
            reasons.append("targeted at earlier academic years")

    # 3. CGPA check
    cgpa_match_pattern = re.search(r"cgpa[:\s]+(\d+(\.\d+)?)", eligibility_text)
    if cgpa_match_pattern:
        required_cgpa = float(cgpa_match_pattern.group(1))
        if cgpa and float(cgpa) < required_cgpa:
            cgpa_match = False
            reasons.append(f"requires minimum {required_cgpa} CGPA (your CGPA: {cgpa})")

    # Combine results
    if branch_match and year_match and cgpa_match:
        return {
            "status": "ELIGIBLE ✅",
            "badge_class": "badge-success",
            "reason": f"Eligible because your academic background ({profile.get('branch', 'Branch')}, {profile.get('academic_year', 'Year')}) meets the requirements."
        }
    elif branch_match and (not year_match or not cgpa_match):
        return {
            "status": "PARTIALLY ELIGIBLE ⚠️",
            "badge_class": "badge-warning",
            "reason": f"Partially eligible: {' and '.join(reasons)}."
        }
    else:
        return {
            "status": "NOT ELIGIBLE ❌",
            "badge_class": "badge-danger",
            "reason": f"Not eligible because this opportunity {' and '.join(reasons)}."
        }

def detect_skill_gaps(profile, opportunity):
    """
    Compares opportunity required skills against student skills, programming languages, and resume.
    """
    req_skills_raw = opportunity.get("required_skills") or ""
    required_skills = [s.strip() for s in req_skills_raw.replace(";", ",").split(",") if s.strip()]

    student_skills = profile.get("skills", []) if profile else []
    student_langs = profile.get("programming_languages", []) if profile else []
    resume_summary = (profile.get("resume_summary") or "").lower() if profile else ""
    student_all_skills = [s.strip().lower() for s in (student_skills + student_langs) if s]

    matched = []
    missing = []

    for req in required_skills:
        req_norm = req.lower().strip()
        is_matched = any(
            req_norm in s or s in req_norm or
            ("c++" in req_norm and "c++" in s) or
            ("c" == req_norm and "c" == s) or
            ("ml" in req_norm and "machine learning" in s) or
            ("ai" in req_norm and "artificial intelligence" in s)
            for s in student_all_skills
        ) or (req_norm in resume_summary)

        if is_matched:
            matched.append(req)
        else:
            missing.append(req)

    has_gap = len(missing) > 0
    if not student_all_skills and not resume_summary:
        warning_message = "No skills or resume added yet. Upload your resume or select skills to close this gap."
    elif has_gap:
        missing_str = ", ".join(missing)
        warning_message = f"You are missing {len(missing)} skill{'s' if len(missing) > 1 else ''}: {missing_str}."
    else:
        warning_message = "All required skills match your verified profile & resume perfectly! 🚀"

    return {
        "required_skills": required_skills,
        "matched_skills": matched,
        "missing_skills": missing,
        "has_gap": has_gap,
        "warning_message": warning_message,
        "can_create_learning_plan": len(missing) > 0
    }

def calculate_match_score(profile, opportunity):
    """
    Calculates personalized match score (0-100%).
    """
    if not profile:
        return {
            "score": 50,
            "breakdown": {"skills": 15, "max_skills": 40, "branch": 15, "max_branch": 25, "year": 10, "max_year": 20, "interest": 10, "max_interest": 15},
            "why_it_matches": "General opportunity matching based on campus profile."
        }

    skill_analysis = detect_skill_gaps(profile, opportunity)
    total_req = len(skill_analysis["required_skills"])
    total_matched = len(skill_analysis["matched_skills"])

    # 1. Skills Score (40 pts)
    if total_req == 0:
        skills_score = 40
    else:
        skills_score = round((total_matched / total_req) * 40)

    # 2. Branch Score (25 pts)
    eligibility_info = check_eligibility(profile, opportunity)
    if "ELIGIBLE ✅" in eligibility_info["status"]:
        branch_score = 25
        year_score = 20
    elif "PARTIALLY" in eligibility_info["status"]:
        branch_score = 18
        year_score = 12
    elif "EXPIRED" in eligibility_info["status"]:
        branch_score = 5
        year_score = 5
    else:
        branch_score = 8
        year_score = 5

    # 3. Interests / Career Goal / Location Score (15 pts)
    interest_score = 5
    career_goal = (profile.get("career_goal") or "").lower()
    interests = (profile.get("interests") or "").lower()
    pref_loc = (profile.get("preferred_location") or "").lower()

    opp_title = (opportunity.get("title") or "").lower()
    opp_desc = (opportunity.get("description") or "").lower()
    opp_loc = (opportunity.get("location") or "").lower()

    if career_goal and any(w in opp_title or w in opp_desc for w in career_goal.split() if len(w) > 3):
        interest_score += 4
    if interests and any(w in opp_title or w in opp_desc for w in interests.split() if len(w) > 3):
        interest_score += 3
    if pref_loc and (pref_loc in opp_loc or "remote" in opp_loc or "hybrid" in opp_loc):
        interest_score += 3

    interest_score = min(interest_score, 15)
    total_score = min(100, max(15, skills_score + branch_score + year_score + interest_score))

    # Generate why it matches text
    match_reasons = []
    if total_matched > 0:
        match_reasons.append(f"Matches your skills in {', '.join(skill_analysis['matched_skills'][:2])}")
    if profile.get("branch"):
        match_reasons.append(f"Fits {profile.get('branch')} curriculum")
    if career_goal and career_goal in opp_title:
        match_reasons.append(f"Aligns with your goal as {profile.get('career_goal')}")

    why_it_matches = " • ".join(match_reasons) if match_reasons else "Aligns with your student profile and college department."

    return {
        "score": total_score,
        "breakdown": {
            "skills": skills_score,
            "max_skills": 40,
            "branch": branch_score,
            "max_branch": 25,
            "year": year_score,
            "max_year": 20,
            "interest": interest_score,
            "max_interest": 15
        },
        "why_it_matches": why_it_matches
    }

def enrich_opportunity(opportunity, profile=None):
    """
    Enriches an opportunity with AI match score, eligibility checking, and skill gap detection.
    """
    opp = dict(opportunity)
    eligibility = check_eligibility(profile, opp)
    skill_gap = detect_skill_gaps(profile, opp)
    match_info = calculate_match_score(profile, opp)

    opp["eligibility_status"] = eligibility["status"]
    opp["eligibility_badge_class"] = eligibility["badge_class"]
    opp["eligibility_reason"] = eligibility["reason"]

    opp["skill_gap"] = skill_gap
    opp["match_score"] = match_info["score"]
    opp["match_breakdown"] = match_info["breakdown"]
    opp["why_it_matches"] = match_info["why_it_matches"]

    return opp

def ask_ai_advisor(profile, prompt, language="en", history=None):
    """
    Answers student questions in their preferred language (English, Telugu, Hindi)
    using OpenRouter LLM or localized intelligent heuristic assistant.
    """
    lang_name = "English"
    if language == "te":
        lang_name = "Telugu (తెలుగు)"
    elif language == "hi":
        lang_name = "Hindi (हिन्दी)"

    # 1. Check if OpenRouter is configured
    if Config.OPENROUTER_API_KEY:
        try:
            profile_context = f"""
Student Profile:
Name: {profile.get('name', 'Student')}
College: {profile.get('college_name', 'Not provided')}
Branch: {profile.get('branch', 'Not provided')}
Year: {profile.get('academic_year', 'Not provided')}
CGPA: {profile.get('cgpa', 'Not provided')}
Skills: {', '.join(profile.get('skills', []))}
Programming Languages: {', '.join(profile.get('programming_languages', []))}
Resume Summary: {profile.get('resume_summary', 'Not provided')}
Career Goal: {profile.get('career_goal', 'Not provided')}
Interests: {profile.get('interests', 'Not provided')}
Preferred Location: {profile.get('preferred_location', 'Not provided')}
Requested Response Language: {lang_name}
"""
            system_prompt = (
                f"You are the AI Campus Opportunity Agent, a warm, highly knowledgeable personal career and opportunity assistant for college students. "
                f"Use the student's stored profile and resume details to provide tailored, encouraging, and actionable guidance. "
                f"CRITICAL: Always reply in {lang_name}. If the user asked in Telugu or Hindi, respond naturally in authentic {lang_name}.\n{profile_context}"
            )
            messages = [{"role": "system", "content": system_prompt}]
            if history:
                for h in history[-4:]:
                    messages.append({"role": "user" if h.get("sender") == "user" else "assistant", "content": h.get("message", "")})
            messages.append({"role": "user", "content": prompt})

            resp = requests.post(
                f"{Config.OPENROUTER_BASE_URL}/chat/completions",
                headers={
                    "Authorization": f"Bearer {Config.OPENROUTER_API_KEY}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "http://localhost:5000",
                    "X-Title": "AI Campus Opportunity Agent"
                },
                json={
                    "model": Config.OPENROUTER_MODEL,
                    "messages": messages,
                    "max_tokens": 500
                },
                timeout=15
            )
            if resp.status_code == 200:
                data = resp.json()
                return data["choices"][0]["message"]["content"]
        except Exception:
            pass

    # 2. Intelligent Multilingual Heuristic Advisor
    p_name = profile.get("name", "Student") if profile else "Student"
    p_goal = profile.get("career_goal", "your chosen career") if profile else "your dream career"
    p_skills = profile.get("skills", []) if profile else []
    p_langs = profile.get("programming_languages", []) if profile else []
    p_branch = profile.get("branch", "Engineering") if profile else "Engineering"
    all_skills_str = ", ".join(p_skills + p_langs) if (p_skills or p_langs) else "Python, Java, SQL"
    p_lower = prompt.lower()

    # Telugu Responses
    if language == "te":
        if "internship" in p_lower or "best" in p_lower or "ఇంటర్న్‌షిప్" in p_lower:
            return (
                f"నమస్కారం {p_name}! మీ **{p_branch}** ప్రొఫైల్ మరియు **{p_goal}** లక్ష్యం ఆధారంగా, "
                f"మా లైవ్ ఇంటర్నెట్ సెర్చ్ ద్వారా సరిపోయే ఇంటర్న్‌షిప్‌లు కనుగొనబడ్డాయి. "
                f"మీ నైపుణ్యాలు: **{all_skills_str}**. గడువు ముగియకముందే దరఖాస్తు చేసుకోండి!"
            )
        elif "learn" in p_lower or "notes" in p_lower or "నేర్చుకోవాలి" in p_lower or "c" in p_lower or "python" in p_lower:
            return (
                f"{p_name}, మీరు ఎప్పుడైనా చదువుకోవడానికి **Python, Java మరియు C ప్రోగ్రామింగ్ నోట్స్** మా ఏజెంట్‌లో సిద్ధంగా ఉన్నాయి! "
                f"ఎడమ వైపు ఉన్న 'Programming Notes' మెనూ క్లిక్ చేసి ముఖ్యమైన కాన్సెప్ట్‌లు మరియు ఇంటర్వ్యూ కోడింగ్ సమస్యలు ప్రాక్టీస్ చేయండి."
            )
        elif "resume" in p_lower or "రెజ్యూమ్" in p_lower:
            return (
                f"మీ రెజ్యూమ్ విజయవంతంగా విశ్లేషించబడింది. మీరు మీ ప్రొఫైల్ పేజీలో స్కిల్స్ మరియు రికమండేషన్‌లను ఎప్పుడైనా చూడవచ్చు!"
            )
        else:
            return (
                f"నమస్కారం {p_name}! నేను మీ AI క్యాంపస్ ఆపర్చునిటీ ఏజెంట్‌ని. "
                f"ఇంటర్న్‌షిప్‌లు, స్కాలర్‌షిప్‌లు, కాలేజీ ఈవెంట్‌లు మరియు Python, Java, C నోట్స్ గురించి నన్ను ఏమైనా అడగండి!"
            )

    # Hindi Responses
    elif language == "hi":
        if "internship" in p_lower or "best" in p_lower or "इंटरर्नशिप" in p_lower:
            return (
                f"नमस्ते {p_name}! आपकी **{p_branch}** ब्रांच और **{p_goal}** के लक्ष्य के आधार पर, "
                f"लाइव इंटरनेट क्रॉलर द्वारा सबसे उपयुक्त इंटर्नशिप खोजी गई हैं। "
                f"आपके स्किल्स: **{all_skills_str}**। कृपया डेडलाइन खत्म होने से पहले अप्लाई करें!"
            )
        elif "learn" in p_lower or "notes" in p_lower or "सीखना" in p_lower:
            return (
                f"{p_name}, आप किसी भी समय अध्ययन करने के लिए **Python, Java और C प्रोग्रामिंग नोट्स** देख सकते हैं! "
                f"बाईं ओर 'Programming Notes' सेक्शन पर क्लिक करें और इंटरव्यू कोडिंग प्रश्नों का अभ्यास करें।"
            )
        elif "resume" in p_lower or "रिज्यूमे" in p_lower:
            return (
                f"आपका रिज्यूमे सफलतापूर्वक प्रोसेस किया गया है! आप अपने प्रोफाइल पेज पर एक्सट्रैक्ट किए गए स्किल्स और मैच स्कोर देख सकते हैं।"
            )
        else:
            return (
                f"नमस्ते {p_name}! मैं आपका AI कैंपस अपॉर्चुनिटी एजेंट हूँ। "
                f"इंटर्नशिप, स्कॉलरशिप, कॉलेज इवेंट्स और प्रोग्रामिंग नोट्स के बारे में मुझसे कभी भी पूछें!"
            )

    # English Default
    if "notes" in p_lower or "c program" in p_lower or "java" in p_lower or "python notes" in p_lower:
        return (
            f"Hello {p_name}! You can access our interactive **Python, Java, and C Programming Learning Notes** anytime from the sidebar. "
            f"Each language includes syntax cheatsheets, OOP/pointers concepts, code examples, and top 15 campus placement interview questions!"
        )
    elif "crawler" in p_lower or "internet" in p_lower or "event" in p_lower:
        return (
            f"Our **Automated Python Crawler** is actively searching the internet for latest internships, scholarships, and Saturday college symposiums/events! "
            f"Any opportunity with an expired deadline is automatically declared as expired, and new updates are sent directly to your registered contact number."
        )
    elif "resume" in p_lower:
        return (
            f"Your uploaded resume has been analyzed! I matched your skills ({all_skills_str}) against live opportunities and calculated personalized eligibility ratings."
        )
    elif "internship" in p_lower or "best" in p_lower:
        return (
            f"Based on your profile as a **{p_branch}** student targeting **{p_goal}**, I recommend looking at opportunities requiring **{all_skills_str}**. "
            f"Check the **Internships** tab on your left sidebar to view verified positions with high match scores. Make sure to close any missing skill gaps with a 7-day learning plan!"
        )
    else:
        return (
            f"Hello {p_name}! As your AI Campus Opportunity Agent, I am actively monitoring live internships, scholarships, hackathons, and college events matching your **{p_branch}** profile and **{p_goal}** goal. "
            f"You can explore Python/Java/C learning notes, review your resume insights, or switch languages to Telugu or Hindi anytime!"
        )
