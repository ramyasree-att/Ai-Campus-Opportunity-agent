import re
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db_connection
from services.profile_service import calculate_profile_completion, get_profile_by_user_id
from services.sms_service import send_contact_notification

def validate_registration_data(data):
    errors = []
    
    # Section 1: Personal Information
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    contact = (data.get("contact_number") or "").strip()
    father_name = (data.get("father_name") or "").strip()
    
    if not name:
        errors.append("Please enter your Full Name.")
    if not email:
        errors.append("Please enter your Email Address.")
    elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        errors.append("Please enter a valid email address.")
    if not contact:
        errors.append("Please enter your Contact Number.")
    elif len(re.sub(r"\D", "", contact)) < 7:
        errors.append("Please enter a valid contact number (at least 7-10 digits).")
    if not father_name:
        errors.append("Please enter your Father Name.")
        
    # Section 2: College Information
    college_name = (data.get("college_name") or "").strip()
    branch = (data.get("branch") or "").strip()
    academic_year = (data.get("academic_year") or "").strip()
    
    if not college_name:
        errors.append("Please enter your College Name.")
    if not branch:
        errors.append("Please select or enter your Branch / Department.")
    if not academic_year:
        errors.append("Please select your Academic Year.")
        
    # Section 5: Password
    password = data.get("password") or ""
    confirm_password = data.get("confirm_password") or ""
    
    if not password:
        errors.append("Please enter a Password.")
    elif len(password) < 6:
        errors.append("Password must be at least 6 characters long.")
    if password != confirm_password:
        errors.append("Passwords do not match.")
        
    return errors

def register_student(data, photo_filename=None, resume_filename=None, resume_summary=None):
    errors = validate_registration_data(data)
    if errors:
        return {"success": False, "errors": errors}
        
    email = (data.get("email") or "").strip().lower()
    password = data.get("password")
    password_hash = generate_password_hash(password)
    contact_number = (data.get("contact_number") or "").strip()
    preferred_language = data.get("preferred_language", "en")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if user already exists
    cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
    if cursor.fetchone():
        conn.close()
        return {"success": False, "errors": ["An account with this email address already exists. Please log in."]}
        
    try:
        # 1. Create User
        cursor.execute(
            "INSERT INTO users (email, password_hash, contact_number, auth_provider) VALUES (?, ?, ?, 'local')",
            (email, password_hash, contact_number)
        )
        user_id = cursor.lastrowid
        
        # 2. Extract CGPA safely
        cgpa_val = None
        raw_cgpa = data.get("cgpa")
        if raw_cgpa:
            try:
                cgpa_val = float(raw_cgpa)
            except (ValueError, TypeError):
                cgpa_val = None
                
        # 3. Create Student Profile automatically
        cursor.execute("""
        INSERT INTO profiles (
            user_id, name, profile_photo, college_name, contact_number,
            father_name, about_college, branch, academic_year, cgpa,
            career_goal, interests, preferred_location, preferred_opportunity_type,
            resume_filename, resume_summary, preferred_language
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            (data.get("name") or "").strip(),
            photo_filename,
            (data.get("college_name") or "").strip(),
            contact_number,
            (data.get("father_name") or "").strip(),
            (data.get("about_college") or "").strip(),
            (data.get("branch") or "").strip(),
            (data.get("academic_year") or "").strip(),
            cgpa_val,
            (data.get("career_goal") or "").strip(),
            (data.get("interests") or "").strip(),
            (data.get("preferred_location") or "").strip(),
            (data.get("preferred_opportunity_type") or "").strip(),
            resume_filename,
            resume_summary,
            preferred_language
        ))
        profile_id = cursor.lastrowid
        
        # 4. Insert Skills
        skills_input = data.get("skills", [])
        if isinstance(skills_input, str):
            skills_list = [s.strip() for s in skills_input.split(",") if s.strip()]
        else:
            skills_list = [str(s).strip() for s in skills_input if str(s).strip()]
            
        for skill in skills_list:
            if skill.lower() != "no skills added yet":
                cursor.execute("INSERT INTO skills (profile_id, skill_name) VALUES (?, ?)", (profile_id, skill))
                
        # 5. Insert Programming Languages
        langs_input = data.get("programming_languages", [])
        if isinstance(langs_input, str):
            langs_list = [l.strip() for l in langs_input.split(",") if l.strip()]
        else:
            langs_list = [str(l).strip() for l in langs_input if str(l).strip()]
            
        for lang in langs_list:
            if lang.lower() != "none" and lang.lower() != "no skills added yet":
                cursor.execute("INSERT INTO programming_languages (profile_id, language_name) VALUES (?, ?)", (profile_id, lang))
        
        # 6. Create initial Welcome In-App Notification
        cursor.execute("""
        INSERT INTO notifications (user_id, title, message, type, sent_to_contact, contact_number)
        VALUES (?, ?, ?, ?, 1, ?)
        """, (
            user_id,
            "Welcome to AI Campus Opportunity Agent! 🚀",
            "Your student profile and resume have been created. Live internet opportunity monitoring is now active.",
            "system",
            contact_number
        ))
        
        conn.commit()
        conn.close()

        # 7. Dispatch Welcome SMS to student's contact number
        welcome_sms = f"Welcome {data.get('name', 'Student')}! Your AI Campus Agent profile is registered. Live internship, scholarship, and event alerts will be sent here."
        send_contact_notification(user_id, contact_number, "Registration Confirmed 🎓", welcome_sms, "system")
        
        return {
            "success": True,
            "user_id": user_id,
            "name": (data.get("name") or "").strip(),
            "email": email,
            "message": "Account created successfully! 🎉 Your student profile has been created."
        }
    except Exception as e:
        conn.rollback()
        conn.close()
        return {"success": False, "errors": [f"Database error during registration: {str(e)}"]}

def authenticate_user(email, password):
    email = (email or "").strip().lower()
    if not email or not password:
        return {"success": False, "message": "Email and password are required."}
        
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, email, password_hash FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()
    
    if not user or not check_password_hash(user["password_hash"], password):
        return {"success": False, "message": "Invalid email address or password."}
        
    return {
        "success": True,
        "user_id": user["id"],
        "email": user["email"]
    }

def authenticate_google_user(email, name, google_id=None, avatar=None):
    """
    Authenticates a user via Google OAuth 2.0. If the student is new,
    automatically creates their user and student profile record with default college data.
    """
    email = (email or "").strip().lower()
    if not email:
        return {"success": False, "message": "Google email is required."}

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, email, contact_number FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()

    if user:
        user_id = user["id"]
        # Update google_id if missing
        if google_id:
            cursor.execute("UPDATE users SET google_id = ?, auth_provider = 'google' WHERE id = ?", (google_id, user_id))
            conn.commit()
        conn.close()
        profile = get_profile_by_user_id(user_id)
        return {
            "success": True,
            "is_new_user": False,
            "user_id": user_id,
            "email": email,
            "profile": profile,
            "message": f"Welcome back, {name or 'Student'}! Signed in via Google."
        }

    # Create new Google User
    dummy_password = generate_password_hash(f"google_oauth_{email}_{google_id or 'secret'}")
    cursor.execute("""
    INSERT INTO users (email, password_hash, contact_number, auth_provider, google_id)
    VALUES (?, ?, ?, 'google', ?)
    """, (email, dummy_password, "", google_id))
    user_id = cursor.lastrowid

    # Create default profile
    cursor.execute("""
    INSERT INTO profiles (
        user_id, name, profile_photo, college_name, branch, academic_year,
        career_goal, preferred_opportunity_type, preferred_language
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'en')
    """, (
        user_id,
        name or email.split("@")[0].title(),
        None,
        "University Campus",
        "Computer Science & Engineering (CSE)",
        "3rd Year",
        "AI Engineer",
        "Internships"
    ))
    profile_id = cursor.lastrowid

    # Default skills
    cursor.execute("INSERT INTO skills (profile_id, skill_name) VALUES (?, 'Problem Solving')", (profile_id,))
    cursor.execute("INSERT INTO programming_languages (profile_id, language_name) VALUES (?, 'Python')", (profile_id,))

    conn.commit()
    conn.close()

    full_profile = get_profile_by_user_id(user_id)
    return {
        "success": True,
        "is_new_user": True,
        "user_id": user_id,
        "email": email,
        "profile": full_profile,
        "message": f"Account created with Google! Welcome to Campus Opportunity Agent, {name}."
    }

def reset_password(user_id, current_password, new_password, confirm_new_password):
    if not new_password or len(new_password) < 6:
        return {"success": False, "message": "New password must be at least 6 characters long."}
    if new_password != confirm_new_password:
        return {"success": False, "message": "New passwords do not match."}
        
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT password_hash, auth_provider FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return {"success": False, "message": "User not found."}

    if user["auth_provider"] == "google":
        # Direct password set for google user
        pass
    elif not check_password_hash(user["password_hash"], current_password):
        conn.close()
        return {"success": False, "message": "Current password is incorrect."}
        
    new_hash = generate_password_hash(new_password)
    cursor.execute("UPDATE users SET password_hash = ? WHERE id = ?", (new_hash, user_id))
    conn.commit()
    conn.close()
    
    return {"success": True, "message": "Password updated successfully!"}
