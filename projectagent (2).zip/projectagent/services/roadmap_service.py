import json
from database import get_db_connection

DEFAULT_ROADMAPS = {
    "ai engineer": [
        {"stage": 1, "title": "Programming & CS Fundamentals", "description": "Master core Python syntax, algorithms, memory models, and Git version control.", "status": "completed", "skills": ["Python", "Git", "Data Structures"]},
        {"stage": 2, "title": "Mathematics & Data Manipulation", "description": "Linear algebra, calculus, probability, NumPy, Pandas, and data wrangling.", "status": "completed", "skills": ["Pandas", "NumPy", "Linear Algebra"]},
        {"stage": 3, "title": "Relational Databases & SQL", "description": "Relational schema design, complex query optimization, and data extraction pipelines.", "status": "current", "skills": ["SQL", "Database Design"]},
        {"stage": 4, "title": "Classical Machine Learning", "description": "Supervised & unsupervised algorithms, feature engineering, Scikit-Learn, and model metrics.", "status": "upcoming", "skills": ["Machine Learning", "Scikit-Learn"]},
        {"stage": 5, "title": "Deep Learning & Neural Networks", "description": "PyTorch / TensorFlow, Convolutional Neural Networks (CNN), and Transformers.", "status": "upcoming", "skills": ["TensorFlow", "PyTorch", "Deep Learning"]},
        {"stage": 6, "title": "Generative AI & LLM Systems", "description": "RAG architectures, LangChain, vector databases (Chroma/Pinecone), and prompt engineering.", "status": "upcoming", "skills": ["Generative AI", "LangChain", "Vector DB"]},
        {"stage": 7, "title": "Portfolio Projects & Hackathons", "description": "Deploy end-to-end AI applications on cloud and participate in national hackathons.", "status": "upcoming", "skills": ["Hackathons", "API Deployment"]},
        {"stage": 8, "title": "Internships & Placement Preparation", "description": "Complete research/industry internships, code interview prep, and system design.", "status": "upcoming", "skills": ["System Design", "Placements"]}
    ],
    "software developer": [
        {"stage": 1, "title": "Programming Fundamentals", "description": "Solidify object-oriented programming in Python, Java, or C++.", "status": "completed", "skills": ["Python", "Java", "OOP"]},
        {"stage": 2, "title": "Data Structures & Algorithms", "description": "Arrays, linked lists, trees, graphs, dynamic programming, and time complexity.", "status": "current", "skills": ["Data Structures", "Algorithms"]},
        {"stage": 3, "title": "Web Architecture & Frontend", "description": "HTML5, modern CSS, JavaScript (ES6+), and responsive UI design.", "status": "upcoming", "skills": ["JavaScript", "HTML", "CSS"]},
        {"stage": 4, "title": "Backend Engineering & REST APIs", "description": "Building scalable API services with Flask/FastAPI/Node.js and SQL databases.", "status": "upcoming", "skills": ["REST APIs", "SQL", "Backend"]},
        {"stage": 5, "title": "Full-Stack Project Development", "description": "Develop full-stack web applications with authentication, state management, and tests.", "status": "upcoming", "skills": ["Full Stack", "Testing"]},
        {"stage": 6, "title": "Campus Hackathons & Open Source", "description": "Collaborate in teams, build MVP prototypes, and contribute to GitHub projects.", "status": "upcoming", "skills": ["Git", "Teamwork"]},
        {"stage": 7, "title": "Internship Experience", "description": "Secure and complete a software development internship.", "status": "upcoming", "skills": ["Industry Experience"]},
        {"stage": 8, "title": "Campus Placement Mastery", "description": "Mock interviews, coding rounds, and technical HR presentations.", "status": "upcoming", "skills": ["Interviews", "Placements"]}
    ],
    "clinical researcher": [
        {"stage": 1, "title": "Medical & Pharmaceutical Foundations", "description": "Human anatomy, pharmacology, medicinal chemistry, and therapeutics.", "status": "completed", "skills": ["Pharmacology", "Therapeutics"]},
        {"stage": 2, "title": "Good Clinical Practice & Regulations", "description": "ICH-GCP guidelines, ethical approvals, informed consent, and regulatory norms.", "status": "current", "skills": ["Good Clinical Practice (GCP)", "Regulatory Ethics"]},
        {"stage": 3, "title": "Clinical Trial Protocols & Design", "description": "Phase I-IV trial frameworks, randomized control trials, and patient screening.", "status": "upcoming", "skills": ["Trial Protocol", "Patient Screening"]},
        {"stage": 4, "title": "Biostatistics & Health Data Analysis", "description": "Survival curves, epidemiological data processing, and statistical significance.", "status": "upcoming", "skills": ["Research", "Data Analysis", "Biostatistics"]},
        {"stage": 5, "title": "Pharmacovigilance & Safety Reporting", "description": "Adverse drug reaction reporting, causality algorithms, and risk management.", "status": "upcoming", "skills": ["Pharmacovigilance", "Safety Protocols"]},
        {"stage": 6, "title": "Clinical Case Studies & Hospital Rounds", "description": "Medication chart reviews, patient counseling, and therapeutic drug monitoring.", "status": "upcoming", "skills": ["Clinical Pharmacy", "Patient Care"]},
        {"stage": 7, "title": "Research Paper Publications & Workshops", "description": "Author research abstracts, present at healthcare conferences, and attend GCP seminars.", "status": "upcoming", "skills": ["Research Publications", "Conferences"]},
        {"stage": 8, "title": "Hospital / CRO Residency & Placements", "description": "Secure clinical research associate or clinical pharmacist placement.", "status": "upcoming", "skills": ["Clinical Residency", "Placements"]}
    ]
}

def generate_roadmap_for_goal(career_goal):
    norm_goal = career_goal.strip().lower()
    for key, stages in DEFAULT_ROADMAPS.items():
        if key in norm_goal or norm_goal in key:
            return json.loads(json.dumps(stages))

    # Dynamic fallback roadmap for custom career goals
    formatted_goal = career_goal.strip().title()
    return [
        {"stage": 1, "title": "Foundational Knowledge & Core Principles", "description": f"Master the baseline principles and key tools required for {formatted_goal}.", "status": "completed", "skills": ["Fundamentals", "Core Tools"]},
        {"stage": 2, "title": "Applied Skills & Technical Workflows", "description": f"Develop hands-on competence in daily workflows for {formatted_goal}.", "status": "current", "skills": ["Practical Operations", "Tooling"]},
        {"stage": 3, "title": "Intermediate Specialization", "description": f"Deep dive into advanced topics and industry standards for {formatted_goal}.", "status": "upcoming", "skills": ["Specialization", "Best Practices"]},
        {"stage": 4, "title": "Real-World Projects & Case Studies", "description": f"Build tangible showcase projects demonstrating expertise in {formatted_goal}.", "status": "upcoming", "skills": ["Portfolio Projects", "Documentation"]},
        {"stage": 5, "title": "Competitions, Workshops & Certifications", "description": "Gain recognized credentials, attend domain events, and participate in challenges.", "status": "upcoming", "skills": ["Certifications", "Networking"]},
        {"stage": 6, "title": "Internships & Industry Immersion", "description": "Apply skills in professional internships and live workplace environments.", "status": "upcoming", "skills": ["Internships", "Industry Collaboration"]},
        {"stage": 7, "title": "Professional Placements & Career Launch", "description": f"Target full-time opportunities and technical interviews as a {formatted_goal}.", "status": "upcoming", "skills": ["Interviews", "Career Placements"]}
    ]

def get_or_create_roadmap(user_id, career_goal):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM career_roadmaps WHERE user_id = ?", (user_id,))
    existing = cursor.fetchone()

    if existing:
        roadmap = dict(existing)
        roadmap["stages"] = json.loads(roadmap["stages_json"])
        conn.close()
        return roadmap

    stages = generate_roadmap_for_goal(career_goal or "Software Developer")
    cursor.execute("""
    INSERT INTO career_roadmaps (user_id, career_goal, stages_json, current_stage)
    VALUES (?, ?, ?, 2)
    """, (user_id, career_goal or "Software Developer", json.dumps(stages)))

    new_id = cursor.lastrowid
    conn.commit()

    cursor.execute("SELECT * FROM career_roadmaps WHERE id = ?", (new_id,))
    new_roadmap = dict(cursor.fetchone())
    new_roadmap["stages"] = json.loads(new_roadmap["stages_json"])
    conn.close()

    return new_roadmap

def update_roadmap_stage(user_id, current_stage):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM career_roadmaps WHERE user_id = ?", (user_id,))
    existing = cursor.fetchone()
    if not existing:
        conn.close()
        return {"success": False, "message": "Roadmap not found."}

    stages = json.loads(existing["stages_json"])
    stage_num = int(current_stage)

    for s in stages:
        if s["stage"] < stage_num:
            s["status"] = "completed"
        elif s["stage"] == stage_num:
            s["status"] = "current"
        else:
            s["status"] = "upcoming"

    cursor.execute("""
    UPDATE career_roadmaps SET stages_json = ?, current_stage = ? WHERE id = ?
    """, (json.dumps(stages), stage_num, existing["id"]))

    conn.commit()
    conn.close()

    return {
        "success": True,
        "current_stage": stage_num,
        "stages": stages
    }
