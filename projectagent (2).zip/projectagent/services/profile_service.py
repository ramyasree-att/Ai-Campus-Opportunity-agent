import os
from database import get_db_connection

def calculate_profile_completion(profile, skills, languages):
    """
    Calculates profile completion percentage and identifies missing fields with constructive AI guidance.
    """
    score = 0
    missing = []

    # 1. Full Name (10%)
    if profile.get("name") and str(profile["name"]).strip():
        score += 10
    else:
        missing.append("Full Name")

    # 2. Contact & Email (10%)
    if profile.get("contact_number") and str(profile["contact_number"]).strip():
        score += 10
    else:
        missing.append("Contact Number")

    # 3. Father Name (5%)
    if profile.get("father_name") and str(profile["father_name"]).strip():
        score += 5
    else:
        missing.append("Father Name")

    # 4. College Name (10%)
    if profile.get("college_name") and str(profile["college_name"]).strip():
        score += 10
    else:
        missing.append("College Name")

    # 5. Branch / Department (10%)
    if profile.get("branch") and str(profile["branch"]).strip():
        score += 10
    else:
        missing.append("Branch / Department")

    # 6. Academic Year (10%)
    if profile.get("academic_year") and str(profile["academic_year"]).strip():
        score += 10
    else:
        missing.append("Academic Year")

    # 7. CGPA / Percentage (10%)
    if profile.get("cgpa") is not None and str(profile["cgpa"]).strip() and float(profile.get("cgpa") or 0) > 0:
        score += 10
    else:
        missing.append("CGPA / Percentage")

    # 8. Skills (10%)
    if skills and len(skills) > 0:
        score += 10
    else:
        missing.append("Skills")

    # 9. Programming Languages (10%)
    if languages and len(languages) > 0:
        score += 10
    else:
        missing.append("Programming Languages")

    # 10. Career Goal & Interests (5%)
    if profile.get("career_goal") and str(profile["career_goal"]).strip():
        score += 5
    else:
        missing.append("Career Goal")

    # 11. Resume Upload (10%)
    if profile.get("resume_filename") and str(profile["resume_filename"]).strip():
        score += 10
    else:
        missing.append("Resume Upload (PDF/DOCX)")

    # AI Guidance message
    if score == 100:
        ai_guidance = "Awesome! Your profile & resume are 100% complete. The AI agent can maximize opportunity matching accuracy."
    elif score >= 75:
        ai_guidance = "Your profile is in great shape! Completing the remaining fields helps me find even more accurate opportunities for you."
    elif not skills:
        ai_guidance = "No skills have been added yet. Upload your resume or select skills to immediately boost match scoring."
    else:
        ai_guidance = "Completing your profile and uploading your resume helps me find verified opportunities and calculate precise eligibility for you."

    return {
        "percentage": min(score, 100),
        "missing_fields": missing,
        "is_complete": len(missing) == 0,
        "ai_guidance": ai_guidance
    }

def get_profile_by_user_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    # User basic info
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    if not user:
        conn.close()
        return None

    # Profile info
    cursor.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
    profile_row = cursor.fetchone()

    if not profile_row:
        conn.close()
        return {
            "user_id": user_id,
            "email": user["email"],
            "contact_number": user["contact_number"],
            "auth_provider": user["auth_provider"],
            "role": user["role"] if "role" in user.keys() and user["role"] else "USER",
            "skills": [],
            "programming_languages": [],
            "preferred_language": user["preferred_language"] if "preferred_language" in user.keys() and user["preferred_language"] else "en",
            "completion": calculate_profile_completion({}, [], [])
        }

    profile = dict(profile_row)
    profile_id = profile["id"]

    # Fetch skills
    cursor.execute("SELECT skill_name FROM skills WHERE profile_id = ?", (profile_id,))
    skills = [row["skill_name"] for row in cursor.fetchall()]

    # Fetch programming languages
    cursor.execute("SELECT language_name FROM programming_languages WHERE profile_id = ?", (profile_id,))
    languages = [row["language_name"] for row in cursor.fetchall()]

    conn.close()

    profile["email"] = user["email"]
    profile["auth_provider"] = user["auth_provider"]
    profile["role"] = user["role"] if "role" in user.keys() and user["role"] else "USER"
    profile["skills"] = skills
    profile["programming_languages"] = languages
    profile["completion"] = calculate_profile_completion(profile, skills, languages)

    return profile

def update_profile(user_id, data, photo_filename=None, resume_filename=None, resume_summary=None):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM profiles WHERE user_id = ?", (user_id,))
    profile_row = cursor.fetchone()
    if not profile_row:
        conn.close()
        return {"success": False, "message": "Profile not found."}

    profile_id = profile_row["id"]

    existing_prof = dict(profile_row)

    # Parse CGPA safely
    cgpa_val = None
    if "cgpa" in data:
        raw_cgpa = data.get("cgpa")
        if raw_cgpa is not None and str(raw_cgpa).strip() != "":
            try:
                cgpa_val = float(raw_cgpa)
            except (ValueError, TypeError):
                cgpa_val = None

    # Use existing values if key not in data
    new_name = (data.get("name") if "name" in data else existing_prof.get("name") or "").strip()
    new_college = (data.get("college_name") if "college_name" in data else existing_prof.get("college_name") or "").strip()
    new_contact = (data.get("contact_number") if "contact_number" in data else existing_prof.get("contact_number") or "").strip()
    new_father = (data.get("father_name") if "father_name" in data else existing_prof.get("father_name") or "").strip()
    new_about = (data.get("about_college") if "about_college" in data else existing_prof.get("about_college") or "").strip()
    new_branch = (data.get("branch") if "branch" in data else existing_prof.get("branch") or "").strip()
    new_year = (data.get("academic_year") if "academic_year" in data else existing_prof.get("academic_year") or "").strip()
    new_goal = (data.get("career_goal") if "career_goal" in data else existing_prof.get("career_goal") or "").strip()
    new_interests = (data.get("interests") if "interests" in data else existing_prof.get("interests") or "").strip()
    new_loc = (data.get("preferred_location") if "preferred_location" in data else existing_prof.get("preferred_location") or "").strip()
    new_opp_type = (data.get("preferred_opportunity_type") if "preferred_opportunity_type" in data else existing_prof.get("preferred_opportunity_type") or "").strip()
    new_lang = data.get("preferred_language") if "preferred_language" in data else existing_prof.get("preferred_language", "en")

    # Update base fields
    cursor.execute("""
    UPDATE profiles SET
        name = ?,
        college_name = ?,
        contact_number = ?,
        father_name = ?,
        about_college = ?,
        branch = ?,
        academic_year = ?,
        cgpa = ?,
        career_goal = ?,
        interests = ?,
        preferred_location = ?,
        preferred_opportunity_type = ?,
        preferred_language = ?,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
    """, (
        new_name,
        new_college,
        new_contact,
        new_father,
        new_about,
        new_branch,
        new_year,
        cgpa_val if cgpa_val is not None else existing_prof.get("cgpa"),
        new_goal,
        new_interests,
        new_loc,
        new_opp_type,
        new_lang,
        profile_id
    ))

    # Update photo if provided
    if photo_filename:
        cursor.execute("UPDATE profiles SET profile_photo = ? WHERE id = ?", (photo_filename, profile_id))

    # Update resume if provided
    if resume_filename:
        cursor.execute("UPDATE profiles SET resume_filename = ? WHERE id = ?", (resume_filename, profile_id))
    if resume_summary:
        cursor.execute("UPDATE profiles SET resume_summary = ? WHERE id = ?", (resume_summary, profile_id))

    # Update user contact_number
    if data.get("contact_number"):
        cursor.execute("UPDATE users SET contact_number = ? WHERE id = ?", (data.get("contact_number").strip(), user_id))

    # Replace Skills
    if "skills" in data:
        cursor.execute("DELETE FROM skills WHERE profile_id = ?", (profile_id,))
        skills_input = data.get("skills", [])
        if isinstance(skills_input, str):
            skills_list = [s.strip() for s in skills_input.split(",") if s.strip()]
        else:
            skills_list = [str(s).strip() for s in skills_input if str(s).strip()]
        for skill in skills_list:
            if skill.lower() != "no skills added yet":
                cursor.execute("INSERT INTO skills (profile_id, skill_name) VALUES (?, ?)", (profile_id, skill))

    # Replace Programming Languages
    if "programming_languages" in data:
        cursor.execute("DELETE FROM programming_languages WHERE profile_id = ?", (profile_id,))
        langs_input = data.get("programming_languages", [])
        if isinstance(langs_input, str):
            langs_list = [l.strip() for l in langs_input.split(",") if l.strip()]
        else:
            langs_list = [str(l).strip() for l in langs_input if str(l).strip()]
        for lang in langs_list:
            if lang.lower() != "none" and lang.lower() != "no skills added yet":
                cursor.execute("INSERT INTO programming_languages (profile_id, language_name) VALUES (?, ?)", (profile_id, lang))

    conn.commit()
    conn.close()

    updated_profile = get_profile_by_user_id(user_id)
    return {
        "success": True,
        "message": "Profile updated successfully! ✅",
        "profile": updated_profile
    }

def update_user_language_preference(user_id, lang_code):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE profiles SET preferred_language = ? WHERE user_id = ?", (lang_code, user_id))
    conn.commit()
    conn.close()
    return {"success": True, "preferred_language": lang_code}
