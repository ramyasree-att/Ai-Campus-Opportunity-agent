"""
Resume Intelligence Analyzer.
Extracts technical and soft skills, scores resume quality, provides actionable improvement tips,
and persists parsed resume profiles into SQLite.
"""
import json
import re
from datetime import datetime
from database.db import get_db_connection
from resume.parser import parse_resume_document

TECHNICAL_SKILLS = [
    # Programming Languages
    "Python", "Java", "C", "C++", "C#", "JavaScript", "TypeScript", "Go", "Rust", "Kotlin", "Swift", "PHP", "Ruby", "R", "SQL",
    # Frameworks & Libraries
    "React", "Angular", "Vue.js", "Node.js", "Express.js", "Django", "Flask", "FastAPI", "Spring Boot", "ASP.NET",
    "TensorFlow", "PyTorch", "Keras", "Scikit-Learn", "Pandas", "NumPy", "OpenCV", "TailwindCSS", "Bootstrap",
    # Databases
    "PostgreSQL", "MySQL", "MongoDB", "SQLite", "Redis", "Oracle", "Cassandra", "DynamoDB",
    # Cloud & DevOps
    "AWS", "Azure", "GCP", "Docker", "Kubernetes", "Linux", "Git", "GitHub", "GitLab", "CI/CD", "Terraform",
    # Domains
    "Machine Learning", "Deep Learning", "Data Science", "Artificial Intelligence", "Natural Language Processing", "NLP",
    "Computer Vision", "Cybersecurity", "Blockchain", "REST API", "GraphQL", "Microservices", "System Design",
    "Data Structures", "Algorithms", "Object-Oriented Programming", "OOP",
    # Pharmacy & Healthcare (Telangana / Pharma domain support)
    "Pharmacology", "Clinical Pharmacy", "Pharmacovigilance", "Good Clinical Practice", "GCP", "Biostatistics",
    "Medical Writing", "Clinical Trials", "Regulatory Affairs", "Pharmaceutics"
]

SOFT_SKILLS = [
    "Communication", "Leadership", "Teamwork", "Problem Solving", "Critical Thinking",
    "Time Management", "Adaptability", "Collaboration", "Agile", "Scrum", "Presentation"
]

def extract_skills(text: str) -> dict:
    """
    Scans resume text against comprehensive skill taxonomies with word boundary precision.
    """
    text_lower = text.lower()
    found_tech = []
    found_soft = []
    programming_langs = []

    core_langs = {"python", "java", "c", "c++", "c#", "javascript", "typescript", "go", "rust", "kotlin", "swift", "php", "ruby", "r", "sql"}

    for skill in TECHNICAL_SKILLS:
        skill_lower = skill.lower()
        # Word boundary pattern
        pattern = r"(?:^|[\s,;./()\-\[\]{}])" + re.escape(skill_lower) + r"(?:$|[\s,;./()\-\[\]{}])"
        if re.search(pattern, text_lower):
            if skill_lower in core_langs and skill not in programming_langs:
                programming_langs.append(skill)
            elif skill not in found_tech:
                found_tech.append(skill)

    for skill in SOFT_SKILLS:
        skill_lower = skill.lower()
        pattern = r"(?:^|[\s,;./()\-\[\]{}])" + re.escape(skill_lower) + r"(?:$|[\s,;./()\-\[\]{}])"
        if re.search(pattern, text_lower):
            if skill not in found_soft:
                found_soft.append(skill)

    all_technical = programming_langs + found_tech

    return {
        "programming_languages": programming_langs,
        "technical_skills": found_tech,
        "soft_skills": found_soft,
        "all_skills": all_technical + found_soft
    }

def calculate_resume_score(text: str, skills_data: dict, contact_info: dict, academics: dict) -> tuple[int, list]:
    """
    Calculates a 0-100 quality score and generates suggestions for improvement.
    """
    score = 0
    suggestions = []

    # 1. Contact completeness (Max 20 pts)
    contact_pts = 0
    if contact_info.get("email"):
        contact_pts += 5
    else:
        suggestions.append("Add a professional email address at the top of your resume.")

    if contact_info.get("phone"):
        contact_pts += 5
    else:
        suggestions.append("Add a reachable 10-digit mobile number.")

    if contact_info.get("github") or contact_info.get("portfolio"):
        contact_pts += 5
    else:
        suggestions.append("Include links to your GitHub profile or live project portfolio.")

    if contact_info.get("linkedin"):
        contact_pts += 5
    else:
        suggestions.append("Add your LinkedIn profile link to improve recruiter discoverability.")

    score += contact_pts

    # 2. Technical Skills breadth & depth (Max 35 pts)
    tech_count = len(skills_data.get("programming_languages", [])) + len(skills_data.get("technical_skills", []))
    if tech_count >= 8:
        score += 35
    elif tech_count >= 5:
        score += 25
        suggestions.append("Add 2-3 more specific technical frameworks or developer tools you have experience with.")
    elif tech_count >= 2:
        score += 15
        suggestions.append("Expand your Technical Skills section with specific languages, databases, and frameworks.")
    else:
        score += 5
        suggestions.append("Highlight core programming languages (e.g., Python, Java, SQL) and technical proficiencies.")

    # 3. Soft Skills & Methodologies (Max 10 pts)
    soft_count = len(skills_data.get("soft_skills", []))
    if soft_count >= 3:
        score += 10
    elif soft_count >= 1:
        score += 5
    else:
        suggestions.append("Mention collaboration, problem solving, or agile methodologies in your experience/project descriptions.")

    # 4. Academics / CGPA (Max 15 pts)
    if academics.get("cgpa") or academics.get("percentage"):
        score += 15
    else:
        suggestions.append("Clearly state your current CGPA, percentage, and graduation year under Education.")

    # 5. Content Length & Substantial Detail (Max 20 pts)
    word_count = len(text.split())
    if word_count >= 250:
        score += 20
    elif word_count >= 150:
        score += 12
        suggestions.append("Add more detail to your project descriptions: include the problem solved, tech stack used, and measurable results.")
    else:
        score += 5
        suggestions.append("Your resume appears brief. Detail your academic projects, internships, hackathons, and certifications.")

    score = max(0, min(100, score))
    if not suggestions:
        suggestions.append("Excellent resume structure! Keep updating it with your latest projects and certifications.")

    return score, suggestions

def analyze_resume(file_path: str, target_career_goal: str = "") -> dict:
    """
    Parses and conducts full AI-ready analysis of a resume document.
    """
    doc = parse_resume_document(file_path)
    skills = extract_skills(doc["text"])
    score, suggestions = calculate_resume_score(
        text=doc["text"],
        skills_data=skills,
        contact_info={"email": doc["email"], "phone": doc["phone"], "linkedin": doc["linkedin"], "github": doc["github"], "portfolio": doc["portfolio"]},
        academics={"cgpa": doc["cgpa"], "percentage": doc["percentage"]}
    )

    summary = (
        f"Resume parsed successfully! Identified {len(skills['all_skills'])} key skills including "
        f"{', '.join(skills['all_skills'][:5]) if skills['all_skills'] else 'general competencies'}. "
        f"Overall Resume Strength Score: {score}/100."
    )

    return {
        "success": True,
        "file_path": file_path,
        "email": doc["email"],
        "phone": doc["phone"],
        "linkedin": doc["linkedin"],
        "github": doc["github"],
        "portfolio": doc["portfolio"],
        "cgpa": doc["cgpa"],
        "percentage": doc["percentage"],
        "programming_languages": skills["programming_languages"],
        "technical_skills": skills["technical_skills"],
        "soft_skills": skills["soft_skills"],
        "all_skills": skills["all_skills"],
        "resume_score": score,
        "suggestions": suggestions,
        "summary": summary,
        "raw_text_snippet": doc["text"][:500] + ("..." if len(doc["text"]) > 500 else "")
    }

def save_resume_analysis(user_id: int, file_path: str, analysis: dict) -> int:
    """
    Persists parsed resume metadata and score into the SQLite `resumes` table.
    """
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        skills_json = json.dumps(analysis.get("all_skills", []))
        suggestions_json = json.dumps(analysis.get("suggestions", []))
        education_data = json.dumps({
            "cgpa": analysis.get("cgpa"),
            "percentage": analysis.get("percentage")
        })

        cursor.execute(
            """
            INSERT INTO resumes (
                user_id, file_path, raw_text, parsed_skills, parsed_education,
                score, suggestions_json, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                file_path,
                analysis.get("raw_text_snippet", ""),
                skills_json,
                education_data,
                analysis.get("resume_score", 0),
                suggestions_json,
                datetime.utcnow().isoformat(),
                datetime.utcnow().isoformat()
            )
        )
        resume_id = cursor.lastrowid

        # Update user's profile skills and resume_url if not already filled
        cursor.execute("SELECT skills, resume_url FROM users WHERE id = ?", (user_id,))
        u = cursor.fetchone()
        if u:
            existing_skills = u["skills"] or ""
            new_skills = list(set([s.strip() for s in existing_skills.split(",") if s.strip()] + analysis.get("all_skills", [])))
            cursor.execute(
                "UPDATE users SET skills = ?, resume_url = ?, updated_at = ? WHERE id = ?",
                (", ".join(new_skills), file_path, datetime.utcnow().isoformat(), user_id)
            )

        conn.commit()
        return resume_id
    finally:
        conn.close()
