"""
Resume text and section parser.
Extracts raw text and identifies key sections from PDF, DOCX, and TXT resume files.
"""
import os
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from pypdf import PdfReader

def extract_text_from_file(file_path: str) -> str:
    """
    Safely extracts plain text from PDF, DOCX, or TXT without altering the original file.
    """
    p = Path(file_path)
    if not p.exists():
        return ""

    ext = p.suffix.lower()
    text = ""

    if ext == ".pdf":
        try:
            reader = PdfReader(str(file_path))
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
        except Exception as e:
            text = f"[PDF Extraction Note: {str(e)}]"
    elif ext in [".docx", ".doc"]:
        try:
            # Modern docx is a zip file with word/document.xml
            if zipfile.is_zipfile(str(file_path)):
                with zipfile.ZipFile(str(file_path)) as docx_zip:
                    xml_content = docx_zip.read("word/document.xml")
                    tree = ET.fromstring(xml_content)
                    paragraphs = []
                    # Word XML namespace tag is {http://schemas.openxmlformats.org/wordprocessingml/2006/main}p or similar
                    for node in tree.iter():
                        if node.tag.endswith("t") and node.text:
                            paragraphs.append(node.text)
                    text = " ".join(paragraphs)
            else:
                # Binary fallback
                with open(file_path, "rb") as f:
                    raw = f.read()
                    clean = re.sub(rb"[^\x20-\x7E\n\r\t]", b" ", raw)
                    text = clean.decode("utf-8", errors="ignore")
        except Exception as e:
            text = f"[DOCX Extraction Note: {str(e)}]"
    elif ext in [".txt", ".md", ".rtf"]:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception as e:
            text = f"[Text Extraction Note: {str(e)}]"
    else:
        # Generic fallback
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            text = ""

    return text.strip()


def extract_contact_info(text: str) -> dict:
    """
    Extracts email, phone, and links (GitHub, LinkedIn, Portfolio) from resume text.
    """
    # Email
    email_match = re.search(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", text)
    email = email_match.group(0) if email_match else ""

    # Phone (Indian format +91 or 10 digits or formatted)
    phone_match = re.search(r"(?:\+?91[\s-]?)?[6-9]\d{9}|\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", text)
    phone = phone_match.group(0) if phone_match else ""

    # Links
    linkedin_match = re.search(r"(?:https?://)?(?:www\.)?linkedin\.com/in/[\w\-]+", text, re.IGNORECASE)
    github_match = re.search(r"(?:https?://)?(?:www\.)?github\.com/[\w\-]+", text, re.IGNORECASE)
    portfolio_match = re.search(r"(?:https?://)(?:[\w\-]+\.)+[\w\-]+(?:/[\w\-./?%&=]*)?", text, re.IGNORECASE)

    return {
        "email": email,
        "phone": phone,
        "linkedin": linkedin_match.group(0) if linkedin_match else "",
        "github": github_match.group(0) if github_match else "",
        "portfolio": portfolio_match.group(0) if portfolio_match else ""
    }


def extract_cgpa_percentage(text: str) -> dict:
    """
    Extracts CGPA (on 10 or 4 scale) or percentage from resume text.
    """
    cgpa = None
    percentage = None

    # CGPA patterns
    cgpa_matches = re.findall(r"(?:cgpa|gpa|grade point average)[:\s]*([0-9]+(?:\.[0-9]+)?)(?:\s*/\s*(?:10|4))?", text, re.IGNORECASE)
    if cgpa_matches:
        try:
            val = float(cgpa_matches[0])
            if 0 <= val <= 10.0:
                cgpa = val
        except ValueError:
            pass

    # Percentage patterns
    pct_matches = re.findall(r"(?:percentage|aggregate|marks)[:\s]*([0-9]+(?:\.[0-9]+)?)\s*%", text, re.IGNORECASE)
    if pct_matches:
        try:
            val = float(pct_matches[0])
            if 0 <= val <= 100.0:
                percentage = val
        except ValueError:
            pass

    return {
        "cgpa": cgpa,
        "percentage": percentage
    }


def parse_resume_document(file_path: str) -> dict:
    """
    Master parser that returns raw text, contact information, education metrics, and raw sections.
    """
    text = extract_text_from_file(file_path)
    contact = extract_contact_info(text)
    academics = extract_cgpa_percentage(text)

    return {
        "file_path": file_path,
        "text": text,
        "email": contact["email"],
        "phone": contact["phone"],
        "linkedin": contact["linkedin"],
        "github": contact["github"],
        "portfolio": contact["portfolio"],
        "cgpa": academics["cgpa"],
        "percentage": academics["percentage"]
    }
