/**
 * Programming Notes & Cheatsheets Controller (Python, Java, C)
 * Interactive code examples, interview prep, and topic filtering
 */

const NotesState = {
  currentLang: 'python',
  allNotes: {},
  searchQuery: ''
};

async function loadProgrammingNotes(language = 'python') {
  NotesState.currentLang = language;
  const container = document.getElementById('notesContentContainer');
  if (!container) return;

  // Highlight active language tab
  document.querySelectorAll('.notes-lang-tab').forEach(tab => {
    if (tab.getAttribute('data-lang') === language) {
      tab.classList.add('active');
    } else {
      tab.classList.remove('active');
    }
  });

  container.innerHTML = `<div style="text-align:center;padding:3rem;color:var(--text-muted);">Loading ${language.toUpperCase()} notes... ⏳</div>`;

  try {
    const res = await fetch(`/api/notes/${language}`);
    const data = await res.json();

    if (data.success && data.note) {
      NotesState.allNotes[language] = data.note;
      renderNotesUI(data.note);
    } else {
      container.innerHTML = `<div style="color:var(--danger);text-align:center;padding:2rem;">Could not load notes for ${language}.</div>`;
    }
  } catch (err) {
    console.error('Error loading notes:', err);
    container.innerHTML = `<div style="color:var(--danger);text-align:center;padding:2rem;">Failed to fetch notes.</div>`;
  }
}

function renderNotesUI(note) {
  const container = document.getElementById('notesContentContainer');
  if (!container) return;

  const cheatsheet = note.cheatsheet || [];
  const topics = note.topics || [];

  // Filter topics by search if present
  const query = NotesState.searchQuery.toLowerCase().trim();
  const filteredTopics = query ? topics.filter(t => t.title.toLowerCase().includes(query) || t.content.toLowerCase().includes(query)) : topics;

  let cheatsheetHtml = '';
  if (cheatsheet.length > 0) {
    cheatsheetHtml = `
      <div class="card" style="margin-bottom:1.5rem;background:var(--bg-input);border-color:var(--border-highlight);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem;">
          <h3 style="color:#fff;font-size:1.1rem;display:flex;align-items:center;gap:0.5rem;">
            <span>⚡ ${note.language} Quick Cheatsheet</span>
          </h3>
          <span class="badge badge-info">Quick Reference</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));gap:0.75rem;">
          ${cheatsheet.map(c => `
            <div style="background:var(--bg-surface);padding:0.75rem 1rem;border-radius:var(--radius-sm);border:1px solid var(--border-color);">
              <code style="color:#38bdf8;font-size:0.825rem;font-weight:700;display:block;margin-bottom:0.25rem;">${escapeHtml(c.command)}</code>
              <span style="color:var(--text-muted);font-size:0.75rem;">${c.desc}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  let topicsHtml = '';
  if (filteredTopics.length === 0) {
    topicsHtml = `
      <div style="text-align:center;padding:3rem;color:var(--text-muted);">
        No topics matched "${NotesState.searchQuery}". Try a different keyword.
      </div>
    `;
  } else {
    topicsHtml = filteredTopics.map(t => `
      <div class="card note-topic-card" id="${t.id}" style="margin-bottom:1.5rem;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;border-bottom:1px solid var(--border-color);padding-bottom:0.75rem;">
          <h3 style="color:#fff;font-size:1.2rem;">${t.title}</h3>
          <button class="btn btn-sm btn-secondary" onclick="askAiAboutTopic('${note.language}', '${t.title}')" title="Ask AI Advisor about this topic">
            🤖 Ask AI Advisor
          </button>
        </div>
        <div class="note-markdown-body" style="font-size:0.9rem;line-height:1.6;color:var(--text-main);">
          ${formatMarkdownToHtml(t.content)}
        </div>
      </div>
    `).join('');
  }

  container.innerHTML = `
    <!-- Header Banner -->
    <div class="greeting-banner" style="margin-bottom:1.5rem;">
      <div>
        <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.25rem;">
          <span style="font-size:1.75rem;">${note.icon}</span>
          <h1 style="color:#fff;font-size:1.5rem;">${note.language} Programming Notes</h1>
        </div>
        <p style="color:var(--text-main);max-width:700px;">${note.overview}</p>
      </div>
      <div style="text-align:right;">
        <span class="badge badge-success" style="font-size:0.85rem;padding:0.4rem 0.8rem;">${note.topics.length} Chapters • Interview Ready 🎯</span>
      </div>
    </div>

    ${cheatsheetHtml}

    <!-- Topics Content -->
    ${topicsHtml}
  `;
}

function askAiAboutTopic(language, topicTitle) {
  const currentLangCode = (AppState.profile && AppState.profile.preferred_language) || 'en';
  let prompt = `Explain key concept and give top interview tips for ${language}: ${topicTitle}`;
  if (currentLangCode === 'te') {
    prompt = `${language} లో ఈ కాన్సెప్ట్ గురించి వివరించండి మరియు ముఖ్యమైన ఇంటర్వ్యూ చిట్కాలు ఇవ్వండి: ${topicTitle}`;
  } else if (currentLangCode === 'hi') {
    prompt = `${language} में इस कॉन्सेप्ट को समझाएं और इंटरव्यू टिप्स दें: ${topicTitle}`;
  }

  if (window.openAiChatDrawer) window.openAiChatDrawer();
  if (window.sendAiAdvisorMessage) window.sendAiAdvisorMessage(prompt);
}

function copyCodeSnippet(btn) {
  const codeBlock = btn.closest('.code-snippet-box').querySelector('code');
  if (codeBlock) {
    navigator.clipboard.writeText(codeBlock.innerText).then(() => {
      btn.textContent = 'Copied! ✅';
      setTimeout(() => { btn.textContent = 'Copy 📋'; }, 2000);
    });
  }
}

function formatMarkdownToHtml(md) {
  if (!md) return '';
  let html = md;

  // Code blocks ```lang ... ```
  html = html.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
    return `
      <div class="code-snippet-box">
        <div class="code-snippet-header">
          <span>${lang ? lang.toUpperCase() : 'CODE'}</span>
          <button class="btn btn-sm btn-icon" onclick="copyCodeSnippet(this)" style="font-size:0.75rem;padding:0.2rem 0.6rem;">Copy 📋</button>
        </div>
        <pre><code class="language-${lang || 'text'}">${escapeHtml(code.trim())}</code></pre>
      </div>
    `;
  });

  // Inline code `code`
  html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');

  // Headings
  html = html.replace(/^#### (.*$)/gim, '<h5 style="color:#fff;margin-top:1rem;margin-bottom:0.5rem;">$1</h5>');
  html = html.replace(/^### (.*$)/gim, '<h4 style="color:#38bdf8;margin-top:1.25rem;margin-bottom:0.5rem;">$1</h4>');
  html = html.replace(/^## (.*$)/gim, '<h3 style="color:#fff;margin-top:1.5rem;margin-bottom:0.75rem;">$1</h3>');

  // Bold & Italic
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');

  // Lists
  html = html.replace(/^\s*-\s+(.*$)/gim, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');

  // Paragraphs
  html = html.replace(/\n\n/g, '<br><br>');

  return html;
}

function escapeHtml(text) {
  return (text || '').replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function initNotesSearch() {
  const searchInput = document.getElementById('notesSearchInput');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      NotesState.searchQuery = e.target.value;
      if (NotesState.allNotes[NotesState.currentLang]) {
        renderNotesUI(NotesState.allNotes[NotesState.currentLang]);
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', initNotesSearch);

window.loadProgrammingNotes = loadProgrammingNotes;
window.askAiAboutTopic = askAiAboutTopic;
window.copyCodeSnippet = copyCodeSnippet;
