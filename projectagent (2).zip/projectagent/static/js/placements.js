/**
 * College Placements, Live Website Scanner & College Hackathons Management
 */

const PlacementsState = {
  colleges: [],
  selectedCollege: null,
  currentPlacements: null,
  currentHackathons: []
};

// Initialize Placements View
async function initPlacementsView() {
  await loadTelanganaCollegesList();
  
  // Set default college from student's profile if available
  const userCollege = AppState.profile?.college_name;
  if (userCollege) {
    const matched = PlacementsState.colleges.find(c => 
      c.name.toLowerCase().includes(userCollege.toLowerCase()) || 
      userCollege.toLowerCase().includes(c.name.toLowerCase())
    );
    if (matched) {
      PlacementsState.selectedCollege = matched.name;
    }
  }

  if (!PlacementsState.selectedCollege && PlacementsState.colleges.length > 0) {
    PlacementsState.selectedCollege = PlacementsState.colleges[0].name;
  }

  const selector = document.getElementById('placementCollegeSelect');
  if (selector && PlacementsState.selectedCollege) {
    selector.value = PlacementsState.selectedCollege;
  }

  await loadCollegePlacements(PlacementsState.selectedCollege);
}

// Load List of 60+ Telangana Colleges
async function loadTelanganaCollegesList() {
  try {
    const res = await fetch('/api/colleges');
    const data = await res.json();
    if (data.success) {
      PlacementsState.colleges = data.colleges;
      populateCollegeDropdowns(data.colleges);
    }
  } catch (err) {
    console.error('Error loading colleges:', err);
  }
}

function populateCollegeDropdowns(colleges) {
  const placementSelect = document.getElementById('placementCollegeSelect');
  const regSelect = document.getElementById('regCollegeName');
  const editSelect = document.getElementById('editCollegeName');

  const optionsHtml = colleges.map(c => 
    `<option value="${c.name}">${c.name} (${c.code || c.district})</option>`
  ).join('');

  if (placementSelect) {
    placementSelect.innerHTML = `<option value="">-- Choose Telangana College --</option>` + optionsHtml;
  }
  if (regSelect) {
    regSelect.innerHTML = `<option value="">-- Select Telangana College --</option>` + optionsHtml;
  }
  if (editSelect) {
    editSelect.innerHTML = `<option value="">-- Select Telangana College --</option>` + optionsHtml;
  }
}

// Load Placement Stats, Top Recruiters, and Drives for Selected College
async function loadCollegePlacements(collegeName) {
  if (!collegeName) return;
  PlacementsState.selectedCollege = collegeName;

  const container = document.getElementById('placementContentContainer');
  if (!container) return;

  container.innerHTML = `
    <div style="text-align:center;padding:3rem;color:var(--text-muted);">
      <div class="spinner" style="margin:0 auto 1rem;"></div>
      <div>Fetching placement statistics, recruiters & live drives for ${collegeName}...</div>
    </div>
  `;

  try {
    const res = await fetch(`/api/colleges/${encodeURIComponent(collegeName)}/placements`);
    const data = await res.json();

    if (data.success && data.placements) {
      PlacementsState.currentPlacements = data.placements;
      renderPlacementsUI(data.placements);
      loadCollegeHackathons(collegeName);
    } else {
      container.innerHTML = `<div class="card" style="text-align:center;padding:2rem;">No placement data found for this college.</div>`;
    }
  } catch (err) {
    container.innerHTML = `<div class="card" style="color:#ef4444;padding:2rem;">Failed to load placement records.</div>`;
  }
}

// Render Placements UI
function renderPlacementsUI(placements) {
  const container = document.getElementById('placementContentContainer');
  if (!container) return;

  const col = placements.college;
  const stats = placements.stats;
  const recruiters = placements.top_recruiters || [];
  const drives = placements.active_drives || [];

  const recruiterChipsHtml = recruiters.map(r => 
    `<span class="chip-tag selected" style="cursor:default;font-weight:600;">🏢 ${r}</span>`
  ).join('');

  const drivesHtml = drives.map(d => `
    <div class="card" style="margin-bottom:1rem;border-left:4px solid #38bdf8;background:rgba(15,23,42,0.6);">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:0.75rem;margin-bottom:0.5rem;">
        <div>
          <h4 style="color:#fff;font-size:1.05rem;margin:0 0 0.25rem 0;">${d.company}</h4>
          <div style="font-size:0.85rem;color:var(--secondary);font-weight:600;">${d.role}</div>
        </div>
        <span class="badge badge-success">${d.status}</span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));gap:0.5rem;font-size:0.85rem;color:var(--text-main);margin:0.75rem 0;">
        <div><strong style="color:var(--text-subtle);">CTC / Package:</strong> <span style="color:#38bdf8;font-weight:700;">${d.ctc}</span></div>
        <div><strong style="color:var(--text-subtle);">Drive Date:</strong> ${d.drive_date}</div>
        <div><strong style="color:var(--text-subtle);">Type:</strong> ${d.type}</div>
        <div><strong style="color:var(--text-subtle);">Location:</strong> ${d.location}</div>
      </div>
      <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:0.75rem;">
        <strong>Eligibility:</strong> ${d.eligibility}
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;">
        <span style="font-size:0.75rem;color:var(--text-muted);">Verified On-Campus Placement Drive</span>
        <a href="${d.apply_url}" target="_blank" class="btn btn-sm btn-primary">
          <span>Apply Drive 🚀</span>
        </a>
      </div>
    </div>
  `).join('');

  container.innerHTML = `
    <!-- College Header Summary -->
    <div class="card" style="margin-bottom:1.5rem;background:linear-gradient(135deg, rgba(30,27,75,0.7) 0%, rgba(15,23,42,0.85) 100%);border-color:rgba(99,102,241,0.4);">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:1rem;">
        <div>
          <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.35rem;">
            <h2 style="color:#fff;font-size:1.35rem;margin:0;">${col.name}</h2>
            <span class="badge badge-primary">${col.code || 'TS-ENG'}</span>
          </div>
          <div style="font-size:0.875rem;color:var(--text-muted);">
            📍 ${col.location || 'Telangana'} • <span style="color:#38bdf8;">${col.type || 'Engineering College'}</span> • <strong>${col.nirf_rank || 'State Tier'}</strong>
          </div>
        </div>
        <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
          <a href="${col.website_url}" target="_blank" class="btn btn-sm btn-secondary">
            <span>Official Website 🌐</span>
          </a>
          <button class="btn btn-sm btn-primary" onclick="triggerCollegeWebsiteScanner('${col.name.replace(/'/g, "\\'")}')">
            <span>Scan Official Site Live 🔍</span>
          </button>
        </div>
      </div>
    </div>

    <!-- 4 Placement Metrics Stat Cards Grid -->
    <div class="stats-grid" style="margin-bottom:1.5rem;">
      <div class="stat-card">
        <div class="stat-icon-wrapper" style="background:rgba(16,185,129,0.15);color:#10b981;">💰</div>
        <div>
          <div class="stat-value" style="color:#10b981;">₹${stats.highest_package_lpa} LPA</div>
          <div class="stat-label">Highest Placement Package</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon-wrapper" style="background:rgba(56,189,248,0.15);color:#38bdf8;">📈</div>
        <div>
          <div class="stat-value" style="color:#38bdf8;">₹${stats.average_package_lpa} LPA</div>
          <div class="stat-label">Average CTC</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon-wrapper" style="background:rgba(99,102,241,0.15);color:#6366f1;">🎯</div>
        <div>
          <div class="stat-value" style="color:#6366f1;">${stats.placement_rate_pct}%</div>
          <div class="stat-label">Placement Rate</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon-wrapper" style="background:rgba(245,158,11,0.15);color:#f59e0b;">📦</div>
        <div>
          <div class="stat-value" style="color:#f59e0b;">${stats.total_offers}+</div>
          <div class="stat-label">Total Placement Offers</div>
        </div>
      </div>
    </div>

    <!-- Live Website Inspection Scanner Container (Dynamic Mount) -->
    <div id="collegeWebsiteScanResultContainer"></div>

    <!-- Top Recruiting Companies Showcase -->
    <div class="card" style="margin-bottom:1.5rem;">
      <h3 style="color:#fff;font-size:1.15rem;margin-bottom:0.75rem;display:flex;align-items:center;gap:0.5rem;">
        <span>🏢 Top Recruiting Companies at ${col.code || 'College'}</span>
      </h3>
      <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:1rem;">
        Major MNCs, product enterprises, and startups actively recruiting from campus.
      </p>
      <div style="display:flex;flex-wrap:wrap;gap:0.5rem;">
        ${recruiterChipsHtml}
      </div>
    </div>

    <!-- Active On-Campus & Pool Placement Drives -->
    <div class="card" style="margin-bottom:1.5rem;">
      <div class="flex-between" style="margin-bottom:1rem;">
        <div>
          <h3 style="color:#fff;font-size:1.15rem;margin:0;">🎯 Active & Upcoming Placement Drives</h3>
          <p style="font-size:0.85rem;color:var(--text-muted);margin:0.25rem 0 0 0;">
            Scheduled hiring drives, online assessments, and interview schedules.
          </p>
        </div>
        <span class="badge badge-info">${drives.length} Drives Active</span>
      </div>
      <div>
        ${drivesHtml}
      </div>
    </div>

    <!-- Hackathons & Saturday Events at Selected College -->
    <div class="card">
      <div class="flex-between" style="margin-bottom:1rem;">
        <div>
          <h3 style="color:#fff;font-size:1.15rem;margin:0;">⚡ College Hackathons & Saturday Events</h3>
          <p style="font-size:0.85rem;color:var(--text-muted);margin:0.25rem 0 0 0;">
            Coding sprints, project expos, and symposiums hosted at ${col.name}.
          </p>
        </div>
      </div>
      <div id="collegeHackathonsListContainer">
        <div style="text-align:center;padding:1.5rem;color:var(--text-muted);">Loading college events & hackathons... ⏳</div>
      </div>
    </div>
  `;
}

// Live College Website Scanner Trigger
async function triggerCollegeWebsiteScanner(collegeName) {
  const mount = document.getElementById('collegeWebsiteScanResultContainer');
  if (!mount) return;

  mount.innerHTML = `
    <div class="card" style="margin-bottom:1.5rem;border-color:#38bdf8;background:rgba(56,189,248,0.08);">
      <div style="display:flex;align-items:center;gap:0.75rem;">
        <div class="spinner" style="width:24px;height:24px;"></div>
        <div>
          <strong style="color:#fff;">Connecting Python Live Crawler to official college website...</strong>
          <div style="font-size:0.8rem;color:var(--text-muted);">Inspecting active placement cell pages, recruiter notices, and NIRF statistics...</div>
        </div>
      </div>
    </div>
  `;

  try {
    const res = await fetch('/api/colleges/inspect-website', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ college_name: collegeName })
    });
    const result = await res.json();

    if (result.success) {
      const announcementsHtml = (result.live_announcements || []).map(a => 
        `<li style="margin-bottom:0.4rem;color:var(--text-main);">${a}</li>`
      ).join('');

      mount.innerHTML = `
        <div class="card" style="margin-bottom:1.5rem;border-color:#10b981;background:rgba(16,185,129,0.06);">
          <div class="flex-between" style="margin-bottom:0.75rem;">
            <div style="display:flex;align-items:center;gap:0.5rem;">
              <span style="font-size:1.3rem;">🌐</span>
              <div>
                <strong style="color:#fff;font-size:1.05rem;">Live Official Website Scan Results</strong>
                <div style="font-size:0.78rem;color:#10b981;">${result.portal_status} • Scanned at ${result.scanned_at}</div>
              </div>
            </div>
            <a href="${result.website_url}" target="_blank" class="btn btn-sm btn-secondary">Visit Site ↗</a>
          </div>
          <div style="font-size:0.85rem;margin-bottom:0.75rem;">
            <strong style="color:var(--text-subtle);">Verified Portal Page:</strong> <span style="color:#fff;">${result.live_page_title}</span>
          </div>
          <div style="font-size:0.85rem;margin-bottom:0.5rem;">
            <strong style="color:var(--text-subtle);">Live Placement Announcements & Bulletins:</strong>
          </div>
          <ul style="font-size:0.85rem;padding-left:1.25rem;margin:0 0 0.75rem 0;">
            ${announcementsHtml}
          </ul>
        </div>
      `;
      showToast('success', 'Website Scanned! 🌐', `Live placement announcements fetched for ${collegeName}.`);
    } else {
      mount.innerHTML = `<div class="card" style="color:#ef4444;padding:1rem;">Could not inspect college website.</div>`;
    }
  } catch (err) {
    mount.innerHTML = `<div class="card" style="color:#ef4444;padding:1rem;">Network error inspecting college portal.</div>`;
  }
}

// Load College Specific Hackathons
async function loadCollegeHackathons(collegeName) {
  const listContainer = document.getElementById('collegeHackathonsListContainer');
  if (!listContainer) return;

  try {
    const res = await fetch(`/api/colleges/${encodeURIComponent(collegeName)}/hackathons`);
    const data = await res.json();

    if (data.success && data.hackathons && data.hackathons.length > 0) {
      PlacementsState.currentHackathons = data.hackathons;
      listContainer.innerHTML = data.hackathons.map(h => `
        <div style="background:var(--bg-surface);border:1px solid var(--border-color);border-radius:var(--radius-sm);padding:1rem;margin-bottom:0.75rem;">
          <div class="flex-between" style="margin-bottom:0.35rem;">
            <strong style="color:#fff;font-size:0.95rem;">${h.title}</strong>
            <span class="badge badge-warning">Saturday Event ⚡</span>
          </div>
          <div style="font-size:0.825rem;color:var(--text-muted);margin-bottom:0.5rem;">
            📅 ${h.dates} • 👥 Team: ${h.team_size} • 📍 ${h.mode}
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;">
            <span style="font-size:0.85rem;color:#10b981;font-weight:700;">🏆 ${h.prize_pool}</span>
            <a href="${h.registration_url}" target="_blank" class="btn btn-sm btn-secondary">
              <span>Register Event →</span>
            </a>
          </div>
        </div>
      `).join('');
    } else {
      listContainer.innerHTML = `<div style="text-align:center;padding:1rem;color:var(--text-muted);">No upcoming hackathons found for this college.</div>`;
    }
  } catch (err) {
    listContainer.innerHTML = `<div style="color:#ef4444;padding:1rem;">Error loading hackathons.</div>`;
  }
}

window.initPlacementsView = initPlacementsView;
window.loadCollegePlacements = loadCollegePlacements;
window.triggerCollegeWebsiteScanner = triggerCollegeWebsiteScanner;
