/**
 * Dashboard Controller - Greeting, Proactive Alerts, Stats & Recommended Opportunities
 */

async function loadDashboard() {
  if (!AppState.user) return;

  try {
    const res = await fetch('/api/dashboard/stats');
    const data = await res.json();

    if (data.success) {
      // 1. Greeting Banner
      const greetingName = document.getElementById('dashStudentName');
      if (greetingName) {
        greetingName.textContent = data.student_name || 'Student';
      }

      // 2. Stat Counts
      const matchCountEl = document.getElementById('dashStatMatchCount');
      const deadlineCountEl = document.getElementById('dashStatDeadlineCount');
      const expiredCountEl = document.getElementById('dashStatExpiredCount');
      const appCountEl = document.getElementById('dashStatAppCount');
      const skillGapCountEl = document.getElementById('dashStatSkillGapCount');

      if (matchCountEl) matchCountEl.textContent = data.counts.matching_opportunities;
      if (deadlineCountEl) deadlineCountEl.textContent = data.counts.urgent_deadlines;
      if (expiredCountEl) expiredCountEl.textContent = data.counts.expired_deadlines || 0;
      if (appCountEl) appCountEl.textContent = data.counts.total_applications;
      if (skillGapCountEl) skillGapCountEl.textContent = data.counts.skill_gaps;

      // 3. Profile Completion Widget
      const comp = data.profile_completion || { percentage: 0, missing_fields: [] };
      const compPercentEl = document.getElementById('dashCompPercent');
      const compBarEl = document.getElementById('dashCompBar');
      const compMissingEl = document.getElementById('dashCompMissing');

      if (compPercentEl) compPercentEl.textContent = `${comp.percentage}%`;
      if (compBarEl) compBarEl.style.width = `${comp.percentage}%`;
      if (compMissingEl) {
        if (comp.missing_fields && comp.missing_fields.length > 0) {
          compMissingEl.textContent = `Missing: ${comp.missing_fields.slice(0, 2).join(', ')}`;
        } else {
          compMissingEl.textContent = `Profile & Resume 100% Complete ✨`;
        }
      }

      // 4. Proactive AI Alert Banners
      renderProactiveAlerts(data.proactive_alerts || []);

      // 5. Load Top Recommended Opportunities
      loadRecommendedOpportunities();
    }
  } catch (err) {
    console.error('Error loading dashboard stats:', err);
  }
}

function renderProactiveAlerts(alerts) {
  const container = document.getElementById('dashProactiveAlertsContainer');
  if (!container) return;

  if (!alerts || alerts.length === 0) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = alerts.map(alert => `
    <div class="proactive-alert-box">
      <div class="proactive-alert-left">
        <div class="proactive-alert-icon">${alert.icon}</div>
        <div>
          <div style="font-weight:700;color:#fff;font-size:0.95rem;margin-bottom:0.2rem;">${alert.title}</div>
          <div style="font-size:0.85rem;color:var(--text-muted);">${alert.message}</div>
        </div>
      </div>
      <div>
        <button class="btn btn-sm btn-primary" onclick="navigateTo('${alert.action_target}')">
          ${alert.action_text} →
        </button>
      </div>
    </div>
  `).join('');
}

async function loadRecommendedOpportunities() {
  const container = document.getElementById('dashRecommendedGrid');
  if (!container) return;

  try {
    const res = await fetch('/api/opportunities?sort_by=best_match');
    const data = await res.json();

    if (data.success && data.opportunities.length > 0) {
      const top3 = data.opportunities.slice(0, 3);
      container.innerHTML = top3.map(opp => window.renderOpportunityCardHtml ? window.renderOpportunityCardHtml(opp) : '').join('');
    } else {
      container.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:2rem;color:var(--text-muted);">No recommendations available yet.</div>`;
    }
  } catch (err) {
    console.error('Error loading recommended opportunities:', err);
  }
}

window.loadDashboard = loadDashboard;
