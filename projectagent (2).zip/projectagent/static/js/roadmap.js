/**
 * Career Roadmap Visualization & Stage Milestone Progression
 */

async function loadCareerRoadmap() {
  const container = document.getElementById('careerRoadmapContainer');
  const goalTitle = document.getElementById('roadmapCareerGoalTitle');
  if (!container) return;

  container.innerHTML = `<div style="text-align:center;padding:3rem;color:var(--text-muted);">Loading career roadmap... ⏳</div>`;

  try {
    const res = await fetch('/api/career-roadmap');
    const data = await res.json();

    if (data.success) {
      const rm = data.roadmap;
      if (goalTitle) goalTitle.textContent = rm.career_goal || 'Career Progression';

      const stages = rm.stages || [];
      const currentStage = rm.current_stage || 1;

      container.innerHTML = `
        <div class="roadmap-timeline">
          ${stages.map(s => {
            const isCompleted = s.stage < currentStage;
            const isCurrent = s.stage === currentStage;
            const statusClass = isCompleted ? 'completed' : (isCurrent ? 'current' : 'upcoming');
            const statusBadge = isCompleted 
              ? `<span class="badge badge-success">Completed Stage ✅</span>`
              : (isCurrent 
                  ? `<span class="badge badge-warning" style="animation:pulseVoice 2s infinite;">Current Focus 🔥</span>`
                  : `<span class="badge badge-neutral">Upcoming Stage</span>`);

            return `
              <div class="roadmap-node ${statusClass}" onclick="setRoadmapActiveStage(${s.stage})" style="cursor:pointer;">
                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;margin-bottom:0.5rem;">
                  <div style="display:flex;align-items:center;gap:0.75rem;">
                    <span style="font-weight:800;color:var(--primary);font-size:1.1rem;">#${s.stage}</span>
                    <h3 style="color:#fff;font-size:1.15rem;">${s.title}</h3>
                  </div>
                  ${statusBadge}
                </div>

                <p style="font-size:0.875rem;color:var(--text-muted);margin-bottom:0.75rem;line-height:1.5;">
                  ${s.description}
                </p>

                <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
                  <span style="font-size:0.75rem;color:var(--text-subtle);font-weight:700;">KEY COMPETENCIES:</span>
                  ${(s.skills || []).map(sk => `<span class="badge badge-neutral" style="font-size:0.75rem;">${sk}</span>`).join(' ')}
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    }
  } catch (err) {
    console.error('Error loading roadmap:', err);
    container.innerHTML = `<div style="color:var(--danger);text-align:center;">Failed to load career roadmap.</div>`;
  }
}

async function setRoadmapActiveStage(stageNum) {
  try {
    const res = await fetch('/api/career-roadmap/stage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stage: stageNum })
    });
    const result = await res.json();
    if (result.success) {
      showToast('info', 'Roadmap Updated', `Current focus stage set to #${stageNum}.`);
      loadCareerRoadmap();
    }
  } catch (err) {
    showToast('error', 'Error', 'Could not update active stage.');
  }
}

window.loadCareerRoadmap = loadCareerRoadmap;
window.setRoadmapActiveStage = setRoadmapActiveStage;
