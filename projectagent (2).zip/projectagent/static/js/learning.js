/**
 * 7-Day Fast-Track Learning Plans & Interactive Daily Checklist Progress
 */

async function loadLearningPlans() {
  const container = document.getElementById('learningPlansContainer');
  if (!container) return;

  container.innerHTML = `<div style="text-align:center;padding:3rem;color:var(--text-muted);">Loading learning plans... ⏳</div>`;

  try {
    const res = await fetch('/api/learning-plans');
    const data = await res.json();

    if (data.success) {
      if (data.plans.length === 0) {
        container.innerHTML = `
          <div style="text-align:center;padding:4rem;background:var(--bg-surface-elevated);border-radius:var(--radius-md);">
            <div style="font-size:2.5rem;margin-bottom:0.5rem;">📚</div>
            <h3 style="color:#fff;margin-bottom:0.5rem;">No Active Learning Plans Yet</h3>
            <p style="color:var(--text-muted);margin-bottom:1.5rem;">Generate a structured 7-day plan below to close any detected skill gaps.</p>
            <div style="display:flex;gap:0.75rem;justify-content:center;flex-wrap:wrap;">
              <button class="btn btn-secondary" onclick="generateLearningPlanForSkill('Python')">Python (7 Days)</button>
              <button class="btn btn-secondary" onclick="generateLearningPlanForSkill('SQL')">SQL (7 Days)</button>
              <button class="btn btn-secondary" onclick="generateLearningPlanForSkill('Java')">Java (7 Days)</button>
              <button class="btn btn-secondary" onclick="generateLearningPlanForSkill('Machine Learning')">Machine Learning (7 Days)</button>
              <button class="btn btn-secondary" onclick="generateLearningPlanForSkill('Clinical Pharmacy')">Clinical Pharmacy (7 Days)</button>
            </div>
          </div>
        `;
        return;
      }

      container.innerHTML = data.plans.map(plan => renderLearningPlanCard(plan)).join('');
    }
  } catch (err) {
    console.error('Error fetching learning plans:', err);
    container.innerHTML = `<div style="color:var(--danger);text-align:center;">Failed to load learning plans.</div>`;
  }
}

function renderLearningPlanCard(plan) {
  const days = plan.plan_json || [];
  const progress = plan.progress_percentage || 0;

  return `
    <div class="learning-plan-card" id="plan-card-${plan.id}">
      <div style="padding:1.5rem;border-bottom:1px solid var(--border-color);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
        <div>
          <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.25rem;">
            <h3 style="color:#fff;font-size:1.2rem;">${plan.title}</h3>
            <span class="badge badge-info">7-DAY PLAN</span>
          </div>
          <p style="font-size:0.85rem;color:var(--text-muted);">Practical daily syllabus with hands-on coding & interview preparation.</p>
        </div>

        <div style="min-width:200px;text-align:right;">
          <div style="display:flex;justify-content:space-between;font-size:0.85rem;font-weight:700;margin-bottom:0.35rem;">
            <span style="color:var(--text-subtle);">Progress</span>
            <span style="color:#38bdf8;" id="plan-pct-${plan.id}">${progress}%</span>
          </div>
          <div style="background:var(--bg-input);height:8px;border-radius:var(--radius-full);overflow:hidden;">
            <div id="plan-bar-${plan.id}" style="width:${progress}%;height:100%;background:var(--accent-gradient);transition:width 0.3s ease;"></div>
          </div>
        </div>
      </div>

      <div class="learning-days-list">
        ${days.map(d => `
          <div class="learning-day-row">
            <div class="learning-day-left">
              <input type="checkbox" class="day-checkbox" ${d.completed ? 'checked' : ''} onchange="toggleDayCheckbox(${plan.id}, ${d.day}, this.checked)">
              <div>
                <div style="font-weight:700;color:${d.completed ? 'var(--text-subtle)' : '#fff'};font-size:0.9rem;${d.completed ? 'text-decoration:line-through;' : ''}">
                  Day ${d.day}: ${d.topic}
                </div>
                <div style="font-size:0.8rem;color:var(--text-muted);margin-top:0.15rem;">
                  ${d.details}
                </div>
              </div>
            </div>
            <div>
              ${d.completed ? '<span class="badge badge-success">Done ✅</span>' : '<span class="badge badge-neutral">Pending</span>'}
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

async function generateLearningPlanForSkill(skillName) {
  if (!skillName) return;
  try {
    const res = await fetch('/api/learning-plans/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ skill_name: skillName })
    });
    const result = await res.json();

    if (result.success) {
      showToast('success', 'Plan Generated! 📚', `7-Day learning plan for ${skillName} is ready.`);
      navigateTo('learning_plans');
    } else {
      showToast('error', 'Error', result.message || 'Could not generate plan.');
    }
  } catch (err) {
    showToast('error', 'Server Error', 'Failed to generate learning plan.');
  }
}

async function toggleDayCheckbox(planId, dayNum, isChecked) {
  try {
    const res = await fetch(`/api/learning-plans/${planId}/update-day`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ day: dayNum, completed: isChecked })
    });
    const result = await res.json();

    if (result.success) {
      const pctEl = document.getElementById(`plan-pct-${planId}`);
      const barEl = document.getElementById(`plan-bar-${planId}`);
      if (pctEl) pctEl.textContent = `${result.progress_percentage}%`;
      if (barEl) barEl.style.width = `${result.progress_percentage}%`;

      if (result.progress_percentage === 100) {
        showToast('success', 'Mastery Achieved! 🏆', `You completed all 7 days of this learning plan!`);
      }
    }
  } catch (err) {
    showToast('error', 'Error', 'Could not save day progress.');
  }
}

window.loadLearningPlans = loadLearningPlans;
window.generateLearningPlanForSkill = generateLearningPlanForSkill;
window.toggleDayCheckbox = toggleDayCheckbox;
