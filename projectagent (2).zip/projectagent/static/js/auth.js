/**
 * Student Registration, Authentication, Profile Management, Resume Parsing & Google OAuth
 */

const AuthState = {
  selectedLanguages: new Set(),
  selectedSkills: new Set(),
  uploadedPhotoFile: null,
  uploadedResumeFile: null,
  noSkillsSelected: false
};

// ==========================================
// REGISTRATION INITIALIZATION & CHIP SELECTORS
// ==========================================
function initRegistrationForm() {
  const regForm = document.getElementById('studentRegistrationForm');
  if (!regForm) return;

  // Language Chips Click
  document.querySelectorAll('#regLangChips .chip-tag').forEach(chip => {
    chip.addEventListener('click', () => {
      const val = chip.getAttribute('data-value');
      if (val === 'No skills added yet') {
        AuthState.selectedLanguages.clear();
        document.querySelectorAll('#regLangChips .chip-tag').forEach(c => c.classList.remove('selected'));
        chip.classList.add('selected');
        AuthState.selectedLanguages.add(val);
      } else {
        const noSkillChip = document.querySelector('#regLangChips .chip-tag[data-value="No skills added yet"]');
        if (noSkillChip) {
          noSkillChip.classList.remove('selected');
          AuthState.selectedLanguages.delete('No skills added yet');
        }
        if (AuthState.selectedLanguages.has(val)) {
          AuthState.selectedLanguages.delete(val);
          chip.classList.remove('selected');
        } else {
          AuthState.selectedLanguages.add(val);
          chip.classList.add('selected');
        }
      }
    });
  });

  // Skill Chips Click
  document.querySelectorAll('#regSkillChips .chip-tag').forEach(chip => {
    chip.addEventListener('click', () => {
      const val = chip.getAttribute('data-value');
      if (val === 'No skills added yet') {
        AuthState.selectedSkills.clear();
        document.querySelectorAll('#regSkillChips .chip-tag').forEach(c => c.classList.remove('selected'));
        chip.classList.add('selected');
        AuthState.selectedSkills.add(val);
      } else {
        const noSkillChip = document.querySelector('#regSkillChips .chip-tag[data-value="No skills added yet"]');
        if (noSkillChip) {
          noSkillChip.classList.remove('selected');
          AuthState.selectedSkills.delete('No skills added yet');
        }
        if (AuthState.selectedSkills.has(val)) {
          AuthState.selectedSkills.delete(val);
          chip.classList.remove('selected');
        } else {
          AuthState.selectedSkills.add(val);
          chip.classList.add('selected');
        }
      }
    });
  });

  // Custom Language Add Button
  const addCustomLangBtn = document.getElementById('addCustomLangBtn');
  const customLangInput = document.getElementById('customLangInput');
  if (addCustomLangBtn && customLangInput) {
    addCustomLangBtn.addEventListener('click', () => {
      const val = customLangInput.value.trim();
      if (val && !AuthState.selectedLanguages.has(val)) {
        AuthState.selectedLanguages.add(val);
        const container = document.getElementById('regLangChips');
        const newChip = document.createElement('span');
        newChip.className = 'chip-tag selected';
        newChip.setAttribute('data-value', val);
        newChip.textContent = `+ ${val}`;
        newChip.addEventListener('click', () => {
          if (AuthState.selectedLanguages.has(val)) {
            AuthState.selectedLanguages.delete(val);
            newChip.remove();
          }
        });
        container.appendChild(newChip);
        customLangInput.value = '';
      }
    });
  }

  // Custom Skill Add Button
  const addCustomSkillBtn = document.getElementById('addCustomSkillBtn');
  const customSkillInput = document.getElementById('customSkillInput');
  if (addCustomSkillBtn && customSkillInput) {
    addCustomSkillBtn.addEventListener('click', () => {
      const val = customSkillInput.value.trim();
      if (val && !AuthState.selectedSkills.has(val)) {
        AuthState.selectedSkills.add(val);
        const container = document.getElementById('regSkillChips');
        const newChip = document.createElement('span');
        newChip.className = 'chip-tag selected';
        newChip.setAttribute('data-value', val);
        newChip.textContent = `+ ${val}`;
        newChip.addEventListener('click', () => {
          if (AuthState.selectedSkills.has(val)) {
            AuthState.selectedSkills.delete(val);
            newChip.remove();
          }
        });
        container.appendChild(newChip);
        customSkillInput.value = '';
      }
    });
  }

  // Resume File Upload in Registration
  const resumeInput = document.getElementById('regResumeFile');
  const resumeStatus = document.getElementById('regResumeStatus');
  if (resumeInput) {
    resumeInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        AuthState.uploadedResumeFile = file;
        if (resumeStatus) {
          resumeStatus.innerHTML = `✅ <strong>${file.name}</strong> selected (${(file.size / 1024).toFixed(1)} KB). Ready for AI parsing on registration.`;
        }
      }
    });
  }

  // Profile Photo Upload Preview
  const photoInput = document.getElementById('regProfilePhoto');
  const previewImg = document.getElementById('regPhotoPreviewImg');
  const placeholderIcon = document.getElementById('regPhotoPlaceholder');

  if (photoInput) {
    photoInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        AuthState.uploadedPhotoFile = file;
        const reader = new FileReader();
        reader.onload = (re) => {
          if (previewImg) {
            previewImg.src = re.target.result;
            previewImg.classList.remove('hidden');
          }
          if (placeholderIcon) placeholderIcon.classList.add('hidden');
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // Registration Submit Handler
  regForm.addEventListener('submit', handleRegistrationSubmit);

  // Login Form Submit Handler
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLoginSubmit);
  }

  // Edit Profile Form Submit Handler (Modal)
  const editProfileForm = document.getElementById('editProfileForm');
  if (editProfileForm) {
    editProfileForm.addEventListener('submit', handleEditProfileSubmit);
  }

  // Inline Profile Edit Form Handler (On-page)
  const inlineEditForm = document.getElementById('inlineProfileEditForm');
  if (inlineEditForm) {
    inlineEditForm.addEventListener('submit', handleInlineProfileSubmit);
  }

  // Password Reset Form Handler
  const resetPassForm = document.getElementById('passwordResetForm');
  if (resetPassForm) {
    resetPassForm.addEventListener('submit', handlePasswordResetSubmit);
  }

  // Logout Button
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }
}

// ==========================================
// GOOGLE OAUTH SIGN-IN / QUICK REGISTRATION
// ==========================================
async function triggerGoogleSignIn() {
  const emailInput = prompt("Sign in with Google Gmail\nEnter your Google email address:", "srija.reddy@gmail.com");
  if (!emailInput) return;

  const nameInput = prompt("Enter your Name:", emailInput.split('@')[0].replace('.', ' ').toUpperCase());

  try {
    const res = await fetch('/api/auth/google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: emailInput,
        name: nameInput || 'Student',
        google_id: 'google_' + Date.now()
      })
    });
    const result = await res.json();

    if (result.success) {
      AppState.user = { id: result.user_id, email: emailInput };
      AppState.profile = result.profile;
      updateHeaderProfileUI(result.profile);
      showToast('success', 'Google Sign-In Success! 🚀', result.message);
      navigateTo('dashboard');
    } else {
      showToast('error', 'Google Sign-In Error', result.message || 'Could not authenticate with Google.');
    }
  } catch (err) {
    showToast('error', 'Server Error', 'Failed to connect to Google authentication service.');
  }
}

// ==========================================
// REGISTRATION FORM SUBMISSION
// ==========================================
async function handleRegistrationSubmit(e) {
  e.preventDefault();

  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const contact = document.getElementById('regContact').value.trim();
  const fatherName = document.getElementById('regFatherName').value.trim();
  const collegeName = document.getElementById('regCollegeName').value.trim();
  const branch = document.getElementById('regBranch').value;
  const academicYear = document.getElementById('regAcademicYear').value;
  const cgpa = document.getElementById('regCgpa').value.trim();
  const aboutCollege = document.getElementById('regAboutCollege').value.trim();
  const careerGoal = document.getElementById('regCareerGoal').value;
  const interests = document.getElementById('regInterests').value.trim();
  const prefLocation = document.getElementById('regPrefLocation').value.trim();
  const prefOppType = document.getElementById('regPrefOppType').value;
  const password = document.getElementById('regPassword').value;
  const confirmPassword = document.getElementById('regConfirmPassword').value;

  const langRadio = document.querySelector('input[name="regLang"]:checked');
  const preferredLanguage = langRadio ? langRadio.value : 'en';

  if (!name) {
    showToast('error', 'Missing Information', 'Please enter your Full Name.');
    document.getElementById('regName').focus();
    return;
  }
  if (!email) {
    showToast('error', 'Missing Information', 'Please enter your Email Address.');
    document.getElementById('regEmail').focus();
    return;
  }
  if (!contact) {
    showToast('error', 'Missing Information', 'Please enter your Contact Number.');
    document.getElementById('regContact').focus();
    return;
  }
  if (!fatherName) {
    showToast('error', 'Missing Information', 'Please enter your Father Name.');
    document.getElementById('regFatherName').focus();
    return;
  }
  if (!collegeName) {
    showToast('error', 'Missing Information', 'Please enter your College Name.');
    document.getElementById('regCollegeName').focus();
    return;
  }
  if (!branch) {
    showToast('error', 'Missing Information', 'Please select your Branch / Department.');
    document.getElementById('regBranch').focus();
    return;
  }
  if (!academicYear) {
    showToast('error', 'Missing Information', 'Please select your Academic Year.');
    document.getElementById('regAcademicYear').focus();
    return;
  }
  if (!password) {
    showToast('error', 'Missing Information', 'Please enter a Password.');
    document.getElementById('regPassword').focus();
    return;
  }
  if (password.length < 6) {
    showToast('error', 'Security Requirement', 'Password must be at least 6 characters long.');
    document.getElementById('regPassword').focus();
    return;
  }
  if (password !== confirmPassword) {
    showToast('error', 'Validation Error', 'Passwords do not match.');
    document.getElementById('regConfirmPassword').focus();
    return;
  }

  const submitBtn = document.getElementById('createAccountBtn');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<span>Creating Account & Parsing Resume... ⏳</span>`;
  }

  const formData = new FormData();
  formData.append('name', name);
  formData.append('email', email);
  formData.append('contact_number', contact);
  formData.append('father_name', fatherName);
  formData.append('college_name', collegeName);
  formData.append('branch', branch);
  formData.append('academic_year', academicYear);
  formData.append('cgpa', cgpa);
  formData.append('about_college', aboutCollege);
  formData.append('career_goal', careerGoal);
  formData.append('interests', interests);
  formData.append('preferred_location', prefLocation);
  formData.append('preferred_opportunity_type', prefOppType);
  formData.append('password', password);
  formData.append('confirm_password', confirmPassword);
  formData.append('preferred_language', preferredLanguage);

  const skillsArr = Array.from(AuthState.selectedSkills);
  const langsArr = Array.from(AuthState.selectedLanguages);
  formData.append('skills', JSON.stringify(skillsArr));
  formData.append('programming_languages', JSON.stringify(langsArr));

  if (AuthState.uploadedPhotoFile) {
    formData.append('profile_photo', AuthState.uploadedPhotoFile);
  }

  if (AuthState.uploadedResumeFile) {
    formData.append('resume_file', AuthState.uploadedResumeFile);
  }

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      body: formData
    });
    const result = await res.json();

    if (result.success) {
      AppState.user = { id: result.user.id, email: result.user.email };
      AppState.profile = result.profile;
      AppState.currentLanguage = preferredLanguage;

      updateHeaderProfileUI(result.profile);
      showToast('success', 'Account Created & Verified! 🎉', 'Your student profile & resume have been parsed. SMS alerts will be sent to your registered number.');

      navigateTo('dashboard');
    } else {
      const errMsgs = result.errors ? result.errors.join('<br>') : (result.message || 'Registration failed.');
      showToast('error', 'Registration Error', errMsgs);
    }
  } catch (err) {
    console.error('Registration fetch error:', err);
    showToast('error', 'Server Error', 'Failed to connect to the server. Please try again.');
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<span>CREATE ACCOUNT & START LIVE MONITORING 🚀</span>`;
    }
  }
}

// ==========================================
// LOGIN SUBMISSION
// ==========================================
async function handleLoginSubmit(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;

  if (!email || !password) {
    showToast('error', 'Missing Credentials', 'Please enter both email and password.');
    return;
  }

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const result = await res.json();

    if (result.success) {
      AppState.user = { id: result.user_id, email: email };
      AppState.profile = result.profile;
      AppState.currentLanguage = result.profile.preferred_language || 'en';
      const langSelect = document.getElementById('globalLanguageSelect');
      if (langSelect) langSelect.value = AppState.currentLanguage;

      updateHeaderProfileUI(result.profile);
      showToast('success', 'Welcome Back! 👋', 'Logged in successfully.');
      navigateTo('dashboard');
    } else {
      showToast('error', 'Login Failed', result.message || 'Invalid email or password.');
    }
  } catch (err) {
    showToast('error', 'Server Error', 'Could not complete login request.');
  }
}

// ==========================================
// DIRECT RESUME UPLOAD HANDLER
// ==========================================
async function handleDirectResumeUpload(inputEl) {
  const file = inputEl.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('resume', file);

  showToast('info', 'Uploading Resume 📄', 'Parsing resume and extracting skills with AI...');

  try {
    const res = await fetch('/api/resume/upload', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();

    if (data.success) {
      showToast('success', 'Resume Parsed! ✅', data.message);
      // Reload profile
      const profRes = await fetch('/api/profile');
      const profData = await profRes.json();
      if (profData.success) {
        AppState.profile = profData.profile;
        renderProfilePage();
      }
    } else {
      showToast('error', 'Upload Error', data.message || 'Failed to parse resume.');
    }
  } catch (err) {
    showToast('error', 'Server Error', 'Failed to upload resume.');
  }
}

// ==========================================
// LOGOUT
// ==========================================
async function handleLogout() {
  try {
    await fetch('/api/auth/logout', { method: 'POST' });
    AppState.user = null;
    AppState.profile = null;
    showToast('info', 'Logged Out', 'You have been logged out.');
    navigateTo('register');
  } catch (err) {
    navigateTo('register');
  }
}

// ==========================================
// RENDER PROFILE PAGE
// ==========================================
function renderProfilePage() {
  const p = AppState.profile;
  if (!p) return;

  // Profile Header Card
  const photoEl = document.getElementById('profileViewPhoto');
  const nameEl = document.getElementById('profileViewName');
  const goalEl = document.getElementById('profileViewGoal');
  const collegeEl = document.getElementById('profileViewCollege');

  if (photoEl) {
    if (p.profile_photo) {
      photoEl.innerHTML = `<img src="/uploads/${p.profile_photo}" alt="${p.name}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } else {
      photoEl.innerHTML = `<div style="font-size:2.5rem;color:var(--primary);">${(p.name || 'S').charAt(0).toUpperCase()}</div>`;
    }
  }
  if (nameEl) nameEl.textContent = p.name || 'Student Name';
  if (goalEl) goalEl.textContent = p.career_goal || 'Career Goal Not Set';
  if (collegeEl) collegeEl.textContent = `${p.college_name || 'College'} • ${p.branch || 'Branch'} (${p.academic_year || 'Year'})`;

  // Resume Section in Profile
  const resumeNameEl = document.getElementById('profileResumeFileName');
  const resumeBox = document.getElementById('profileResumeSummaryBox');
  if (resumeNameEl && resumeBox) {
    if (p.resume_filename) {
      resumeNameEl.innerHTML = `<a href="/uploads/${p.resume_filename}" target="_blank" style="color:#38bdf8;text-decoration:underline;">📥 View/Download ${p.resume_filename}</a>`;
      resumeBox.innerHTML = `
        <div style="margin-bottom:0.5rem;">
          <strong>AI Resume Summary:</strong> ${p.resume_summary || 'Resume analyzed and synced with career advisor.'}
        </div>
        <div style="font-size:0.8rem;color:var(--text-muted);">
          Skills extracted from your resume are actively matched against live internships and college events.
        </div>
      `;
    } else {
      resumeNameEl.textContent = 'No resume uploaded yet';
      resumeBox.innerHTML = `
        <div style="color:var(--text-muted);">
          Upload your resume (PDF/DOCX) above to let the AI agent automatically extract your competencies and match you with verified internships.
        </div>
      `;
    }
  }

  // Profile Completion Widget
  const comp = p.completion || { percentage: 0, missing_fields: [], ai_guidance: '' };
  const compPercentEl = document.getElementById('profileCompPercentage');
  const compBarEl = document.getElementById('profileCompBar');
  const compMissingEl = document.getElementById('profileCompMissing');
  const compGuidanceEl = document.getElementById('profileCompGuidance');

  if (compPercentEl) compPercentEl.textContent = `${comp.percentage}%`;
  if (compBarEl) compBarEl.style.width = `${comp.percentage}%`;
  if (compMissingEl) {
    if (comp.missing_fields && comp.missing_fields.length > 0) {
      compMissingEl.innerHTML = `<strong>Missing:</strong> ${comp.missing_fields.join(', ')}`;
      compMissingEl.classList.remove('hidden');
    } else {
      compMissingEl.innerHTML = `<span style="color:var(--success);">✨ All profile information & resume are complete!</span>`;
    }
  }
  if (compGuidanceEl) compGuidanceEl.textContent = comp.ai_guidance;

  // Personal Info Details
  const pName = document.getElementById('pvPersonalName');
  const pEmail = document.getElementById('pvPersonalEmail');
  const pContact = document.getElementById('pvPersonalContact');
  const pFather = document.getElementById('pvPersonalFather');

  if (pName) pName.textContent = p.name || '—';
  if (pEmail) pEmail.textContent = p.email || '—';
  if (pContact) pContact.textContent = p.contact_number || '—';
  if (pFather) pFather.textContent = p.father_name || '—';

  // College Info Details
  const cName = document.getElementById('pvCollegeName');
  const cBranch = document.getElementById('pvCollegeBranch');
  const cYear = document.getElementById('pvCollegeYear');
  const cCgpa = document.getElementById('pvCollegeCgpa');
  const cAbout = document.getElementById('pvCollegeAbout');

  if (cName) cName.textContent = p.college_name || '—';
  if (cBranch) cBranch.textContent = p.branch || '—';
  if (cYear) cYear.textContent = p.academic_year || '—';
  if (cCgpa) cCgpa.textContent = p.cgpa ? `${p.cgpa} CGPA` : 'Not entered';
  if (cAbout) cAbout.textContent = p.about_college || 'No description provided.';

  // Skills & Languages
  const skillsContainer = document.getElementById('pvSkillsContainer');
  const langsContainer = document.getElementById('pvLangsContainer');

  if (skillsContainer) {
    if (p.skills && p.skills.length > 0) {
      skillsContainer.innerHTML = p.skills.map(s => `<span class="badge badge-verified" style="font-size:0.85rem;padding:0.4rem 0.8rem;">${s}</span>`).join(' ');
    } else {
      skillsContainer.innerHTML = `<span class="text-muted" style="font-size:0.85rem;">No skills added yet.</span>`;
    }
  }

  if (langsContainer) {
    if (p.programming_languages && p.programming_languages.length > 0) {
      langsContainer.innerHTML = p.programming_languages.map(l => `<span class="badge badge-info" style="font-size:0.85rem;padding:0.4rem 0.8rem;">${l}</span>`).join(' ');
    } else {
      langsContainer.innerHTML = `<span class="text-muted" style="font-size:0.85rem;">No programming languages added yet.</span>`;
    }
  }

  // Career Information
  const pvGoal = document.getElementById('pvCareerGoal');
  const pvInterests = document.getElementById('pvInterests');
  const pvLoc = document.getElementById('pvPreferredLocation');
  const pvOppType = document.getElementById('pvPreferredOppType');

  if (pvGoal) pvGoal.textContent = p.career_goal || '—';
  if (pvInterests) pvInterests.textContent = p.interests || '—';
  if (pvLoc) pvLoc.textContent = p.preferred_location || 'Any / Remote';
  if (pvOppType) pvOppType.textContent = p.preferred_opportunity_type || 'All';
}

// ==========================================
// POPULATE INLINE PROFILE EDITOR & MODAL
// ==========================================
function populateInlineProfileEditor() {
  const p = AppState.profile;
  if (!p) return;

  // 1. Populate Inline Form Fields (if present)
  const inlineName = document.getElementById('inlineEditName');
  if (inlineName) {
    inlineName.value = p.name || '';
    if (document.getElementById('inlineEditEmail')) document.getElementById('inlineEditEmail').value = p.email || '';
    if (document.getElementById('inlineEditContact')) document.getElementById('inlineEditContact').value = p.contact_number || '';
    if (document.getElementById('inlineEditFatherName')) document.getElementById('inlineEditFatherName').value = p.father_name || '';

    const inColSelect = document.getElementById('inlineEditCollegeName');
    if (inColSelect && p.college_name) {
      let found = false;
      for (let opt of inColSelect.options) {
        if (opt.value === p.college_name) { opt.selected = true; found = true; break; }
      }
      if (!found && p.college_name) {
        const newOpt = document.createElement('option');
        newOpt.value = p.college_name;
        newOpt.textContent = p.college_name;
        newOpt.selected = true;
        inColSelect.appendChild(newOpt);
      }
    }

    const inBranch = document.getElementById('inlineEditBranch');
    if (inBranch && p.branch) {
      let found = false;
      for (let opt of inBranch.options) {
        if (opt.value === p.branch) { opt.selected = true; found = true; break; }
      }
      if (!found && p.branch) {
        const newOpt = document.createElement('option');
        newOpt.value = p.branch;
        newOpt.textContent = p.branch;
        newOpt.selected = true;
        inBranch.appendChild(newOpt);
      }
    }

    if (document.getElementById('inlineEditAcademicYear')) document.getElementById('inlineEditAcademicYear').value = p.academic_year || '1st Year';
    if (document.getElementById('inlineEditCgpa')) document.getElementById('inlineEditCgpa').value = p.cgpa || '';
    if (document.getElementById('inlineEditAboutCollege')) document.getElementById('inlineEditAboutCollege').value = p.about_college || '';
    if (document.getElementById('inlineEditCareerGoal')) document.getElementById('inlineEditCareerGoal').value = p.career_goal || 'Software Developer';
    if (document.getElementById('inlineEditPrefLocation')) document.getElementById('inlineEditPrefLocation').value = p.preferred_location || '';
    if (document.getElementById('inlineEditPrefOppType')) document.getElementById('inlineEditPrefOppType').value = p.preferred_opportunity_type || 'Internships';
    if (document.getElementById('inlineEditLanguage')) document.getElementById('inlineEditLanguage').value = p.preferred_language || 'en';
    if (document.getElementById('inlineEditLanguages')) document.getElementById('inlineEditLanguages').value = (p.programming_languages || []).join(', ');
    if (document.getElementById('inlineEditSkills')) document.getElementById('inlineEditSkills').value = (p.skills || []).join(', ');
  }

  // 2. Populate Modal Form Fields (if present)
  const editName = document.getElementById('editName');
  if (editName) {
    editName.value = p.name || '';
    if (document.getElementById('editEmail')) document.getElementById('editEmail').value = p.email || '';
    if (document.getElementById('editContact')) document.getElementById('editContact').value = p.contact_number || '';
    if (document.getElementById('editFatherName')) document.getElementById('editFatherName').value = p.father_name || '';

    const colSelect = document.getElementById('editCollegeName');
    if (colSelect && p.college_name) {
      let found = false;
      for (let opt of colSelect.options) {
        if (opt.value === p.college_name) { opt.selected = true; found = true; break; }
      }
      if (!found && p.college_name) {
        const newOpt = document.createElement('option');
        newOpt.value = p.college_name;
        newOpt.textContent = p.college_name;
        newOpt.selected = true;
        colSelect.appendChild(newOpt);
      }
    }

    const branchSelect = document.getElementById('editBranch');
    if (branchSelect && p.branch) {
      let found = false;
      for (let opt of branchSelect.options) {
        if (opt.value === p.branch) { opt.selected = true; found = true; break; }
      }
      if (!found && p.branch) {
        const newOpt = document.createElement('option');
        newOpt.value = p.branch;
        newOpt.textContent = p.branch;
        newOpt.selected = true;
        branchSelect.appendChild(newOpt);
      }
    }

    if (document.getElementById('editAcademicYear')) document.getElementById('editAcademicYear').value = p.academic_year || '1st Year';
    if (document.getElementById('editCgpa')) document.getElementById('editCgpa').value = p.cgpa || '';
    if (document.getElementById('editAboutCollege')) document.getElementById('editAboutCollege').value = p.about_college || '';
    if (document.getElementById('editCareerGoal')) document.getElementById('editCareerGoal').value = p.career_goal || 'Software Developer';
    if (document.getElementById('editInterests')) document.getElementById('editInterests').value = p.interests || '';
    if (document.getElementById('editPrefLocation')) document.getElementById('editPrefLocation').value = p.preferred_location || '';
    if (document.getElementById('editPrefOppType')) document.getElementById('editPrefOppType').value = p.preferred_opportunity_type || 'Internships';
    if (document.getElementById('editLanguage')) document.getElementById('editLanguage').value = p.preferred_language || 'en';
    if (document.getElementById('editSkills')) document.getElementById('editSkills').value = (p.skills || []).join(', ');
    if (document.getElementById('editLanguages')) document.getElementById('editLanguages').value = (p.programming_languages || []).join(', ');
  }
}

// ==========================================
// EDIT PROFILE MODAL
// ==========================================
function openEditProfileModal() {
  populateInlineProfileEditor();
  openModal('editProfileModal');
}

async function handleEditProfileSubmit(e) {
  e.preventDefault();

  const formData = new FormData();
  formData.append('name', document.getElementById('editName').value.trim());
  formData.append('contact_number', document.getElementById('editContact').value.trim());
  formData.append('father_name', document.getElementById('editFatherName').value.trim());
  formData.append('college_name', document.getElementById('editCollegeName').value.trim());
  formData.append('branch', document.getElementById('editBranch').value);
  formData.append('academic_year', document.getElementById('editAcademicYear').value);
  formData.append('cgpa', document.getElementById('editCgpa').value.trim());
  formData.append('about_college', document.getElementById('editAboutCollege').value.trim());
  formData.append('career_goal', document.getElementById('editCareerGoal').value);
  formData.append('interests', document.getElementById('editInterests') ? document.getElementById('editInterests').value.trim() : '');
  formData.append('preferred_location', document.getElementById('editPrefLocation').value.trim());
  formData.append('preferred_opportunity_type', document.getElementById('editPrefOppType').value);
  formData.append('preferred_language', document.getElementById('editLanguage').value);

  const skillsInput = document.getElementById('editSkills').value;
  const langsInput = document.getElementById('editLanguages').value;
  formData.append('skills', skillsInput);
  formData.append('programming_languages', langsInput);

  const photoInput = document.getElementById('editProfilePhoto');
  if (photoInput && photoInput.files[0]) {
    formData.append('profile_photo', photoInput.files[0]);
  }

  const resumeInput = document.getElementById('editResumeFile');
  if (resumeInput && resumeInput.files[0]) {
    formData.append('resume_file', resumeInput.files[0]);
  }

  await executeProfileUpdate(formData, 'editProfileModal');
}

async function handleInlineProfileSubmit(e) {
  e.preventDefault();

  const btn = document.getElementById('saveInlineProfileBtn');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span>Saving Changes... ⏳</span>`;
  }

  const formData = new FormData();
  formData.append('name', document.getElementById('inlineEditName').value.trim());
  formData.append('contact_number', document.getElementById('inlineEditContact').value.trim());
  formData.append('father_name', document.getElementById('inlineEditFatherName').value.trim());
  formData.append('college_name', document.getElementById('inlineEditCollegeName').value.trim());
  formData.append('branch', document.getElementById('inlineEditBranch').value);
  formData.append('academic_year', document.getElementById('inlineEditAcademicYear').value);
  formData.append('cgpa', document.getElementById('inlineEditCgpa').value.trim());
  formData.append('about_college', document.getElementById('inlineEditAboutCollege').value.trim());
  formData.append('career_goal', document.getElementById('inlineEditCareerGoal').value);
  formData.append('preferred_location', document.getElementById('inlineEditPrefLocation').value.trim());
  formData.append('preferred_opportunity_type', document.getElementById('inlineEditPrefOppType').value);
  formData.append('preferred_language', document.getElementById('inlineEditLanguage').value);

  const skillsInput = document.getElementById('inlineEditSkills').value;
  const langsInput = document.getElementById('inlineEditLanguages').value;
  formData.append('skills', skillsInput);
  formData.append('programming_languages', langsInput);

  const photoInput = document.getElementById('inlineEditProfilePhoto');
  if (photoInput && photoInput.files[0]) {
    formData.append('profile_photo', photoInput.files[0]);
  }

  const resumeInput = document.getElementById('inlineEditResumeFile');
  if (resumeInput && resumeInput.files[0]) {
    formData.append('resume_file', resumeInput.files[0]);
  }

  await executeProfileUpdate(formData);

  if (btn) {
    btn.disabled = false;
    btn.innerHTML = `<span>SAVE PROFILE & SYNC OPPORTUNITIES ✅</span>`;
  }
}

async function executeProfileUpdate(formData, modalToClose = null) {
  try {
    const res = await fetch('/api/profile/update', {
      method: 'POST',
      body: formData
    });
    const result = await res.json();

    if (result.success) {
      AppState.profile = result.profile;
      updateHeaderProfileUI(result.profile);
      renderProfilePage();
      renderCompleteInfoPage();
      if (modalToClose) closeModal(modalToClose);
      if (window.switchProfileTab) window.switchProfileTab('summary');
      showToast('success', 'Profile & Resume Updated! ✅', 'Your changes have been saved and synced with opportunity matching.');
    } else {
      showToast('error', 'Update Error', result.message || 'Could not update profile.');
    }
  } catch (err) {
    console.error('Profile update error:', err);
    showToast('error', 'Server Error', 'Failed to save profile changes.');
  }
}

// ==========================================
// RENDER COMPLETE INFO WORKBENCH
// ==========================================
function renderCompleteInfoPage() {
  const container = document.getElementById('completeInfoDynamicMount');
  const p = AppState.profile;
  if (!container || !p) return;

  const comp = p.completion || { percentage: 85, missing_fields: [] };
  const missing = comp.missing_fields || [];

  container.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(320px, 1fr));gap:1.5rem;margin-bottom:2rem;">
      <div class="card" style="background:var(--bg-input);border-color:var(--border-highlight);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
          <h3 style="color:#fff;font-size:1.1rem;margin:0;">Profile Completion Status</h3>
          <span style="font-size:1.35rem;font-weight:800;color:#38bdf8;">${comp.percentage}%</span>
        </div>
        <div style="background:var(--bg-surface-elevated);height:10px;border-radius:var(--radius-full);overflow:hidden;margin-bottom:1rem;">
          <div style="width:${comp.percentage}%;height:100%;background:var(--accent-gradient);"></div>
        </div>
        <div style="font-size:0.85rem;color:var(--text-muted);margin-bottom:0.5rem;">
          ${missing.length > 0 ? `<strong>Pending Items:</strong> ${missing.join(' • ')}` : '<span style="color:var(--success);">🎉 All profile fields & resume complete!</span>'}
        </div>
        <div style="font-size:0.8rem;color:#93c5fd;font-style:italic;">
          ${comp.ai_guidance || 'Keep your skills and resume up to date for maximum opportunity matching.'}
        </div>
      </div>

      <div class="card" style="display:flex;flex-direction:column;justify-content:space-between;">
        <div>
          <h3 style="color:#fff;font-size:1.1rem;margin-bottom:0.5rem;">Quick Profile Actions</h3>
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:1rem;">Update specific sections directly to optimize matching score.</p>
        </div>
        <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
          <button class="btn btn-sm btn-primary" onclick="navigateTo('profile', {tab: 'edit'})">Open Profile Editor ✏️</button>
          <button class="btn btn-sm btn-secondary" onclick="openEditProfileModal()">Edit in Popup ⚙️</button>
          <button class="btn btn-sm btn-secondary" onclick="navigateTo('profile', {tab: 'resume'})">Replace Resume 📄</button>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// PASSWORD RESET
// ==========================================
async function handlePasswordResetSubmit(e) {
  e.preventDefault();
  const currentPass = document.getElementById('resetCurrentPassword').value;
  const newPass = document.getElementById('resetNewPassword').value;
  const confirmNewPass = document.getElementById('resetConfirmPassword').value;

  if (!currentPass || !newPass || !confirmNewPass) {
    showToast('error', 'Validation Error', 'All fields are required.');
    return;
  }

  if (newPass !== confirmNewPass) {
    showToast('error', 'Validation Error', 'New passwords do not match.');
    return;
  }

  try {
    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        current_password: currentPass,
        new_password: newPass,
        confirm_new_password: confirmNewPass
      })
    });
    const result = await res.json();

    if (result.success) {
      showToast('success', 'Password Updated! 🔒', result.message);
      document.getElementById('passwordResetForm').reset();
    } else {
      showToast('error', 'Reset Failed', result.message);
    }
  } catch (err) {
    showToast('error', 'Server Error', 'Could not complete password reset.');
  }
}

window.initRegistrationForm = initRegistrationForm;
window.renderProfilePage = renderProfilePage;
window.renderCompleteInfoPage = renderCompleteInfoPage;
window.populateInlineProfileEditor = populateInlineProfileEditor;
window.openEditProfileModal = openEditProfileModal;
window.handleInlineProfileSubmit = handleInlineProfileSubmit;
window.triggerGoogleSignIn = triggerGoogleSignIn;
window.handleDirectResumeUpload = handleDirectResumeUpload;

document.addEventListener('DOMContentLoaded', initRegistrationForm);

