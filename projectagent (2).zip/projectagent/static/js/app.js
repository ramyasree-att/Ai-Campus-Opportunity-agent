/**
 * AI Campus Opportunity Agent - Core Application SPA Controller
 * Multilingual support (English, Telugu, Hindi), live crawler sync & SMS monitor
 */

const AppState = {
  user: null,
  profile: null,
  activeView: 'dashboard',
  currentCategory: 'all',
  searchQuery: '',
  notifications: [],
  unreadCount: 0,
  currentLanguage: 'en'
};

// Global Toast System
function showToast(type, title, message) {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  const iconMap = {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    info: '💡'
  };

  toast.innerHTML = `
    <div style="font-size: 1.25rem;">${iconMap[type] || '🔔'}</div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-message">${message}</div>
    </div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'slideInToast 0.3s cubic-bezier(0.4, 0, 0.2, 1) reverse forwards';
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

// Modal Helpers
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    if (modalId === 'smsLogsModal') {
      loadSmsLogs();
    }
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
  }
}

// Navigation & View Switching
function navigateTo(viewName, params = {}) {
  // If user is not logged in, enforce registration or login screen
  if (!AppState.user && viewName !== 'login') {
    viewName = 'register';
  }
  AppState.activeView = viewName;

  // Opportunity categories list
  const oppCategories = ['internships', 'hackathons', 'scholarships', 'competitions', 'events', 'workshops', 'certifications', 'opportunities'];
  const isOppCategory = oppCategories.includes(viewName);

  // Update navigation items in sidebar
  document.querySelectorAll('.nav-item').forEach(item => {
    const itemTarget = item.getAttribute('data-view') || item.getAttribute('data-view-target');
    if (itemTarget === viewName) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  // Hide all view containers
  document.querySelectorAll('.view-section').forEach(sec => {
    sec.classList.add('hidden');
  });

  // Show requested view
  if (isOppCategory) {
    const oppContainer = document.getElementById('view-opportunities') || document.getElementById('view-internships');
    if (oppContainer) oppContainer.classList.remove('hidden');
  } else {
    const targetView = document.getElementById(`view-${viewName}`);
    if (targetView) {
      targetView.classList.remove('hidden');
    }
  }

  // Handle auth layout toggle (hide sidebar/header when on register/login)
  const isAuthView = (viewName === 'register' || viewName === 'login');
  const sidebar = document.getElementById('sidebar');
  const topHeader = document.getElementById('topHeader');
  const mainWrapper = document.getElementById('mainWrapper');

  if (isAuthView) {
    if (sidebar) sidebar.classList.add('hidden');
    if (topHeader) topHeader.classList.add('hidden');
    if (mainWrapper) mainWrapper.style.marginLeft = '0';
  } else {
    if (sidebar) sidebar.classList.remove('hidden');
    if (topHeader) topHeader.classList.remove('hidden');
    if (mainWrapper) mainWrapper.style.marginLeft = window.innerWidth > 1024 ? 'var(--sidebar-width)' : '0';
  }

  // Scroll to top
  window.scrollTo(0, 0);

  // Trigger view specific loaders
  if (isOppCategory) {
    const category = (viewName === 'opportunities') ? 'all' : viewName;
    if (window.loadOpportunities) {
      window.loadOpportunities(category, params.search || '', params);
    }
  } else {
    switch (viewName) {
      case 'dashboard':
        if (window.loadDashboard) window.loadDashboard();
        break;
      case 'profile':
        if (window.renderProfilePage) window.renderProfilePage();
        if (params.tab && window.switchProfileTab) window.switchProfileTab(params.tab);
        break;
      case 'complete_info':
        if (window.renderCompleteInfoPage) window.renderCompleteInfoPage();
        if (window.renderProfilePage) window.renderProfilePage();
        break;
      case 'notes':
        if (window.loadProgrammingNotes) window.loadProgrammingNotes(params.language || 'python');
        break;
      case 'placements':
        if (window.initPlacementsView) {
          window.initPlacementsView();
        } else if (window.loadOpportunities) {
          window.loadOpportunities('placements');
        }
        break;
      case 'saved':
        if (window.loadSavedOpportunities) window.loadSavedOpportunities();
        break;
      case 'applications':
        if (window.loadApplicationsTracker) window.loadApplicationsTracker();
        break;
      case 'roadmap':
        if (window.loadCareerRoadmap) window.loadCareerRoadmap();
        break;
      case 'learning_plans':
        if (window.loadLearningPlans) window.loadLearningPlans();
        break;
      case 'admin':
        if (window.initAdminDashboard) window.initAdminDashboard();
        break;
    }
  }
}

// Profile View Tab Switcher
function switchProfileTab(tabName) {
  const tabs = ['summary', 'edit', 'resume'];
  tabs.forEach(t => {
    const btn = document.getElementById(`profTabBtn_${t}`);
    const pane = document.getElementById(`profPane_${t}`);
    if (btn) {
      if (t === tabName) btn.classList.add('active');
      else btn.classList.remove('active');
    }
    if (pane) {
      if (t === tabName) pane.classList.remove('hidden');
      else pane.classList.add('hidden');
    }
  });

  if (tabName === 'edit' && window.populateInlineProfileEditor) {
    window.populateInlineProfileEditor();
  }
}

// Initial Session Check
async function initApp() {
  try {
    const res = await fetch('/api/auth/me');
    const data = await res.json();

    if (data.authenticated && data.profile) {
      AppState.user = { id: data.profile.user_id, email: data.profile.email };
      AppState.profile = data.profile;
      AppState.currentLanguage = data.profile.preferred_language || 'en';

      const langSelect = document.getElementById('globalLanguageSelect');
      if (langSelect) langSelect.value = AppState.currentLanguage;

      updateHeaderProfileUI(data.profile);
      if (window.checkAdminAccessAndInit) window.checkAdminAccessAndInit();
      navigateTo('dashboard');
    } else {
      AppState.user = null;
      AppState.profile = null;
      navigateTo('register');
    }
  } catch (err) {
    console.error('Session init error:', err);
    navigateTo('register');
  }

  setupGlobalEventListeners();
  loadNotifications();
}

function updateHeaderProfileUI(profile) {
  if (!profile) return;
  
  const nameEl = document.getElementById('headerStudentName');
  const avatarEl = document.getElementById('headerAvatar');

  if (nameEl) nameEl.textContent = profile.name || 'Student';
  if (avatarEl) {
    if (profile.profile_photo) {
      avatarEl.innerHTML = `<img src="/uploads/${profile.profile_photo}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } else {
      const initial = (profile.name || 'S').charAt(0).toUpperCase();
      avatarEl.textContent = initial;
    }
  }
}

async function loadNotifications() {
  if (!AppState.user) return;
  try {
    const res = await fetch('/api/notifications');
    const data = await res.json();
    if (data.success) {
      AppState.notifications = data.notifications;
      AppState.unreadCount = data.unread_count;
      const badge = document.getElementById('notificationBadge');
      if (badge) {
        if (data.unread_count > 0) {
          badge.classList.remove('hidden');
        } else {
          badge.classList.add('hidden');
        }
      }

      // Render notifications in modal
      const modalList = document.getElementById('modalNotificationsList');
      if (modalList && data.notifications.length > 0) {
        modalList.innerHTML = data.notifications.map(n => `
          <div style="background:var(--bg-input);padding:0.75rem 1rem;border-radius:var(--radius-sm);border-left:3px solid var(--primary);">
            <div style="font-weight:700;color:#fff;font-size:0.9rem;margin-bottom:0.2rem;">${n.title}</div>
            <div style="font-size:0.8rem;color:var(--text-main);">${n.message}</div>
            <div style="font-size:0.7rem;color:var(--text-muted);margin-top:0.35rem;">
              ${n.sent_to_contact ? `📱 Sent via SMS to ${n.contact_number || 'Mobile'} • ` : ''}${new Date(n.created_at).toLocaleString()}
            </div>
          </div>
        `).join('');
      }
    }
  } catch (e) {
    console.error('Error fetching notifications:', e);
  }
}

async function loadSmsLogs() {
  const container = document.getElementById('smsLogsListContainer');
  if (!container) return;

  try {
    const res = await fetch('/api/sms/logs');
    const data = await res.json();

    if (data.success && data.logs.length > 0) {
      container.innerHTML = data.logs.map(log => `
        <div style="background:var(--bg-input);padding:0.85rem 1rem;border-radius:var(--radius-sm);border:1px solid var(--border-color);">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.35rem;">
            <strong style="color:#fff;font-size:0.9rem;">📱 ${log.title || 'SMS Notification'}</strong>
            <span class="badge badge-success" style="font-size:0.7rem;">${log.status} ✅</span>
          </div>
          <div style="font-size:0.825rem;color:var(--text-main);margin-bottom:0.4rem;">
            ${log.message}
          </div>
          <div style="display:flex;justify-content:space-between;font-size:0.7rem;color:var(--text-muted);">
            <span>To: <strong>${log.contact_number}</strong> (${log.gateway})</span>
            <span>${new Date(log.created_at).toLocaleString()}</span>
          </div>
        </div>
      `).join('');
    } else {
      container.innerHTML = `<div style="text-align:center;padding:2rem;color:var(--text-muted);">No SMS notifications recorded yet.</div>`;
    }
  } catch (err) {
    container.innerHTML = `<div style="color:var(--danger);text-align:center;">Failed to load SMS logs.</div>`;
  }
}

async function triggerLiveCrawlerSync() {
  const icon = document.getElementById('crawlerSpinIcon');
  if (icon) icon.classList.add('spinning');

  showToast('info', 'Python Crawler Searching 🌐', 'Searching the internet for latest internships, scholarships & college events...');

  try {
    const res = await fetch('/api/crawler/sync', { method: 'POST' });
    const data = await res.json();

    if (icon) icon.classList.remove('spinning');

    if (data.success) {
      showToast('success', 'Live Internet Crawl Complete! 🚀', `Discovered & synced ${data.new_opportunities_added} new items. Updated ${data.expired_deadlines_updated} expired deadlines.`);
      
      // Reload opportunities and dashboard
      if (window.loadDashboard) window.loadDashboard();
      if (window.loadOpportunities) window.loadOpportunities(AppState.currentCategory);
      loadNotifications();
    } else {
      showToast('error', 'Crawler Error', 'Could not sync live opportunities.');
    }
  } catch (err) {
    if (icon) icon.classList.remove('spinning');
    showToast('error', 'Server Error', 'Failed to connect with crawler engine.');
  }
}

async function handleLanguageChange(langCode) {
  AppState.currentLanguage = langCode;
  try {
    await fetch('/api/language/change', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ language: langCode })
    });
  } catch (e) {
    console.error('Language sync error:', e);
  }

  const langNames = { en: 'English 🇬🇧', te: 'తెలుగు 🇮🇳', hi: 'हिन्दी 🇮🇳' };
  showToast('info', 'Language Switched 🌐', `Agent responses and speech will now be in ${langNames[langCode] || langCode}.`);

  // Update AI Chat welcome bubble
  const welcomeBubble = document.getElementById('aiChatWelcomeBubble');
  if (welcomeBubble) {
    if (langCode === 'te') {
      welcomeBubble.textContent = 'నమస్కారం! నేను మీ AI కెరీర్ అడ్వైజర్‌ని. ఇంటర్న్‌షిప్‌లు, స్కాలర్‌షిప్‌లు, కాలేజీ ఈవెంట్‌లు మరియు ప్రోగ్రామింగ్ నోట్స్ గురించి నన్ను తెలుగులో అడగండి!';
    } else if (langCode === 'hi') {
      welcomeBubble.textContent = 'नमस्ते! मैं आपका AI करियर एडवाइजर हूँ। इंटर्नशिप, स्कॉलरशिप, कॉलेज इवेंट्स और प्रोग्रामिंग नोट्स के बारे में मुझसे हिन्दी में पूछें!';
    } else {
      welcomeBubble.textContent = 'Hello! I\'m your AI Career Advisor. Ask me anything in English, తెలుగు, or हिन्दी about internships, scholarships, college events, resume reviews, or Python/Java/C programming notes!';
    }
  }
}

function setupGlobalEventListeners() {
  // Global Navigation clicks
  document.querySelectorAll('[data-view-target]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const target = btn.getAttribute('data-view-target');
      navigateTo(target);
    });
  });

  // Global Language Dropdown
  const langSelect = document.getElementById('globalLanguageSelect');
  if (langSelect) {
    langSelect.addEventListener('change', (e) => {
      handleLanguageChange(e.target.value);
    });
  }

  // Global search input
  const searchInput = document.getElementById('globalSearchInput');
  if (searchInput) {
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        const query = e.target.value.trim();
        AppState.searchQuery = query;
        if (query) {
          if (AppState.activeView !== 'internships' && AppState.activeView !== 'hackathons' && AppState.activeView !== 'scholarships') {
            navigateTo('internships');
          }
          if (window.loadOpportunities) {
            window.loadOpportunities(AppState.currentCategory, query);
          }
        }
      }, 400);
    });
  }

  // Close modals when clicking backdrop
  document.querySelectorAll('.modal-backdrop').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
      }
    });
  });

  // Close buttons
  document.querySelectorAll('.close-modal-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const modal = btn.closest('.modal-backdrop');
      if (modal) modal.classList.remove('active');
    });
  });

  // Mobile sidebar toggle
  const menuToggle = document.getElementById('mobileMenuToggle');
  const sidebar = document.getElementById('sidebar');
  if (menuToggle && sidebar) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
    });
  }

  // Load Telangana colleges globally
  if (window.loadTelanganaCollegesList) {
    window.loadTelanganaCollegesList();
  }
}

// Live Python Prompt Search Tool
async function triggerPromptSearch() {
  const input = document.getElementById('promptSearchInput');
  const banner = document.getElementById('promptSearchResultsBanner');
  if (!input) return;

  const query = input.value.trim();
  if (!query) {
    showToast('warning', 'Empty Query', 'Please enter a search instruction or keyword.');
    return;
  }

  if (banner) {
    banner.style.display = 'block';
    banner.innerHTML = `<span>🐍 Python Search Engine active: crawling live web & network for "${query}"... ⏳</span>`;
  }

  try {
    const res = await fetch('/api/crawler/search_tool', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: query, category: AppState.currentCategory || 'all' })
    });
    const data = await res.json();

    if (data.success && data.results) {
      if (banner) {
        banner.innerHTML = `<span>✅ Discovered ${data.count} verified live results matching "${query}" (${data.detected_category}).</span>`;
      }
      if (window.loadOpportunities) {
        window.loadOpportunities(AppState.currentCategory);
      }
      showToast('success', 'Search Complete! 🚀', `Python search engine extracted ${data.count} opportunities for "${query}".`);
    } else {
      if (banner) banner.innerHTML = `<span>No results found for "${query}".</span>`;
    }
  } catch (err) {
    if (banner) banner.innerHTML = `<span style="color:#ef4444;">Search engine query failed.</span>`;
  }
}

document.addEventListener('DOMContentLoaded', initApp);

window.showToast = showToast;
window.openModal = openModal;
window.closeModal = closeModal;
window.navigateTo = navigateTo;
window.switchProfileTab = switchProfileTab;
window.triggerLiveCrawlerSync = triggerLiveCrawlerSync;
window.handleLanguageChange = handleLanguageChange;
window.triggerPromptSearch = triggerPromptSearch;


