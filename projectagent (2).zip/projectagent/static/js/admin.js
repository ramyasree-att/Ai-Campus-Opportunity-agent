/**
 * Admin Dashboard & Control Center JavaScript Controller
 * Role-Based Access, User Management, Telangana Colleges, Opportunity Moderation,
 * Automation Controls, Interval Tuning, and Collector Health Logs.
 */

const AdminState = {
  activeTab: 'overview',
  users: [],
  colleges: [],
  opportunities: [],
  sources: [],
  logs: []
};

async function checkAdminAccessAndInit() {
  try {
    const res = await fetch('/api/auth/me');
    const data = await res.json();
    if (data.authenticated && data.profile && data.profile.role === 'ADMIN') {
      const adminNav = document.getElementById('adminNavItem');
      if (adminNav) adminNav.classList.remove('hidden');
    }
  } catch (e) {
    console.error('Error checking admin status:', e);
  }
}

async function initAdminDashboard() {
  await loadAdminStats();
  setupAdminTabListeners();
}

function setupAdminTabListeners() {
  document.querySelectorAll('.admin-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.getAttribute('data-admin-tab');
      switchAdminTab(tab);
    });
  });
}

function switchAdminTab(tab) {
  AdminState.activeTab = tab;
  document.querySelectorAll('.admin-tab-btn').forEach(b => {
    if (b.getAttribute('data-admin-tab') === tab) {
      b.classList.add('active');
    } else {
      b.classList.remove('active');
    }
  });

  document.querySelectorAll('.admin-tab-pane').forEach(p => {
    if (p.id === `adminPane_${tab}`) {
      p.classList.remove('hidden');
    } else {
      p.classList.add('hidden');
    }
  });

  if (tab === 'overview') loadAdminStats();
  if (tab === 'users') loadAdminUsers();
  if (tab === 'colleges') loadAdminColleges();
  if (tab === 'opportunities') loadAdminOpportunities();
  if (tab === 'automation') loadAdminAutomation();
  if (tab === 'logs') loadAdminLogs();
}

// ----------------- OVERVIEW STATS -----------------
async function loadAdminStats() {
  const container = document.getElementById('adminOverviewContent');
  if (!container) return;

  try {
    const res = await fetch('/api/admin/stats');
    const data = await res.json();
    if (!data.success) {
      container.innerHTML = `<div class="alert alert-danger">${data.message || 'Access denied.'}</div>`;
      return;
    }

    const s = data.stats;
    const opps = s.opportunities || {};

    container.innerHTML = `
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:1rem;margin-bottom:1.5rem;">
        <div class="card" style="padding:1.25rem;border-left:4px solid #38bdf8;">
          <div style="color:var(--text-muted);font-size:0.8rem;text-transform:uppercase;">Total Registered Users</div>
          <div style="font-size:1.8rem;font-weight:800;color:#fff;margin-top:0.25rem;">${s.total_users}</div>
        </div>
        <div class="card" style="padding:1.25rem;border-left:4px solid #4ade80;">
          <div style="color:var(--text-muted);font-size:0.8rem;text-transform:uppercase;">Telangana Colleges</div>
          <div style="font-size:1.8rem;font-weight:800;color:#fff;margin-top:0.25rem;">${s.total_colleges}</div>
        </div>
        <div class="card" style="padding:1.25rem;border-left:4px solid #fbbf24;">
          <div style="color:var(--text-muted);font-size:0.8rem;text-transform:uppercase;">Active Opportunities</div>
          <div style="font-size:1.8rem;font-weight:800;color:#fff;margin-top:0.25rem;">${opps.ACTIVE || 0}</div>
        </div>
        <div class="card" style="padding:1.25rem;border-left:4px solid #f87171;">
          <div style="color:var(--text-muted);font-size:0.8rem;text-transform:uppercase;">Expired / Archived</div>
          <div style="font-size:1.8rem;font-weight:800;color:#fff;margin-top:0.25rem;">${opps.EXPIRED || 0}</div>
        </div>
      </div>

      <div class="card">
        <h3 style="color:#fff;font-size:1.1rem;margin-bottom:1rem;">🤖 Automation & Collector System Health</h3>
        <div style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap;margin-bottom:1rem;">
          <button class="btn btn-primary" id="btnAdminTriggerCrawl" onclick="triggerAdminCrawl()">
            ⚡ Run All Collectors Now
          </button>
          <span id="adminCrawlStatusMsg" style="font-size:0.85rem;color:var(--text-muted);"></span>
        </div>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Error loading admin stats: ${e.message}</div>`;
  }
}

async function triggerAdminCrawl() {
  const btn = document.getElementById('btnAdminTriggerCrawl');
  const msg = document.getElementById('adminCrawlStatusMsg');
  if (btn) btn.disabled = true;
  if (msg) msg.textContent = 'Running live crawlers & deadline check... ⏳';

  try {
    const res = await fetch('/api/admin/automation/trigger', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      if (msg) msg.textContent = `✅ Crawl finished in ${data.results.duration_seconds || 'few'}s!`;
      if (typeof showToast === 'function') showToast('Live collector cycle completed!', 'success');
      loadAdminStats();
    } else {
      if (msg) msg.textContent = `❌ Failed: ${data.message}`;
    }
  } catch (e) {
    if (msg) msg.textContent = `❌ Error: ${e.message}`;
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ----------------- USER MANAGEMENT -----------------
async function loadAdminUsers() {
  const container = document.getElementById('adminUsersTableContainer');
  if (!container) return;

  container.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text-muted);">Loading students list...</div>';

  try {
    const res = await fetch('/api/admin/users');
    const data = await res.json();
    if (!data.success) {
      container.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
      return;
    }

    AdminState.users = data.users || [];
    if (AdminState.users.length === 0) {
      container.innerHTML = '<div style="text-align:center;padding:2rem;">No registered users found.</div>';
      return;
    }

    container.innerHTML = `
      <div style="overflow-x:auto;">
        <table class="table" style="width:100%;border-collapse:collapse;font-size:0.85rem;">
          <thead>
            <tr style="border-bottom:1px solid var(--border-color);text-align:left;color:var(--text-muted);">
              <th style="padding:0.75rem;">ID</th>
              <th style="padding:0.75rem;">Name / Email</th>
              <th style="padding:0.75rem;">College & Branch</th>
              <th style="padding:0.75rem;">CGPA</th>
              <th style="padding:0.75rem;">Role</th>
              <th style="padding:0.75rem;">Status</th>
              <th style="padding:0.75rem;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${AdminState.users.map(u => `
              <tr style="border-bottom:1px solid var(--border-color);">
                <td style="padding:0.75rem;color:var(--text-muted);">#${u.id}</td>
                <td style="padding:0.75rem;">
                  <div style="font-weight:700;color:#fff;">${escapeHtml(u.full_name || 'Student')}</div>
                  <div style="color:var(--text-muted);font-size:0.75rem;">${escapeHtml(u.email)}</div>
                </td>
                <td style="padding:0.75rem;">
                  <div style="color:var(--text-main);">${escapeHtml(u.college_name || 'Not set')}</div>
                  <div style="color:var(--text-muted);font-size:0.75rem;">${escapeHtml(u.branch || '-')} (${escapeHtml(u.academic_year || '-')})</div>
                </td>
                <td style="padding:0.75rem;font-weight:700;color:#38bdf8;">${u.cgpa || '-'}</td>
                <td style="padding:0.75rem;">
                  <span class="badge ${u.role === 'ADMIN' ? 'badge-danger' : 'badge-info'}">${u.role}</span>
                </td>
                <td style="padding:0.75rem;">
                  <span class="badge ${u.is_active ? 'badge-success' : 'badge-warning'}">${u.is_active ? 'Active' : 'Suspended'}</span>
                </td>
                <td style="padding:0.75rem;">
                  <button class="btn btn-sm btn-secondary" onclick="toggleAdminUserStatus(${u.id})">
                    ${u.is_active ? 'Suspend' : 'Activate'}
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`;
  }
}

async function toggleAdminUserStatus(userId) {
  try {
    const res = await fetch(`/api/admin/users/${userId}/toggle-status`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      if (typeof showToast === 'function') showToast(data.message, 'success');
      loadAdminUsers();
    }
  } catch (e) {
    alert('Failed to update status: ' + e.message);
  }
}

// ----------------- TELANGANA COLLEGES -----------------
async function loadAdminColleges() {
  const container = document.getElementById('adminCollegesContainer');
  if (!container) return;

  container.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text-muted);">Loading Telangana colleges...</div>';

  try {
    const res = await fetch('/api/admin/colleges');
    const data = await res.json();
    if (!data.success) {
      container.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
      return;
    }

    AdminState.colleges = data.colleges || [];
    container.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
        <h3 style="color:#fff;font-size:1.1rem;">Telangana Engineering Colleges (${AdminState.colleges.length})</h3>
      </div>
      <div style="overflow-x:auto;">
        <table class="table" style="width:100%;border-collapse:collapse;font-size:0.85rem;">
          <thead>
            <tr style="border-bottom:1px solid var(--border-color);text-align:left;color:var(--text-muted);">
              <th style="padding:0.75rem;">Rank</th>
              <th style="padding:0.75rem;">College Name</th>
              <th style="padding:0.75rem;">Location</th>
              <th style="padding:0.75rem;">Avg / Highest LPA</th>
              <th style="padding:0.75rem;">Placement %</th>
              <th style="padding:0.75rem;">Website</th>
            </tr>
          </thead>
          <tbody>
            ${AdminState.colleges.slice(0, 30).map(c => `
              <tr style="border-bottom:1px solid var(--border-color);">
                <td style="padding:0.75rem;font-weight:700;color:#facc15;">#${c.nirf_rank || c.id}</td>
                <td style="padding:0.75rem;font-weight:700;color:#fff;">${escapeHtml(c.college_name || c.name || '')}</td>
                <td style="padding:0.75rem;color:var(--text-muted);">${escapeHtml(c.city || c.location || 'Telangana')}</td>
                <td style="padding:0.75rem;color:#38bdf8;">₹${c.avg_package_lpa || 6.5} / ₹${c.highest_package_lpa || 30.0} LPA</td>
                <td style="padding:0.75rem;font-weight:700;color:#4ade80;">${c.placement_percentage || c.placement_rate_pct || 85}%</td>
                <td style="padding:0.75rem;">
                  <a href="${escapeHtml(c.website_url || '#')}" target="_blank" rel="noopener noreferrer" style="color:#38bdf8;text-decoration:underline;">Visit ↗</a>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`;
  }
}

// ----------------- OPPORTUNITIES MODERATION -----------------
async function loadAdminOpportunities() {
  const container = document.getElementById('adminOppsContainer');
  if (!container) return;

  container.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text-muted);">Loading opportunities...</div>';

  try {
    const res = await fetch('/api/admin/opportunities');
    const data = await res.json();
    if (!data.success) {
      container.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
      return;
    }

    AdminState.opportunities = data.opportunities || [];
    container.innerHTML = `
      <div style="overflow-x:auto;">
        <table class="table" style="width:100%;border-collapse:collapse;font-size:0.85rem;">
          <thead>
            <tr style="border-bottom:1px solid var(--border-color);text-align:left;color:var(--text-muted);">
              <th style="padding:0.75rem;">ID</th>
              <th style="padding:0.75rem;">Title & Organization</th>
              <th style="padding:0.75rem;">Category</th>
              <th style="padding:0.75rem;">Deadline</th>
              <th style="padding:0.75rem;">Status</th>
              <th style="padding:0.75rem;">Source</th>
              <th style="padding:0.75rem;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${AdminState.opportunities.map(o => `
              <tr style="border-bottom:1px solid var(--border-color);">
                <td style="padding:0.75rem;color:var(--text-muted);">#${o.id}</td>
                <td style="padding:0.75rem;">
                  <div style="font-weight:700;color:#fff;">${escapeHtml(o.title)}</div>
                  <div style="color:var(--text-muted);font-size:0.75rem;">${escapeHtml(o.organization || o.company || '')}</div>
                </td>
                <td style="padding:0.75rem;">
                  <span class="badge badge-info">${o.category}</span>
                </td>
                <td style="padding:0.75rem;color:#facc15;">${o.deadline || 'Ongoing'}</td>
                <td style="padding:0.75rem;">
                  <span class="badge ${o.status === 'ACTIVE' ? 'badge-success' : (o.status === 'EXPIRING_SOON' ? 'badge-warning' : 'badge-danger')}">
                    ${o.status}
                  </span>
                </td>
                <td style="padding:0.75rem;font-size:0.75rem;color:var(--text-muted);">
                  ${escapeHtml(o.source || o.source_name || 'Web')}
                </td>
                <td style="padding:0.75rem;">
                  <select onchange="updateOppStatus(${o.id}, this.value)" style="padding:0.25rem 0.5rem;font-size:0.75rem;background:var(--bg-input);color:#fff;border-radius:4px;border:1px solid var(--border-color);">
                    <option value="">Change Status</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="EXPIRING_SOON">EXPIRING_SOON</option>
                    <option value="EXPIRED">EXPIRED</option>
                    <option value="CLOSED">CLOSED</option>
                  </select>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`;
  }
}

async function updateOppStatus(oppId, status) {
  if (!status) return;
  try {
    const res = await fetch(`/api/admin/opportunities/${oppId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    const data = await res.json();
    if (data.success) {
      if (typeof showToast === 'function') showToast(data.message, 'success');
      loadAdminOpportunities();
    }
  } catch (e) {
    alert('Failed to update status: ' + e.message);
  }
}

// ----------------- AUTOMATION & SOURCES -----------------
async function loadAdminAutomation() {
  const container = document.getElementById('adminAutomationContainer');
  if (!container) return;

  try {
    const [intervalsRes, sourcesRes] = await Promise.all([
      fetch('/api/admin/automation/intervals'),
      fetch('/api/admin/sources')
    ]);
    const intervalsData = await intervalsRes.json();
    const sourcesData = await sourcesRes.json();

    const sources = sourcesData.sources || [];
    const intervals = intervalsData.intervals || {};

    container.innerHTML = `
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(320px, 1fr));gap:1.5rem;">
        <div class="card">
          <h3 style="color:#fff;font-size:1.1rem;margin-bottom:1rem;">⏱️ Scheduler Intervals</h3>
          <div style="display:flex;flex-direction:column;gap:1rem;">
            ${Object.entries(intervals).map(([k, v]) => `
              <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:0.5rem;">
                <div>
                  <div style="font-weight:700;color:#fff;font-size:0.85rem;">${escapeHtml(k)}</div>
                  <div style="color:var(--text-muted);font-size:0.75rem;">${escapeHtml(v.description || '')}</div>
                </div>
                <div style="font-weight:800;color:#38bdf8;">${v.value}h</div>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="card">
          <h3 style="color:#fff;font-size:1.1rem;margin-bottom:1rem;">🔌 Verified Collector Sources</h3>
          <div style="display:flex;flex-direction:column;gap:0.75rem;max-height:400px;overflow-y:auto;">
            ${sources.map(s => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:0.5rem;background:var(--bg-input);border-radius:4px;">
                <div>
                  <div style="font-weight:700;color:#fff;font-size:0.85rem;">${escapeHtml(s.source_name)}</div>
                  <div style="color:var(--text-muted);font-size:0.75rem;">${s.category} • ${s.source_type}</div>
                </div>
                <button class="btn btn-sm ${s.is_enabled ? 'btn-success' : 'btn-secondary'}" onclick="toggleSource(${s.id})">
                  ${s.is_enabled ? 'Enabled ✅' : 'Disabled ❌'}
                </button>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`;
  }
}

async function toggleSource(sourceId) {
  try {
    const res = await fetch(`/api/admin/sources/${sourceId}/toggle`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      if (typeof showToast === 'function') showToast(data.message, 'success');
      loadAdminAutomation();
    }
  } catch (e) {
    alert('Failed: ' + e.message);
  }
}

// ----------------- LOGS -----------------
async function loadAdminLogs() {
  const container = document.getElementById('adminLogsContainer');
  if (!container) return;

  try {
    const res = await fetch('/api/admin/logs');
    const data = await res.json();
    const crawlerLogs = data.crawler_logs || [];

    container.innerHTML = `
      <div class="card">
        <h3 style="color:#fff;font-size:1.1rem;margin-bottom:1rem;">📜 Collector Execution Logs</h3>
        <div style="overflow-x:auto;">
          <table class="table" style="width:100%;border-collapse:collapse;font-size:0.8rem;">
            <thead>
              <tr style="border-bottom:1px solid var(--border-color);text-align:left;color:var(--text-muted);">
                <th style="padding:0.5rem;">Collector</th>
                <th style="padding:0.5rem;">Status</th>
                <th style="padding:0.5rem;">Items Found</th>
                <th style="padding:0.5rem;">Items Added</th>
                <th style="padding:0.5rem;">Duration</th>
                <th style="padding:0.5rem;">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              ${crawlerLogs.slice(0, 25).map(l => `
                <tr style="border-bottom:1px solid var(--border-color);">
                  <td style="padding:0.5rem;font-weight:700;color:#fff;">${escapeHtml(l.collector_name || 'Crawler')}</td>
                  <td style="padding:0.5rem;"><span class="badge badge-success">${l.status || 'SUCCESS'}</span></td>
                  <td style="padding:0.5rem;color:#38bdf8;">${l.items_found || 0}</td>
                  <td style="padding:0.5rem;color:#4ade80;">${l.items_added || 0}</td>
                  <td style="padding:0.5rem;">${l.duration_seconds || 0}s</td>
                  <td style="padding:0.5rem;color:var(--text-muted);">${l.finished_at || l.timestamp || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">Error loading logs: ${e.message}</div>`;
  }
}
