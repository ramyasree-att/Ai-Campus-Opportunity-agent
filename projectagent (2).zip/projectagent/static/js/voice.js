/**
 * Multilingual Voice Assistant - Speech-to-Text & Text-to-Speech Web Speech API
 * Supports English (en-US), Telugu (te-IN), and Hindi (hi-IN)
 */

const VoiceAssistant = {
  recognition: null,
  isListening: false,
  synth: window.speechSynthesis || null,

  init() {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRec) {
      this.recognition = new SpeechRec();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.updateMicButtonUI(true);
        const langCode = AppState.currentLanguage || 'en';
        const msgMap = {
          en: 'Speak your request now (e.g., "Python notes", "Internships")...',
          te: 'ఇప్పుడు మాట్లాడండి (ఉదా: "ఇంటర్న్‌షిప్స్", "పైథాన్ నోట్స్")...',
          hi: 'अब बोलिए (जैसे: "इंटर्नशिप", "पायथन नोट्स")...'
        };
        showToast('info', 'Voice Assistant Listening 🎙️', msgMap[langCode] || msgMap.en);
      };

      this.recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log('Voice transcript:', transcript);
        this.handleVoiceCommand(transcript);
      };

      this.recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        this.isListening = false;
        this.updateMicButtonUI(false);
        if (event.error !== 'no-speech') {
          showToast('warning', 'Voice Input', 'Could not detect speech clearly. Please try again.');
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.updateMicButtonUI(false);
      };
    }

    const micBtn = document.getElementById('headerVoiceBtn');
    if (micBtn) {
      micBtn.addEventListener('click', () => {
        this.toggleListening();
      });
    }
  },

  toggleListening() {
    if (!this.recognition) {
      showToast('warning', 'Browser Compatibility', 'Speech Recognition is not supported on this browser. Use Chrome/Edge.');
      return;
    }

    if (this.isListening) {
      this.recognition.stop();
    } else {
      try {
        const langCode = AppState.currentLanguage || 'en';
        if (langCode === 'te') this.recognition.lang = 'te-IN';
        else if (langCode === 'hi') this.recognition.lang = 'hi-IN';
        else this.recognition.lang = 'en-US';

        this.recognition.start();
      } catch (e) {
        console.error('Recognition start error:', e);
      }
    }
  },

  updateMicButtonUI(active) {
    const micBtn = document.getElementById('headerVoiceBtn');
    if (micBtn) {
      if (active) {
        micBtn.classList.add('listening');
        micBtn.title = 'Listening... Click to stop';
      } else {
        micBtn.classList.remove('listening');
        micBtn.title = 'Voice Assistant (Click to Speak)';
      }
    }
  },

  speak(text) {
    if (!this.synth) return;
    try {
      this.synth.cancel();
      const cleanText = text.replace(/[*_#`[\]()]/g, '').slice(0, 300);
      const utterance = new SpeechSynthesisUtterance(cleanText);
      const langCode = AppState.currentLanguage || 'en';

      if (langCode === 'te') {
        utterance.lang = 'te-IN';
      } else if (langCode === 'hi') {
        utterance.lang = 'hi-IN';
      } else {
        utterance.lang = 'en-US';
      }

      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      this.synth.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  },

  handleVoiceCommand(transcript) {
    const lower = transcript.toLowerCase();
    showToast('info', 'Voice Command Detected 🎙️', `"${transcript}"`);

    const searchInput = document.getElementById('globalSearchInput');
    if (searchInput) searchInput.value = transcript;

    const langCode = AppState.currentLanguage || 'en';

    // Notes Commands
    if (lower.includes('notes') || lower.includes('python note') || lower.includes('java note') || lower.includes('c note') || lower.includes('నోట్స్') || lower.includes('नोट्स')) {
      if (lower.includes('java')) {
        this.speak(langCode === 'te' ? 'జావా నోట్స్ తెరుస్తున్నాను.' : (langCode === 'hi' ? 'जावा नोट्स खोल रहे हैं।' : 'Opening Java programming notes.'));
        navigateTo('notes');
        if (window.loadProgrammingNotes) window.loadProgrammingNotes('java');
      } else if (lower.includes('c') || lower.includes('pointer')) {
        this.speak(langCode === 'te' ? 'సి ప్రోగ్రామింగ్ నోట్స్ తెరుస్తున్నాను.' : (langCode === 'hi' ? 'सी प्रोग्रामिंग नोट्स खोल रहे हैं।' : 'Opening C programming notes.'));
        navigateTo('notes');
        if (window.loadProgrammingNotes) window.loadProgrammingNotes('c');
      } else {
        this.speak(langCode === 'te' ? 'పైథాన్ నోట్స్ తెరుస్తున్నాను.' : (langCode === 'hi' ? 'पायथन नोट्स खोल रहे हैं।' : 'Opening Python programming notes.'));
        navigateTo('notes');
        if (window.loadProgrammingNotes) window.loadProgrammingNotes('python');
      }
    } else if (lower.includes('sync') || lower.includes('crawler') || lower.includes('crawl') || lower.includes('refresh') || lower.includes('సెర్చ్') || lower.includes('सर्च')) {
      this.speak(langCode === 'te' ? 'ఇంటర్నెట్ నుండి లైవ్ అవకాశాలను సింక్ చేస్తున్నాను.' : (langCode === 'hi' ? 'इंटरनेट से लाइव अवसर सिंक कर रहे हैं।' : 'Syncing live opportunities from internet.'));
      if (window.triggerLiveCrawlerSync) window.triggerLiveCrawlerSync();
    } else if (lower.includes('internship') || lower.includes('ఇంటర్న్‌షిప్') || lower.includes('इंटर्नशिप')) {
      this.speak(langCode === 'te' ? 'మీకు సరిపోయే ఇంటర్న్‌షిప్‌లను చూపిస్తున్నాను.' : (langCode === 'hi' ? 'उपयुक्त इंटर्नशिप दिखा रहे हैं।' : 'Finding matching internships for your profile.'));
      navigateTo('internships');
      if (window.loadOpportunities) window.loadOpportunities('internships', transcript);
    } else if (lower.includes('event') || lower.includes('symposium') || lower.includes('college event') || lower.includes('ఈవెంట్') || lower.includes('इवेंट')) {
      this.speak(langCode === 'te' ? 'కాలేజీ ఈవెంట్‌లు మరియు సింపోజియంలను చూపిస్తున్నాను.' : (langCode === 'hi' ? 'कॉलेज इवेंट्स दिखा रहे हैं।' : 'Showing upcoming college events and symposiums.'));
      navigateTo('events');
      if (window.loadOpportunities) window.loadOpportunities('events', transcript);
    } else if (lower.includes('scholarship') || lower.includes('స్కాలర్‌షిప్') || lower.includes('स्कॉलरशिप')) {
      this.speak(langCode === 'te' ? 'స్కాలర్‌షిప్ అవకాశాలను చూపిస్తున్నాను.' : (langCode === 'hi' ? 'स्कॉलरशिप अवसर दिखा रहे हैं।' : 'Displaying scholarship opportunities.'));
      navigateTo('scholarships');
      if (window.loadOpportunities) window.loadOpportunities('scholarships', transcript);
    } else if (lower.includes('resume') || lower.includes('రెజ్యూమ్') || lower.includes('रिज्यूमे')) {
      this.speak(langCode === 'te' ? 'మీ రెజ్యూమ్ వివరాలను తెరుస్తున్నాను.' : (langCode === 'hi' ? 'रिज्यूमे विवरण खोल रहे हैं।' : 'Opening your student profile and resume details.'));
      navigateTo('profile');
    } else if (lower.includes('roadmap') || lower.includes('career') || lower.includes('రోడ్‌మ్యాప్')) {
      this.speak(langCode === 'te' ? 'కెరీర్ రోడ్‌మ్యాప్ తెరుస్తున్నాను.' : (langCode === 'hi' ? 'करियर रोडमैप खोल रहे हैं।' : 'Opening your career roadmap.'));
      navigateTo('roadmap');
    } else {
      // Send to AI Advisor chat in current language
      this.speak(langCode === 'te' ? 'పరిశీలిస్తున్నాను, దయచేసి వేచి ఉండండి.' : (langCode === 'hi' ? 'जाँच कर रहे हैं, कृपया प्रतीक्षा करें।' : 'Let me check that for you.'));
      if (window.sendAiAdvisorMessage) {
        window.sendAiAdvisorMessage(transcript);
        if (window.openAiChatDrawer) window.openAiChatDrawer();
      }
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  VoiceAssistant.init();
});

window.VoiceAssistant = VoiceAssistant;
