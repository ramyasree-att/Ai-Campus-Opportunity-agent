/**
 * Opportunity Exploration, 8 Categories, Filters, Details Modal, and AI Match Breakdown
 */

async function loadOpportunities(category = 'all', searchQuery = '', options = {}) {
  AppState.currentCategory = category;
  const gridContainer = document.getElementById('opportunitiesGrid');
  const titleEl = document.getElementById('oppViewTitle');
  const subtitleEl = document.getElementById('oppViewSubtitle');
  const countEl = document.getElementById('oppViewCount');

  const titleMap = {
    all: '🌐 All Opportunities',
    internships: '💼 Internships',
    hackathons: '⚡ Hackathons & Coding Contests',
    scholarships: '🎓 Scholarships & Financial Aid',
    competitions: '🏆 Competitions & Challenges',
    events: '🎪 Events & Technical Symposiums',
    workshops: '🛠️ Hands-on Engineering Workshops',
    certifications: '📜 Professional Certifications',
    placements: '🏢 Campus Placements'
  };

  const subtitleMap = {
    all: 'Comprehensive opportunity explorer across internships, hackathons, scholarships, competitions, and college events.',
    internships: 'Verified early career and research opportunities matched to your student profile & resume.',
    hackathons: 'Competitive coding marathons, Saturday college events, and innovation challenges.',
    scholarships: 'Government, corporate, and private financial scholarships (including Telangana ePASS & national awards).',
    competitions: 'National & international technical contests, case challenges, and coding cups.',
    events: 'College technical symposiums, research conferences, and Saturday workshops.',
    workshops: 'Hands-on engineering bootcamps, AI labs, and technical masterclasses.',
    certifications: 'Accredited industry certifications in Python, Cloud, AI, and Cybersecurity.',
    placements: 'Telangana engineering college placement records, top recruiters, and active campus drives.'
  };

  if (titleEl) titleEl.textContent = titleMap[category] || `${category.charAt(0).toUpperCase() + category.slice(1)} Opportunities`;
  if (subtitleEl) subtitleEl.textContent = subtitleMap[category] || 'Verified student opportunities matching your profile.';

  // Highlight active category quick pill
  document.querySelectorAll('.cat-pill-btn').forEach(btn => {
    const cat = btn.getAttribute('data-cat');
    if (cat === category || (category === 'all' && cat === 'all')) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  if (gridContainer) gridContainer.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--text-muted);"><div class="spinner" style="margin:0 auto 1rem;"></div>Finding verified opportunities matching your profile & resume... ⏳</div>`;

  const modeFilterEl = document.getElementById('oppModeFilter');
  const verFilterEl = document.getElementById('oppVerFilter');
  const sortFilterEl = document.getElementById('oppSortFilter');

  if (options.mode && modeFilterEl) modeFilterEl.value = options.mode;
  if (options.verification && verFilterEl) verFilterEl.value = options.verification;
  if (options.sort_by && sortFilterEl) sortFilterEl.value = options.sort_by;

  const modeFilter = modeFilterEl ? modeFilterEl.value : 'all';
  const verFilter = verFilterEl ? verFilterEl.value : 'all';
  const sortFilter = sortFilterEl ? sortFilterEl.value : 'deadline';

  const queryParams = new URLSearchParams({
    category: category,
    search: searchQuery || AppState.searchQuery || '',
    mode: modeFilter,
    verification: verFilter,
    sort_by: sortFilter
  });

  try {
    const res = await fetch(`/api/opportunities?${queryParams.toString()}`);
    const data = await res.json();

    if (data.success) {
      if (countEl) countEl.textContent = `${data.count} Available`;
      if (data.opportunities.length === 0) {
        gridContainer.innerHTML = `
          <div style="grid-column:1/-1;text-align:center;padding:4rem;background:var(--bg-surface-elevated);border-radius:var(--radius-md);">
            <div style="font-size:2.5rem;margin-bottom:0.5rem;">🔍</div>
            <h3 style="color:#fff;margin-bottom:0.5rem;">No matching opportunities found for this category</h3>
            <p style="color:var(--text-muted);margin-bottom:1.5rem;">Try syncing with the live internet crawler or adjusting your filters.</p>
            <div style="display:flex;gap:0.75rem;justify-content:center;flex-wrap:wrap;">
              <button class="btn btn-primary" onclick="triggerLiveCrawlerSync()">🔄 Sync Live Internet</button>
              <button class="btn btn-secondary" onclick="resetOpportunityFilters()">Reset Filters</button>
            </div>
          </div>
        `;
      } else {
        gridContainer.innerHTML = data.opportunities.map(opp => renderOpportunityCardHtml(opp)).join('');
      }
    }
  } catch (err) {
    console.error('Error fetching opportunities:', err);
    if (gridContainer) {
      gridContainer.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:2rem;color:var(--danger);">Failed to load opportunities.</div>`;
    }
  }
}

function renderOpportunityCardHtml(opp) {
  const dBadge = opp.deadline_badge || { badge_text: 'Rolling Basis', badge_class: 'badge-neutral' };
  const isSaved = opp.is_saved;
  const isApplied = opp.is_applied;
  const isExpired = opp.is_expired || dBadge.level === 'expired';
  const matchScore = opp.match_score || 70;
  const skillGap = opp.skill_gap || { has_gap: false, missing_skills: [] };

  const rewardTag = opp.stipend_or_reward ? `<span class="badge badge-info">${opp.stipend_or_reward}</span>` : '';
  const verClass = opp.verification_status.includes('Verified') ? 'badge-verified' : (isExpired ? 'badge-expired' : 'badge-warning');

  let skillGapHtml = '';
  if (skillGap.has_gap && skillGap.missing_skills.length > 0) {
    const missingStr = skillGap.missing_skills.slice(0, 3).join(', ');
    const firstMissing = skillGap.missing_skills[0];
    skillGapHtml = `
      <div class="skill-gap-alert-card">
        <div class="skill-gap-header">
          <span>⚠️ SKILL GAP DETECTED</span>
        </div>
        <div style="color:var(--text-muted);font-size:0.8rem;margin-bottom:0.4rem;">
          Missing: <strong>${missingStr}</strong>
        </div>
        <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
          <button class="btn btn-sm btn-outline" style="font-size:0.75rem;padding:0.25rem 0.6rem;" onclick="triggerCreateLearningPlan('${firstMissing}')">
            Create 7-Day Plan (${firstMissing}) →
          </button>
          <button class="btn btn-sm btn-secondary" style="font-size:0.75rem;padding:0.25rem 0.6rem;" onclick="navigateTo('notes')">
            📖 Study Notes
          </button>
        </div>
      </div>
    `;
  }

  let applyButtonHtml = '';
  if (isExpired) {
    applyButtonHtml = `<span class="badge badge-expired" style="padding:0.5rem 0.8rem;">Deadline Passed ❌</span>`;
  } else if (isApplied) {
    applyButtonHtml = `<span class="badge badge-success" style="padding:0.5rem 0.8rem;">Applied ✅</span>`;
  } else {
    applyButtonHtml = `
      <button class="btn btn-sm btn-primary" onclick="initiateApplicationPreview(${opp.id})">
        Apply Now 🚀
      </button>
    `;
  }

  return `
    <div class="opportunity-card ${isExpired ? 'opp-card-expired' : ''}" id="opp-card-${opp.id}">
      <div class="opp-card-top">
        <div>
          <div class="opp-card-title">${opp.title}</div>
          <div class="opp-card-org">${opp.organization}</div>
        </div>
        <div class="match-score-pill" title="AI Personalized Match Score">
          🎯 ${matchScore}%
        </div>
      </div>

      <div class="opp-card-meta">
        ${isExpired ? '<span class="badge badge-danger">DEADLINE EXPIRED ❌</span>' : `<span class="badge ${dBadge.badge_class}">${dBadge.badge_text}</span>`}
        <span class="badge ${opp.eligibility_badge_class || 'badge-success'}">${opp.eligibility_status || 'ELIGIBLE ✅'}</span>
        <span class="badge ${verClass}">${opp.verification_status}</span>
        <span class="badge badge-neutral">${opp.mode} • ${opp.location}</span>
        ${rewardTag}
      </div>

      <div class="opp-card-desc">
        ${opp.description}
      </div>

      ${skillGapHtml}

      <div style="font-size:0.8rem;color:var(--text-subtle);margin-bottom:0.85rem;">
        <strong>Eligibility:</strong> ${opp.eligibility || 'Open to all students'}
      </div>

      <div class="opp-card-actions">
        <button class="btn btn-sm btn-secondary" onclick="openOpportunityDetailsModal(${opp.id})">
          View Details
        </button>
        <button class="btn btn-sm btn-icon ${isSaved ? 'btn-primary' : 'btn-secondary'}" onclick="toggleSaveOpportunity(${opp.id})" title="${isSaved ? 'Remove from Saved' : 'Save Opportunity'}">
          ${isSaved ? '📌 Saved' : 'Save 📌'}
        </button>
        ${applyButtonHtml}
      </div>
    </div>
  `;
}

async function openOpportunityDetailsModal(oppId) {
  try {
    const res = await fetch(`/api/opportunities/${oppId}`);
    const data = await res.json();
    if (!data.success) {
      showToast('error', 'Error', data.message || 'Could not load details.');
      return;
    }

    const opp = data.opportunity;
    const modalContent = document.getElementById('oppDetailModalBody');
    if (!modalContent) return;

    const bk = opp.match_breakdown || { skills: 35, max_skills: 40, branch: 25, max_branch: 25, year: 20, max_year: 20, interest: 12, max_interest: 15 };
    const skillGap = opp.skill_gap || { has_gap: false, missing_skills: [] };
    const isExpired = opp.is_expired;

    modalContent.innerHTML = `
      <div style="margin-bottom:1.5rem;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:0.5rem;">
          <h2 style="color:#fff;font-size:1.35rem;">${opp.title}</h2>
          <div class="match-score-pill" style="font-size:1rem;padding:0.4rem 1rem;">
            Match: ${opp.match_score}%
          </div>
        </div>
        <div style="font-size:0.95rem;color:var(--secondary);font-weight:600;">${opp.organization}</div>
      </div>

      <!-- Match Score & AI Rationale -->
      <div style="background:var(--bg-input);border:1px solid var(--border-highlight);border-radius:var(--radius-md);padding:1.25rem;margin-bottom:1.5rem;">
        <div style="font-weight:700;color:#fff;margin-bottom:0.6rem;display:flex;align-items:center;gap:0.4rem;">
          <span>🤖 AI Personalized Match Breakdown</span>
        </div>
        <div style="font-size:0.875rem;color:var(--text-muted);margin-bottom:0.85rem;">
          <strong>Why this opportunity matches you:</strong> ${opp.why_it_matches}
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(130px, 1fr));gap:0.75rem;">
          <div style="background:var(--bg-surface);padding:0.6rem 0.8rem;border-radius:var(--radius-sm);">
            <span style="font-size:0.75rem;color:var(--text-subtle);">Skills (Max 40)</span>
            <div style="font-weight:700;color:#38bdf8;">${bk.skills} / 40</div>
          </div>
          <div style="background:var(--bg-surface);padding:0.6rem 0.8rem;border-radius:var(--radius-sm);">
            <span style="font-size:0.75rem;color:var(--text-subtle);">Branch (Max 25)</span>
            <div style="font-weight:700;color:#818cf8;">${bk.branch} / 25</div>
          </div>
          <div style="background:var(--bg-surface);padding:0.6rem 0.8rem;border-radius:var(--radius-sm);">
            <span style="font-size:0.75rem;color:var(--text-subtle);">Year (Max 20)</span>
            <div style="font-weight:700;color:#c084fc;">${bk.year} / 20</div>
          </div>
          <div style="background:var(--bg-surface);padding:0.6rem 0.8rem;border-radius:var(--radius-sm);">
            <span style="font-size:0.75rem;color:var(--text-subtle);">Interests (Max 15)</span>
            <div style="font-weight:700;color:#f472b6;">${bk.interest} / 15</div>
          </div>
        </div>
      </div>

      <!-- Eligibility & Verification -->
      <div class="card" style="margin-bottom:1.5rem;">
        <h4 style="color:#fff;margin-bottom:0.5rem;font-size:0.95rem;">Eligibility Verification</h4>
        <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.5rem;">
          <span class="badge ${opp.eligibility_badge_class}">${opp.eligibility_status}</span>
        </div>
        <p style="font-size:0.875rem;color:var(--text-muted);">${opp.eligibility_reason}</p>
      </div>

      <!-- Skill Gap Analysis -->
      ${
        skillGap.has_gap
          ? `
          <div class="skill-gap-alert-card" style="margin-bottom:1.5rem;">
            <div class="skill-gap-header">
              <span>⚠️ SKILL GAP WARNING</span>
            </div>
            <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:0.75rem;">
              ${skillGap.warning_message}
            </p>
            <div style="display:flex;gap:0.5rem;">
              <button class="btn btn-sm btn-primary" onclick="closeModal('oppDetailModal'); triggerCreateLearningPlan('${skillGap.missing_skills[0]}');">
                Create 7-Day Fast-Track Plan (${skillGap.missing_skills[0]}) →
              </button>
            </div>
          </div>
        `
          : ''
      }

      <!-- Detailed Description -->
      <div style="margin-bottom:1.5rem;">
        <h4 style="color:#fff;margin-bottom:0.4rem;font-size:0.95rem;">Opportunity Overview</h4>
        <p style="font-size:0.875rem;line-height:1.6;color:var(--text-main);">${opp.description}</p>
      </div>

      <!-- Meta Grid -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:1rem;background:var(--bg-surface);padding:1rem;border-radius:var(--radius-sm);margin-bottom:1.5rem;font-size:0.85rem;">
        <div><span style="color:var(--text-subtle);">DEADLINE:</span> <strong style="color:#fff;">${opp.deadline || 'Rolling Basis'}</strong></div>
        <div><span style="color:var(--text-subtle);">MODE & LOCATION:</span> <strong style="color:#fff;">${opp.mode} (${opp.location})</strong></div>
        <div><span style="color:var(--text-subtle);">STIPEND / PRIZE:</span> <strong style="color:#38bdf8;">${opp.stipend_or_reward || 'Disclosed upon selection'}</strong></div>
        <div><span style="color:var(--text-subtle);">SOURCE:</span> <strong style="color:#fff;">${opp.source}</strong></div>
      </div>

      <!-- Footer Buttons -->
      <div style="display:flex;justify-content:flex-end;gap:0.75rem;">
        <button class="btn btn-secondary close-modal-btn">Close</button>
        ${
          isExpired
            ? `<button class="btn btn-danger" disabled style="opacity:0.6;">Deadline Passed</button>`
            : `<button class="btn btn-primary" onclick="closeModal('oppDetailModal'); initiateApplicationPreview(${opp.id});">
                Proceed to Apply 🚀
              </button>`
        }
      </div>
    `;

    openModal('oppDetailModal');
  } catch (err) {
    showToast('error', 'Server Error', 'Failed to fetch opportunity details.');
  }
}

async function toggleSaveOpportunity(oppId) {
  try {
    const res = await fetch(`/api/opportunities/${oppId}/save`, { method: 'POST' });
    const result = await res.json();
    if (result.success) {
      showToast('success', result.is_saved ? 'Opportunity Saved 📌' : 'Opportunity Unsaved', result.message);
      if (AppState.activeView === 'saved') {
        loadSavedOpportunities();
      } else {
        loadOpportunities(AppState.currentCategory);
      }
    }
  } catch (err) {
    showToast('error', 'Error', 'Could not update saved status.');
  }
}

async function loadSavedOpportunities() {
  const container = document.getElementById('savedOpportunitiesGrid');
  if (!container) return;

  container.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--text-muted);">Loading your saved bookmarks... ⏳</div>`;

  try {
    const res = await fetch('/api/opportunities/saved');
    const data = await res.json();

    if (data.success) {
      if (data.opportunities.length === 0) {
        container.innerHTML = `
          <div style="grid-column:1/-1;text-align:center;padding:4rem;background:var(--bg-surface-elevated);border-radius:var(--radius-md);">
            <div style="font-size:2.5rem;margin-bottom:0.5rem;">📌</div>
            <h3 style="color:#fff;margin-bottom:0.5rem;">No Saved Opportunities Yet</h3>
            <p style="color:var(--text-muted);margin-bottom:1.5rem;">Click the bookmark pin on any opportunity card to save it here.</p>
            <button class="btn btn-primary" onclick="navigateTo('internships')">Browse Internships →</button>
          </div>
        `;
      } else {
        container.innerHTML = data.opportunities.map(opp => renderOpportunityCardHtml(opp)).join('');
      }
    }
  } catch (err) {
    container.innerHTML = `<div style="grid-column:1/-1;color:var(--danger);text-align:center;">Failed to load saved opportunities.</div>`;
  }
}

function resetOpportunityFilters() {
  const mode = document.getElementById('oppModeFilter');
  const ver = document.getElementById('oppVerFilter');
  const sort = document.getElementById('oppSortFilter');
  const search = document.getElementById('globalSearchInput');

  if (mode) mode.value = 'all';
  if (ver) ver.value = 'all';
  if (sort) sort.value = 'deadline';
  if (search) search.value = '';
  AppState.searchQuery = '';

  loadOpportunities(AppState.currentCategory);
}

function triggerCreateLearningPlan(skillName) {
  if (window.generateLearningPlanForSkill) {
    window.generateLearningPlanForSkill(skillName);
  }
}

window.loadOpportunities = loadOpportunities;
window.renderOpportunityCardHtml = renderOpportunityCardHtml;
window.openOpportunityDetailsModal = openOpportunityDetailsModal;
window.toggleSaveOpportunity = toggleSaveOpportunity;
window.loadSavedOpportunities = loadSavedOpportunities;
window.resetOpportunityFilters = resetOpportunityFilters;
window.triggerCreateLearningPlan = triggerCreateLearningPlan;
