/**
 * Two-Click Application Workflow (with safety confirmation) & Application Tracker
 */

let currentApplyingOppId = null;

// ==========================================
// STEP 1: INITIATE APPLICATION PREVIEW
// ==========================================
async function initiateApplicationPreview(oppId) {
  currentApplyingOppId = oppId;
  try {
    const res = await fetch(`/api/applications/prepare/${oppId}`);
    const data = await res.json();

    if (!data.success) {
      showToast('error', 'Error', data.message || 'Could not prepare application.');
      return;
    }

    const preview = data.preview;
    const std = preview.student_details;

    const modalBody = document.getElementById('appPreviewModalBody');
    if (!modalBody) return;

    modalBody.innerHTML = `
      <div style="background:var(--primary-light);border:1px solid rgba(99,102,241,0.3);border-radius:var(--radius-md);padding:1rem 1.25rem;margin-bottom:1.5rem;">
        <div style="display:flex;align-items:center;gap:0.6rem;font-weight:700;color:#fff;margin-bottom:0.25rem;">
          <span>🤖 AI Application Assistant</span>
        </div>
        <div style="font-size:0.875rem;color:var(--text-main);">
          Application details prepared automatically from your student profile for <strong>${preview.opportunity_title}</strong> at <strong>${preview.organization}</strong>.
        </div>
      </div>

      <div style="margin-bottom:1.5rem;">
        <h4 style="color:#fff;margin-bottom:0.75rem;font-size:1rem;">Application Preview (Review & Confirm)</h4>
        
        <form id="appPreviewForm" onsubmit="event.preventDefault();">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <input type="text" id="appPrevName" class="form-control" value="${std.name || ''}" required>
            </div>
            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input type="email" id="appPrevEmail" class="form-control" value="${std.email || ''}" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Contact Number</label>
              <input type="text" id="appPrevContact" class="form-control" value="${std.contact_number || ''}" required>
            </div>
            <div class="form-group">
              <label class="form-label">Father Name</label>
              <input type="text" id="appPrevFather" class="form-control" value="${std.father_name || ''}">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">College Name</label>
              <input type="text" id="appPrevCollege" class="form-control" value="${std.college_name || ''}" required>
            </div>
            <div class="form-group">
              <label class="form-label">Branch & Academic Year</label>
              <input type="text" id="appPrevBranchYear" class="form-control" value="${std.branch || ''} - ${std.academic_year || ''}">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">CGPA / Percentage</label>
              <input type="text" id="appPrevCgpa" class="form-control" value="${std.cgpa ? std.cgpa + ' CGPA' : ''}">
            </div>
            <div class="form-group">
              <label class="form-label">Preferred Location</label>
              <input type="text" id="appPrevLocation" class="form-control" value="${std.preferred_location || 'Any / Remote'}">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Skills & Competencies</label>
            <input type="text" id="appPrevSkills" class="form-control" value="${std.skills || ''}">
          </div>

          <div class="form-group">
            <label class="form-label">Cover Statement / Personal Pitch</label>
            <textarea id="appPrevNotes" class="form-control" rows="2">${std.additional_notes || ''}</textarea>
          </div>
        </form>
      </div>

      <div style="background:rgba(239, 68, 68, 0.08);border:1px solid rgba(239, 68, 68, 0.25);border-radius:var(--radius-sm);padding:0.85rem 1rem;margin-bottom:1.5rem;font-size:0.825rem;color:var(--text-muted);">
        <strong style="color:#f87171;">⚠️ Application Safety Rule:</strong> The AI will NEVER submit without your explicit confirmation. Review your details and click <strong>[CONFIRM & SUBMIT]</strong> to proceed.
      </div>

      <div style="display:flex;align-items:center;justify-content:flex-end;gap:0.75rem;">
        <button type="button" class="btn btn-secondary" onclick="closeModal('appPreviewModal')">Cancel</button>
        <button type="button" class="btn btn-primary" id="confirmSubmitBtn" onclick="confirmAndSubmitApplication(${oppId})">
          CONFIRM & SUBMIT ✅
        </button>
      </div>
    `;

    openModal('appPreviewModal');
  } catch (err) {
    console.error('Error preparing application preview:', err);
    showToast('error', 'Server Error', 'Failed to prepare application preview.');
  }
}

// ==========================================
// STEP 2: CONFIRM & SUBMIT APPLICATION
// ==========================================
async function confirmAndSubmitApplication(oppId) {
  const submitBtn = document.getElementById('confirmSubmitBtn');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting... ⏳';
  }

  const verifiedData = {
    name: document.getElementById('appPrevName') ? document.getElementById('appPrevName').value : '',
    email: document.getElementById('appPrevEmail') ? document.getElementById('appPrevEmail').value : '',
    contact_number: document.getElementById('appPrevContact') ? document.getElementById('appPrevContact').value : '',
    college_name: document.getElementById('appPrevCollege') ? document.getElementById('appPrevCollege').value : '',
    branch_year: document.getElementById('appPrevBranchYear') ? document.getElementById('appPrevBranchYear').value : '',
    cgpa: document.getElementById('appPrevCgpa') ? document.getElementById('appPrevCgpa').value : '',
    skills: document.getElementById('appPrevSkills') ? document.getElementById('appPrevSkills').value : '',
    notes: document.getElementById('appPrevNotes') ? document.getElementById('appPrevNotes').value : ''
  };

  try {
    const res = await fetch('/api/applications/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        opportunity_id: oppId,
        student_details: verifiedData
      })
    });
    const result = await res.json();

    closeModal('appPreviewModal');

    if (result.success) {
      showToast('success', 'Application Submitted! ✅', result.message);

      // Open Success & Verified Portal Modal
      openApplicationSuccessModal(result);

      // Refresh data
      if (AppState.activeView === 'applications') {
        loadApplicationsTracker();
      } else {
        loadOpportunities(AppState.currentCategory);
      }
    } else {
      showToast('error', 'Submission Failed', result.message || 'Could not record application.');
    }
  } catch (err) {
    console.error('Submission error:', err);
    showToast('error', 'Server Error', 'Could not complete application submission.');
  }
}

function openApplicationSuccessModal(result) {
  const modalBody = document.getElementById('appSuccessModalBody');
  if (!modalBody) return;

  const dispatch = result.dispatch_details || {};
  const txnId = dispatch.tracking_id || `TXN-COMP-${Date.now()}`;

  modalBody.innerHTML = `
    <div style="text-align:center;padding:1.5rem 0;">
      <div style="font-size:3.5rem;margin-bottom:1rem;">🚀</div>
      <h2 style="color:#fff;font-size:1.4rem;margin-bottom:0.5rem;">STATUS: SUBMITTED TO COMPANY ✅</h2>
      <p style="color:var(--text-muted);font-size:0.95rem;margin-bottom:1.5rem;">
        Your verified application for <strong>${result.opportunity_title}</strong> has been automatically dispatched directly to <strong>${result.organization}</strong>!
      </p>

      <div style="background:var(--bg-input);border:1px solid var(--border-highlight);border-radius:var(--radius-md);padding:1.25rem;margin-bottom:1.5rem;text-align:left;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;">
          <span style="font-size:0.75rem;color:var(--text-subtle);font-weight:700;">COMPANY DISPATCH RECEIPT</span>
          <span class="badge badge-success" style="font-size:0.7rem;">DISPATCHED & LOGGED</span>
        </div>
        <div style="font-size:0.9rem;color:#38bdf8;font-family:'JetBrains Mono',monospace;margin-bottom:0.5rem;">
          Ref ID: <strong>${txnId}</strong>
        </div>
        <p style="font-size:0.85rem;color:var(--text-muted);line-height:1.5;margin-bottom:0.4rem;">
          📱 An instant SMS confirmation has been dispatched to your registered phone number.
        </p>
      </div>

      <div style="display:flex;justify-content:center;gap:1rem;flex-wrap:wrap;">
        <button class="btn btn-secondary" onclick="closeModal('appSuccessModal'); navigateTo('applications');">
          View in Tracker 📋
        </button>
        <a href="${result.application_url}" target="_blank" class="btn btn-primary">
          Company Portal ↗
        </a>
      </div>
    </div>
  `;

  openModal('appSuccessModal');
}

// ==========================================
// APPLICATION TRACKER VIEW
// ==========================================
async function loadApplicationsTracker() {
  const trackerGrid = document.getElementById('trackerGridContainer');
  if (!trackerGrid) return;

  trackerGrid.innerHTML = `<div style="text-align:center;padding:3rem;color:var(--text-muted);">Loading application tracker... ⏳</div>`;

  try {
    const res = await fetch('/api/applications/my');
    const data = await res.json();

    if (data.success) {
      // Update Summary Stats
      const st = data.stats;
      if (document.getElementById('trkTotalCount')) document.getElementById('trkTotalCount').textContent = st.total;
      if (document.getElementById('trkShortlistedCount')) document.getElementById('trkShortlistedCount').textContent = st.shortlisted;
      if (document.getElementById('trkInterviewCount')) document.getElementById('trkInterviewCount').textContent = st.interviews;
      if (document.getElementById('trkSelectedCount')) document.getElementById('trkSelectedCount').textContent = st.selected;

      if (data.applications.length === 0) {
        trackerGrid.innerHTML = `
          <div style="text-align:center;padding:4rem;background:var(--bg-surface-elevated);border-radius:var(--radius-md);">
            <div style="font-size:2.5rem;margin-bottom:0.5rem;">📋</div>
            <h3 style="color:#fff;margin-bottom:0.5rem;">No applications tracked yet</h3>
            <p style="color:var(--text-muted);margin-bottom:1.5rem;">Start exploring internships and hackathons to apply with our 2-click experience.</p>
            <button class="btn btn-primary" onclick="navigateTo('internships')">Explore Internships</button>
          </div>
        `;
        return;
      }

      // Render Application Cards in Pipeline
      trackerGrid.innerHTML = `
        <div style="display:flex;flex-direction:column;gap:1rem;">
          ${data.applications.map(app => `
            <div class="card card-hover" style="display:flex;align-items:center;justify-content:space-between;gap:1.5rem;flex-wrap:wrap;">
              <div>
                <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:0.35rem;">
                  <span class="badge ${getStatusBadgeClass(app.status)}">${app.status}</span>
                  <span class="badge badge-neutral">${app.category}</span>
                  <span style="font-size:0.8rem;color:var(--text-subtle);">Applied on ${app.applied_at ? app.applied_at.split(' ')[0] : 'Today'}</span>
                </div>
                <h3 style="color:#fff;font-size:1.15rem;margin-bottom:0.2rem;">${app.title}</h3>
                <div style="font-size:0.875rem;color:var(--secondary);">${app.organization} • ${app.location} (${app.mode})</div>
              </div>

              <div style="display:flex;align-items:center;gap:1rem;">
                <div style="display:flex;flex-direction:column;gap:0.3rem;">
                  <label style="font-size:0.75rem;color:var(--text-subtle);font-weight:600;">UPDATE STATUS</label>
                  <select class="form-control" style="padding:0.4rem 0.8rem;font-size:0.85rem;min-width:140px;" onchange="updateAppStatus(${app.application_id}, this.value)">
                    <option value="Applied" ${app.status === 'Applied' ? 'selected' : ''}>Applied</option>
                    <option value="Shortlisted" ${app.status === 'Shortlisted' ? 'selected' : ''}>Shortlisted</option>
                    <option value="Interview" ${app.status === 'Interview' ? 'selected' : ''}>Interview</option>
                    <option value="Selected" ${app.status === 'Selected' ? 'selected' : ''}>Selected 🎉</option>
                    <option value="Rejected" ${app.status === 'Rejected' ? 'selected' : ''}>Rejected</option>
                  </select>
                </div>
                <a href="${app.application_url}" target="_blank" class="btn btn-sm btn-outline" style="align-self:flex-end;">
                  Portal ↗
                </a>
              </div>
            </div>
          `).join('')}
        </div>
      `;
    }
  } catch (err) {
    console.error('Error fetching tracker data:', err);
    trackerGrid.innerHTML = `<div style="color:var(--danger);text-align:center;">Failed to load applications tracker.</div>`;
  }
}

function getStatusBadgeClass(status) {
  switch (status) {
    case 'Selected': return 'badge-success';
    case 'Interview': return 'badge-info';
    case 'Shortlisted': return 'badge-warning';
    case 'Rejected': return 'badge-danger';
    default: return 'badge-verified';
  }
}

async function updateAppStatus(appId, newStatus) {
  try {
    const res = await fetch(`/api/applications/${appId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    const result = await res.json();
    if (result.success) {
      showToast('success', 'Status Updated', result.message);
      loadApplicationsTracker();
    }
  } catch (err) {
    showToast('error', 'Error', 'Could not update application status.');
  }
}

window.initiateApplicationPreview = initiateApplicationPreview;
window.confirmAndSubmitApplication = confirmAndSubmitApplication;
window.loadApplicationsTracker = loadApplicationsTracker;
window.updateAppStatus = updateAppStatus;
