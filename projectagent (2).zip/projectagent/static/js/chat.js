/**
 * Multilingual AI Career Advisor & Help/Support Chat Drawer (English, Telugu, Hindi)
 */

function openAiChatDrawer() {
  const drawer = document.getElementById('aiChatDrawer');
  if (drawer) drawer.classList.add('active');
}

function closeAiChatDrawer() {
  const drawer = document.getElementById('aiChatDrawer');
  if (drawer) drawer.classList.remove('active');
}

function toggleAiChatDrawer() {
  const drawer = document.getElementById('aiChatDrawer');
  if (drawer) drawer.classList.toggle('active');
}

async function sendAiAdvisorMessage(customPrompt = null) {
  const inputEl = document.getElementById('aiChatInput');
  const messagesContainer = document.getElementById('aiChatMessages');
  if (!messagesContainer) return;

  const prompt = customPrompt || (inputEl ? inputEl.value.trim() : '');
  if (!prompt) return;

  if (inputEl && !customPrompt) inputEl.value = '';

  // Append User message bubble
  const userBubble = document.createElement('div');
  userBubble.className = 'chat-bubble chat-bubble-user';
  userBubble.textContent = prompt;
  messagesContainer.appendChild(userBubble);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;

  // Append AI typing placeholder
  const aiBubble = document.createElement('div');
  aiBubble.className = 'chat-bubble chat-bubble-ai';
  aiBubble.innerHTML = `<em>Thinking... 🤖</em>`;
  messagesContainer.appendChild(aiBubble);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;

  const currentLang = AppState.currentLanguage || 'en';

  try {
    const res = await fetch('/api/ai/advisor', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: prompt,
        language: currentLang
      })
    });
    const data = await res.json();

    if (data.success) {
      let formatted = data.response
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n\n/g, '<br><br>')
        .replace(/\n- /g, '<br>• ');

      aiBubble.innerHTML = formatted;

      // Speak response if in voice mode
      if (window.VoiceAssistant && window.VoiceAssistant.isListening) {
        window.VoiceAssistant.speak(data.response);
      }
    } else {
      aiBubble.innerHTML = `<span style="color:var(--danger);">${data.message || 'Could not reach advisor.'}</span>`;
    }
  } catch (err) {
    aiBubble.innerHTML = `<span style="color:var(--danger);">Error getting advice. Please try again.</span>`;
  }

  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

document.addEventListener('DOMContentLoaded', () => {
  const chatForm = document.getElementById('aiChatForm');
  if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      sendAiAdvisorMessage();
    });
  }

  const toggleBtn = document.getElementById('floatingAiAdvisorBtn');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', toggleAiChatDrawer);
  }

  const closeBtn = document.getElementById('closeAiChatBtn');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeAiChatDrawer);
  }
});

window.openAiChatDrawer = openAiChatDrawer;
window.closeAiChatDrawer = closeAiChatDrawer;
window.toggleAiChatDrawer = toggleAiChatDrawer;
window.sendAiAdvisorMessage = sendAiAdvisorMessage;
