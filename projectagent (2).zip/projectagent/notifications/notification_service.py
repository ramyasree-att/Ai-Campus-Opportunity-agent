import logging
from datetime import datetime, date, timedelta
from database.db import get_db_connection
from automation.deduplication import generate_notification_fingerprint
from notifications.providers.sms import SMSNotificationProvider
from notifications.providers.email import EmailNotificationProvider

logger = logging.getLogger("NotificationService")

sms_provider = SMSNotificationProvider()
email_provider = EmailNotificationProvider()

def get_user_notification_preferences(user_id):
    """Retrieves or creates default notification preferences for the user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM notification_preferences WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()

    if not row:
        cursor.execute("""
        INSERT INTO notification_preferences (user_id, internships_enabled, scholarships_enabled, events_enabled, deadlines_enabled, frequency, sms_enabled, email_enabled)
        VALUES (?, 1, 1, 1, 1, 'IMMEDIATE', 1, 1)
        """, (user_id,))
        conn.commit()
        cursor.execute("SELECT * FROM notification_preferences WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()

    prefs = dict(row)
    conn.close()
    return prefs

def update_user_notification_preferences(user_id, data):
    """Updates user notification preferences."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
    UPDATE notification_preferences
    SET internships_enabled = ?, scholarships_enabled = ?, events_enabled = ?,
        deadlines_enabled = ?, frequency = ?, sms_enabled = ?, email_enabled = ?,
        updated_at = CURRENT_TIMESTAMP
    WHERE user_id = ?
    """, (
        data.get("internships_enabled", 1),
        data.get("scholarships_enabled", 1),
        data.get("events_enabled", 1),
        data.get("deadlines_enabled", 1),
        data.get("frequency", "IMMEDIATE"),
        data.get("sms_enabled", 1),
        data.get("email_enabled", 1),
        user_id
    ))
    conn.commit()
    conn.close()
    return {"success": True, "message": "Notification preferences updated."}

def send_targeted_notification(user_id, title, message, category="info", target_id="general"):
    """
    Sends targeted in-app, SMS, and Email alerts adhering to user preferences
    and deduplication fingerprints.
    """
    fingerprint = generate_notification_fingerprint(user_id, title, target_id)
    
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Check duplicate fingerprint within past 24 hours
    cursor.execute("""
    SELECT id FROM notifications
    WHERE user_id = ? AND fingerprint = ? AND created_at > datetime('now', '-1 day')
    """, (user_id, fingerprint))
    if cursor.fetchone():
        conn.close()
        return {"success": False, "message": "Duplicate notification skipped."}

    # 2. Get user info and preferences
    cursor.execute("SELECT email, contact_number FROM users WHERE id = ?", (user_id,))
    user_row = cursor.fetchone()
    if not user_row:
        conn.close()
        return {"success": False, "message": "User not found."}

    user_email = user_row["email"]
    user_phone = user_row["contact_number"]
    prefs = get_user_notification_preferences(user_id)

    # 3. Create In-App Notification
    cursor.execute("""
    INSERT INTO notifications (user_id, title, message, type, fingerprint, sent_to_contact, contact_number)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (user_id, title, message, category, fingerprint, 1 if user_phone else 0, user_phone))
    notif_id = cursor.lastrowid
    conn.commit()
    conn.close()

    # 4. Multi-channel dispatch (SMS & Email)
    if user_phone and prefs.get("sms_enabled", 1):
        sms_res = sms_provider.send(user_phone, title, message)
        # Log SMS
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO sms_logs (user_id, contact_number, title, message, status, gateway)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, user_phone, title, message, sms_res.get("status", "DELIVERED"), sms_res.get("provider", "SMS Gateway")))
        conn.commit()
        conn.close()

    if user_email and prefs.get("email_enabled", 1):
        email_provider.send(user_email, title, message)

    return {"success": True, "notification_id": notif_id, "message": "Notification dispatched."}

def run_deadline_alert_dispatcher():
    """
    Scans approaching deadlines (7 days, 3 days, 1 day, deadline day)
    and notifies matching candidates.
    """
    today = date.today()
    target_days = [7, 3, 1, 0]

    conn = get_db_connection()
    cursor = conn.cursor()

    for days in target_days:
        target_date_str = (today + timedelta(days=days)).isoformat()
        cursor.execute("""
        SELECT id, title, organization, category, deadline FROM opportunities
        WHERE deadline = ? AND is_expired = 0
        """, (target_date_str,))
        opps = cursor.fetchall()

        for opp in opps:
            opp_title = opp["title"]
            opp_org = opp["organization"]
            opp_cat = opp["category"]

            # Query all active users
            cursor.execute("SELECT id, contact_number, email FROM users WHERE role = 'USER'")
            users = cursor.fetchall()

            for u in users:
                uid = u["id"]
                days_text = "TODAY!" if days == 0 else f"in {days} days ({opp['deadline']})"
                title = f"⏰ Deadline Alert: {opp_title}"
                message = f"Urgent: Application deadline for '{opp_title}' at {opp_org} closes {days_text}. Apply before the deadline passes!"
                send_targeted_notification(uid, title, message, category="deadline", target_id=f"opp_{opp['id']}_{days}d")

    conn.close()
