from abc import ABC, abstractmethod

class BaseNotificationProvider(ABC):
    """
    Abstract Base Class for multi-channel notification providers
    (SMS, Email, WhatsApp, Push).
    """
    def __init__(self, name):
        self.name = name

    @abstractmethod
    def send(self, recipient, title, message, metadata=None):
        """
        Sends notification to the recipient.
        Returns:
            {"success": bool, "provider": str, "status": "DELIVERED"|"FAILED"|"LOGGED", "message": str}
        """
        pass
