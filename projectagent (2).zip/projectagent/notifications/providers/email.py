import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import Config
from notifications.providers.base import BaseNotificationProvider

logger = logging.getLogger("EmailNotificationProvider")

class EmailNotificationProvider(BaseNotificationProvider):
    def __init__(self):
        super().__init__("EmailProvider")

    def send(self, recipient_email, title, message, metadata=None):
        """
        Dispatches email notification via SMTP.
        Gracefully logs if SMTP is not configured.
        """
        if not recipient_email:
            return {"success": False, "provider": self.name, "status": "FAILED", "message": "No email provided."}

        if Config.EMAIL_USERNAME and Config.EMAIL_PASSWORD:
            try:
                msg = MIMEMultipart()
                msg["From"] = Config.EMAIL_USERNAME
                msg["To"] = recipient_email
                msg["Subject"] = f"[Campus Agent] {title}"
                msg.attach(MIMEText(message, "plain"))

                server = smtplib.SMTP(Config.EMAIL_HOST, Config.EMAIL_PORT, timeout=10)
                server.starttls()
                server.login(Config.EMAIL_USERNAME, Config.EMAIL_PASSWORD)
                server.send_message(msg)
                server.quit()
                return {"success": True, "provider": "SMTP Live Email", "status": "DELIVERED", "message": "Email sent."}
            except Exception as e:
                logger.error(f"SMTP error: {e}")

        logger.info(f"[EMAIL NOTIFICATION LOGGED] To: {recipient_email} | Subject: {title} | Message: {message}")
        return {"success": True, "provider": "Simulated Email Gateway", "status": "DELIVERED", "message": f"Email alert logged for {recipient_email}."}
