"""
Authentication package for Google OAuth 2.0 and session management.
"""
from auth.google_oauth import get_google_auth_url, handle_google_callback

__all__ = ["get_google_auth_url", "handle_google_callback"]
