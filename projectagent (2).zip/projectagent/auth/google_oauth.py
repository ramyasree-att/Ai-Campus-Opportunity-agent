"""
Google OAuth 2.0 Flow Handler for Campus Opportunity Agent.
Integrates Google Sign-In with graceful fallback when credentials are not configured.
"""
import os
import urllib.parse
import requests
from datetime import datetime
from config import Config
from database.db import get_db_connection

GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_ENDPOINT = "https://www.googleapis.com/oauth2/v2/userinfo"

def is_google_oauth_configured() -> bool:
    """Checks whether Google OAuth client ID and client secret are populated."""
    client_id = getattr(Config, "GOOGLE_CLIENT_ID", None) or os.getenv("GOOGLE_CLIENT_ID", "")
    client_secret = getattr(Config, "GOOGLE_CLIENT_SECRET", None) or os.getenv("GOOGLE_CLIENT_SECRET", "")
    return bool(client_id and client_secret and "your_google" not in client_id)

def get_google_auth_url(state: str = "login") -> str | None:
    """
    Generates the Google OAuth 2.0 authorization URL.
    Returns None if client credentials are not configured.
    """
    if not is_google_oauth_configured():
        return None

    client_id = getattr(Config, "GOOGLE_CLIENT_ID", None) or os.getenv("GOOGLE_CLIENT_ID", "")
    redirect_uri = getattr(Config, "GOOGLE_REDIRECT_URI", None) or os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:5000/auth/google/callback")

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "access_type": "offline",
        "prompt": "select_account",
        "state": state
    }
    return f"{GOOGLE_AUTH_ENDPOINT}?{urllib.parse.urlencode(params)}"

def handle_google_callback(code: str) -> dict:
    """
    Exchanges authorization code for access tokens, fetches Google profile,
    and creates or updates the user in SQLite database.
    """
    if not is_google_oauth_configured():
        return {
            "success": False,
            "message": "Google OAuth is not configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file."
        }

    client_id = getattr(Config, "GOOGLE_CLIENT_ID", None) or os.getenv("GOOGLE_CLIENT_ID", "")
    client_secret = getattr(Config, "GOOGLE_CLIENT_SECRET", None) or os.getenv("GOOGLE_CLIENT_SECRET", "")
    redirect_uri = getattr(Config, "GOOGLE_REDIRECT_URI", None) or os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:5000/auth/google/callback")

    # Step 1: Exchange code for token
    token_payload = {
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": redirect_uri,
        "grant_type": "authorization_code"
    }

    try:
        token_resp = requests.post(GOOGLE_TOKEN_ENDPOINT, data=token_payload, timeout=10)
        if token_resp.status_code != 200:
            return {
                "success": False,
                "message": f"Failed to exchange Google OAuth code: {token_resp.text}"
            }
        token_data = token_resp.json()
        access_token = token_data.get("access_token")
    except Exception as e:
        return {"success": False, "message": f"Error connecting to Google OAuth token endpoint: {str(e)}"}

    # Step 2: Fetch user profile info
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        userinfo_resp = requests.get(GOOGLE_USERINFO_ENDPOINT, headers=headers, timeout=10)
        if userinfo_resp.status_code != 200:
            return {"success": False, "message": "Failed to fetch user info from Google."}
        google_profile = userinfo_resp.json()
    except Exception as e:
        return {"success": False, "message": f"Error fetching Google profile: {str(e)}"}

    google_id = google_profile.get("id")
    email = (google_profile.get("email") or "").lower().strip()
    full_name = google_profile.get("name") or "Google User"
    picture = google_profile.get("picture") or ""

    if not email:
        return {"success": False, "message": "No email address provided by Google account."}

    # Step 3: Upsert into database
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email = ? OR google_id = ?", (email, google_id))
        user = cursor.fetchone()

        now = datetime.utcnow().isoformat()
        if user:
            # Update existing user
            cursor.execute(
                """
                UPDATE users
                SET google_id = ?, avatar_url = COALESCE(NULLIF(avatar_url, ''), ?),
                    last_login_at = ?, updated_at = ?
                WHERE id = ?
                """,
                (google_id, picture, now, now, user["id"])
            )
            user_id = user["id"]
            user_role = user["role"]
            preferred_lang = user["preferred_language"] or "en"
        else:
            # Insert new user with Google auth
            cursor.execute(
                """
                INSERT INTO users (
                    full_name, email, password_hash, auth_provider, google_id,
                    avatar_url, role, preferred_language, is_active, created_at, updated_at, last_login_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
                """,
                (
                    full_name, email, "OAUTH_GOOGLE_NO_PASSWORD", "GOOGLE", google_id,
                    picture, "USER", "en", now, now, now
                )
            )
            user_id = cursor.lastrowid
            user_role = "USER"
            preferred_lang = "en"

            # Create default notification preferences
            cursor.execute(
                """
                INSERT OR IGNORE INTO notification_preferences (
                    user_id, in_app_enabled, email_enabled, sms_enabled, whatsapp_enabled,
                    frequency, notify_internships, notify_scholarships, notify_events,
                    deadline_reminders, updated_at
                )
                VALUES (?, 1, 1, 0, 0, 'IMMEDIATE', 1, 1, 1, 1, ?)
                """,
                (user_id, now)
            )

        conn.commit()

        return {
            "success": True,
            "user": {
                "id": user_id,
                "email": email,
                "full_name": full_name,
                "role": user_role,
                "avatar_url": picture,
                "preferred_language": preferred_lang
            }
        }
    finally:
        conn.close()
