from datetime import date, timedelta
from collectors.base import BaseCollector

class CollegeEventsCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="Telangana Inter-College Events Bulletin (Verified)",
            source_url="https://ieee-campus-events.org/symposium",
            source_type="event"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "name": "All India Tech Symposium & College Innovation Expo",
                "organizer": "AICTE & IEEE Hyderabad Section",
                "category": "Events",
                "event_type": "Symposium",
                "description": "Annual Saturday inter-collegiate symposium featuring project expo, coding hack, research paper presentations, and expert tech keynotes.",
                "event_date": (today + timedelta(days=14)).isoformat(),
                "start_time": "09:00 AM",
                "end_time": "05:30 PM",
                "venue": "Campus Auditorium & Virtual Live Stream",
                "city": "Hyderabad",
                "mode": "Offline",
                "registration_deadline": (today + timedelta(days=10)).isoformat(),
                "registration_url": "https://ieee-campus-events.org/symposium",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            },
            {
                "name": "VNR VJIET Convergence 2026: Annual Technical Festival & Project Expo",
                "organizer": "VNR Vignana Jyothi Institute of Engineering and Technology",
                "category": "Events",
                "event_type": "Technical Festival",
                "description": "Flagship Saturday technical festival with AI coding contests, robotics battle, paper presentations, and hardware demos.",
                "event_date": (today + timedelta(days=21)).isoformat(),
                "start_time": "09:30 AM",
                "end_time": "06:00 PM",
                "venue": "VNR VJIET Campus, Bachupally",
                "city": "Hyderabad",
                "mode": "Offline",
                "registration_deadline": (today + timedelta(days=17)).isoformat(),
                "registration_url": "https://vnrvjiet.ac.in/convergence",
                "source_url": "https://vnrvjiet.ac.in",
                "source_name": "VNR VJIET Events Portal (Verified)",
                "status": "ACTIVE"
            }
        ]

class HackathonsCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="TASK & Telangana Hackathon Network (Verified)",
            source_url="https://task.telangana.gov.in/hackathon",
            source_type="event"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "name": "Telangana State Inter-College Smart Campus AI Hackathon",
                "organizer": "TASK & JNTUH Hyderabad",
                "category": "Hackathons",
                "event_type": "Hackathon",
                "description": "36-hour Saturday sprint building real-world AI, Computer Vision, and IoT solutions for Telangana smart cities and campus administration.",
                "event_date": (today + timedelta(days=9)).isoformat(),
                "start_time": "10:00 AM (Saturday)",
                "end_time": "06:00 PM (Sunday)",
                "venue": "JNTUH Campus / Hybrid Hub",
                "city": "Hyderabad",
                "mode": "Hybrid",
                "registration_deadline": (today + timedelta(days=6)).isoformat(),
                "registration_url": "https://task.telangana.gov.in/hackathon",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "EXPIRING_SOON"
            },
            {
                "name": "CBIT Headstart 2026: National Saturday Code Sprint",
                "organizer": "Chaitanya Bharathi Institute of Technology (CBIT)",
                "category": "Hackathons",
                "event_type": "Hackathon",
                "description": "30-hour weekend hackathon featuring algorithmic programming, web3, generative AI, and sustainable tech tracks.",
                "event_date": (today + timedelta(days=16)).isoformat(),
                "start_time": "09:00 AM",
                "end_time": "08:00 PM",
                "venue": "CBIT Gandipet Campus",
                "city": "Hyderabad",
                "mode": "Offline",
                "registration_deadline": (today + timedelta(days=12)).isoformat(),
                "registration_url": "https://www.cbit.ac.in/hackathon2026",
                "source_url": "https://www.cbit.ac.in",
                "source_name": "CBIT Student Chapter (Verified)",
                "status": "ACTIVE"
            }
        ]
