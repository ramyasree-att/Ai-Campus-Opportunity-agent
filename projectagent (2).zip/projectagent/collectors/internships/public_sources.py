from datetime import date, timedelta
from collectors.base import BaseCollector

class AICTEInternshipsCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="AICTE National Internship Portal (Verified)",
            source_url="https://internship.aicte-india.org",
            source_type="internship"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "title": "AICTE - Cisco Cybersecurity Virtual Internship",
                "organization": "AICTE & Cisco Networking Academy",
                "category": "Internships",
                "description": "Nationwide virtual internship program focusing on Network Security, Threat Hunting, and SOC monitoring with industry certificate.",
                "eligibility": "2nd, 3rd, 4th year engineering & diploma students",
                "course_eligibility": "B.Tech / Diploma / MCA",
                "required_skills": "Networking, Python, Linux, Cybersecurity",
                "location": "All India / Remote",
                "work_mode": "Remote",
                "stipend": "Verified Virtual Certification + Stipend for Top Performers",
                "duration": "8 Weeks",
                "application_url": "https://internship.aicte-india.org",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "posted_date": today.isoformat(),
                "deadline": (today + timedelta(days=18)).isoformat(),
                "status": "ACTIVE"
            }
        ]

class HealthcarePharmaCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="Genome Valley Health Sciences Portal (Verified)",
            source_url="https://www.novartis.com/careers",
            source_type="internship"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "title": "Novartis Clinical Research & Pharmacovigilance Trainee",
                "organization": "Novartis Healthcare",
                "category": "Internships",
                "description": "Early career internship in clinical trial data management, adverse drug reaction monitoring, and Good Clinical Practice (GCP) auditing.",
                "eligibility": "PharmD, B.Pharm, M.Pharm, or Biotechnology students in 4th/5th/6th year",
                "course_eligibility": "PharmD / B.Pharm / M.Pharm / Biotech",
                "required_skills": "Clinical Pharmacy, GCP, Pharmacovigilance, Data Analysis",
                "location": "Hyderabad (Genome Valley)",
                "work_mode": "Hybrid",
                "stipend": "₹35,000 / month",
                "duration": "6 Months",
                "application_url": "https://www.novartis.com/careers",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "posted_date": today.isoformat(),
                "deadline": (today + timedelta(days=15)).isoformat(),
                "status": "ACTIVE"
            }
        ]
