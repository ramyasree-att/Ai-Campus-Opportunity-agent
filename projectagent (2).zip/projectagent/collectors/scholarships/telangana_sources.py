from datetime import date, timedelta
from collectors.base import BaseCollector

class TelanganaEPASSCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="Telangana ePASS Portal (Verified)",
            source_url="https://telanganaepass.cgg.gov.in",
            source_type="scholarship"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "name": "Telangana ePASS Post-Matric Scholarship & Fee Reimbursement (RTF & MTF) 2026",
                "provider": "Government of Telangana Welfare Departments",
                "category": "Scholarships",
                "description": "State government scheme providing 100% college tuition fee reimbursement (RTF) and monthly maintenance stipend (MTF) for SC, ST, BC, EBC, Minority, and PwD engineering students.",
                "eligibility": "Telangana domicile undergraduate B.Tech / Pharmacy students with parental annual income < ₹2 Lakh (Rural) or < ₹2.5 Lakh (Urban)",
                "course_eligibility": "B.Tech / PharmD / B.Pharm / M.Tech",
                "year_eligibility": "1st, 2nd, 3rd, 4th, 5th, 6th Year",
                "income_criteria": "Parental income < ₹2,00,000 / year",
                "amount": "100% Tuition Fee Reimbursement + ₹12,000/yr MTF",
                "application_start_date": (today - timedelta(days=30)).isoformat(),
                "deadline": (today + timedelta(days=28)).isoformat(),
                "application_url": "https://telanganaepass.cgg.gov.in",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            },
            {
                "name": "Mahatma Jyothiba Phule BC Overseas Vidya Nidhi Scheme 2026",
                "provider": "Telangana Backward Classes Welfare Department",
                "category": "Scholarships",
                "description": "Financial grant for Telangana BC and EBC undergraduate graduates pursuing higher studies in top 200 QS/Times ranked global universities.",
                "eligibility": "Telangana BC/EBC graduates with minimum 60% marks in B.Tech / Degree",
                "course_eligibility": "Graduate / Final Year B.Tech",
                "year_eligibility": "Final Year / Passed Out",
                "income_criteria": "Parental income < ₹5,00,000 / year",
                "amount": "₹20,00,000 Scholarship Grant + Economy Airfare",
                "application_start_date": (today - timedelta(days=15)).isoformat(),
                "deadline": (today + timedelta(days=40)).isoformat(),
                "application_url": "https://telanganaepass.cgg.gov.in/OverseasLinks.do",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            },
            {
                "name": "Dr. B.R. Ambedkar Overseas Vidya Nidhi for SC/ST Students 2026",
                "provider": "Telangana Scheduled Castes Development Department",
                "category": "Scholarships",
                "description": "Foreign higher education scholarship for deserving Telangana SC and ST engineering students securing admission in USA, UK, Australia, Canada, or Germany.",
                "eligibility": "SC / ST Engineering & Science graduates of Telangana State with valid offer letter",
                "course_eligibility": "B.Tech / Science Graduate",
                "year_eligibility": "Final Year / Graduates",
                "income_criteria": "Parental income < ₹5,00,000 / year",
                "amount": "₹20,00,000 Grant",
                "application_start_date": (today - timedelta(days=20)).isoformat(),
                "deadline": (today + timedelta(days=35)).isoformat(),
                "application_url": "https://telanganaepass.cgg.gov.in",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            }
        ]

class VidyadhanTelanganaCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="Sarojini Damodaran Vidyadhan Foundation (Verified)",
            source_url="https://www.vidyadhan.org",
            source_type="scholarship"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "name": "Vidyadhan Scholarship Telangana Chapter 2026",
                "provider": "Sarojini Damodaran Foundation",
                "category": "Scholarships",
                "description": "Merit-based financial sponsorship for economically challenged meritorious engineering students across all 33 Telangana districts.",
                "eligibility": "1st and 2nd year B.Tech students with >= 85% in Intermediate / 10th and family income < ₹2,00,000",
                "course_eligibility": "B.Tech / Medicine / Pharmacy",
                "year_eligibility": "1st & 2nd Year",
                "income_criteria": "Family annual income < ₹2,00,000",
                "amount": "₹60,000 to ₹75,000 / year",
                "application_start_date": (today - timedelta(days=10)).isoformat(),
                "deadline": (today + timedelta(days=16)).isoformat(),
                "application_url": "https://www.vidyadhan.org/apply",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            }
        ]
