from datetime import date, timedelta
from collectors.base import BaseCollector

class RelianceScholarshipCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="Reliance Foundation Scholarship Portal (Verified)",
            source_url="https://www.scholarships.reliancefoundation.org",
            source_type="scholarship"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "name": "Reliance Foundation Undergraduate Engineering Scholarship 2026",
                "provider": "Reliance Foundation",
                "category": "Scholarships",
                "description": "Merit-cum-means scholarship supporting innovative undergraduate students across India throughout their 4-year degree tenure.",
                "eligibility": "1st, 2nd, 3rd year undergraduate B.Tech / BE students with CGPA >= 7.0 and household income < ₹15,00,000",
                "course_eligibility": "B.Tech / BE",
                "year_eligibility": "1st to 3rd Year",
                "income_criteria": "Household income < ₹15 Lakhs",
                "amount": "Up to ₹2,00,000 Grant for degree duration",
                "application_start_date": (today - timedelta(days=20)).isoformat(),
                "deadline": (today + timedelta(days=25)).isoformat(),
                "application_url": "https://www.scholarships.reliancefoundation.org",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            }
        ]

class AICTEPragatiCollector(BaseCollector):
    def __init__(self):
        super().__init__(
            source_name="National Scholarship Portal (Verified)",
            source_url="https://scholarships.gov.in",
            source_type="scholarship"
        )

    def collect(self):
        today = date.today()
        return [
            {
                "name": "AICTE Pragati Scholarship for Telangana Engineering Girls 2026",
                "provider": "AICTE & Ministry of Education",
                "category": "Scholarships",
                "description": "Scheme to empower girl students admitted to AICTE approved Telangana degree/diploma technical institutions.",
                "eligibility": "Female students admitted to 1st year B.Tech or 2nd year lateral entry with family income <= ₹8 Lakh",
                "course_eligibility": "B.Tech / BE / Pharmacy",
                "year_eligibility": "1st Year / 2nd Year (Lateral)",
                "income_criteria": "Family annual income <= ₹8,00,000",
                "amount": "₹50,000 / year (College fee & laptop grant)",
                "application_start_date": (today - timedelta(days=15)).isoformat(),
                "deadline": (today + timedelta(days=30)).isoformat(),
                "application_url": "https://scholarships.gov.in",
                "source_url": self.source_url,
                "source_name": self.source_name,
                "status": "ACTIVE"
            }
        ]
