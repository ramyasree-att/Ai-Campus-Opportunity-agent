import time
import logging
from abc import ABC, abstractmethod
from datetime import datetime, date, timedelta
import requests
from bs4 import BeautifulSoup

logger = logging.getLogger("CampusAgentCollectors")

class BaseCollector(ABC):
    """
    Abstract Base Collector for ethically gathering public opportunities,
    scholarships, and college events without bypassing security restrictions.
    """
    def __init__(self, source_name, source_url, source_type="internship"):
        self.source_name = source_name
        self.source_url = source_url
        self.source_type = source_type
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) CampusOpportunityAgent/2.0 (Ethical Career Crawler; contact@campusagent.org)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
        }

    def fetch_page(self, url=None, timeout=5):
        """Safely fetches a web page with timeout."""
        target = url or self.source_url
        try:
            resp = requests.get(target, headers=self.headers, timeout=timeout)
            if resp.status_code == 200:
                return resp.text
            else:
                logger.warning(f"Collector {self.source_name} received HTTP {resp.status_code} from {target}")
                return None
        except Exception as e:
            logger.error(f"Collector {self.source_name} network error: {e}")
            return None

    @abstractmethod
    def collect(self):
        """
        Subclasses must implement this method to return a list of standardized dictionaries:
        [{
            'title': ...,
            'organization': ...,
            'description': ...,
            'eligibility': ...,
            'required_skills': ...,
            'location': ...,
            'work_mode': 'Remote' | 'On-site' | 'Hybrid',
            'stipend': ...,
            'application_url': ...,
            'source_url': self.source_url,
            'source_name': self.source_name,
            'deadline': 'YYYY-MM-DD',
            'posted_date': 'YYYY-MM-DD',
            'status': 'ACTIVE' | 'EXPIRING_SOON' | 'EXPIRED' | 'UNVERIFIED'
        }]
        """
        pass
