import time
import logging
from datetime import datetime
from database.db import get_db_connection
from automation.deduplication import generate_event_hash
from collectors.events.college_events import CollegeEventsCollector, HackathonsCollector

logger = logging.getLogger("EventCollector")

def run_event_collector():
    """
    Executes all college event and hackathon collectors, deduplicates records,
    and saves them in the events and opportunities tables.
    """
    start_time = time.time()
    collectors = [
        CollegeEventsCollector(),
        HackathonsCollector()
    ]

    total_found = 0
    total_added = 0
    total_updated = 0
    errors = []

    conn = get_db_connection()
    cursor = conn.cursor()

    for collector in collectors:
        try:
            items = collector.collect()
            total_found += len(items)

            for item in items:
                item_hash = generate_event_hash(
                    item["name"], item["organizer"], item["event_date"], item["source_url"]
                )

                cursor.execute("SELECT id FROM events WHERE hash = ?", (item_hash,))
                existing_ev = cursor.fetchone()

                if not existing_ev:
                    cursor.execute("""
                    INSERT INTO events (
                        name, organizer, description, event_type, event_date,
                        start_time, end_time, venue, city, mode,
                        registration_deadline, registration_url, source_url,
                        source_name, status, last_verified_at, hash
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
                    """, (
                        item["name"], item["organizer"], item["description"], item.get("event_type", "Event"),
                        item["event_date"], item.get("start_time"), item.get("end_time"), item.get("venue"),
                        item.get("city", "Hyderabad"), item.get("mode", "Offline"),
                        item.get("registration_deadline"), item["registration_url"], item["source_url"],
                        item["source_name"], item.get("status", "ACTIVE"), item_hash
                    ))
                    total_added += 1
                else:
                    cursor.execute("""
                    UPDATE events
                    SET last_verified_at = CURRENT_TIMESTAMP, status = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, (item.get("status", "ACTIVE"), existing_ev["id"]))
                    total_updated += 1

                # Sync to unified opportunities table under 'Events' or 'Hackathons'
                cat = item.get("category", "Hackathons" if "hack" in item["name"].lower() else "Events")
                cursor.execute("SELECT id FROM opportunities WHERE title = ? AND organization = ?", (item["name"], item["organizer"]))
                existing_opp = cursor.fetchone()
                if not existing_opp:
                    cursor.execute("""
                    INSERT INTO opportunities (
                        title, organization, category, description, eligibility,
                        required_skills, location, mode, deadline, stipend_or_reward,
                        application_url, source, verification_status, status, is_expired, crawled_at
                    ) VALUES (?, ?, ?, ?, 'Open to all college students', 'Problem Solving, Coding, Teamwork', ?, ?, ?, 'Prizes & Certificates', ?, ?, 'Verified ✅', ?, 0, CURRENT_TIMESTAMP)
                    """, (
                        item["name"], item["organizer"], cat, item["description"],
                        item.get("city", "Hyderabad"), item.get("mode", "Offline"),
                        item.get("registration_deadline"), item["registration_url"],
                        item["source_name"], item.get("status", "ACTIVE")
                    ))
                else:
                    cursor.execute("""
                    UPDATE opportunities
                    SET deadline = ?, status = ?, verification_status = 'Verified ✅', updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, (item.get("registration_deadline"), item.get("status", "ACTIVE"), existing_opp["id"]))

        except Exception as e:
            err_msg = f"Event Collector {collector.source_name} failed: {e}"
            logger.error(err_msg)
            errors.append(err_msg)

    duration = round(time.time() - start_time, 2)
    status = "SUCCESS" if not errors else "PARTIAL"

    cursor.execute("""
    INSERT INTO automation_logs (
        collector_name, status, items_found, items_added, items_updated, error_message, duration_seconds, finished_at
    ) VALUES ('EventCollector', ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (status, total_found, total_added, total_updated, "; ".join(errors) if errors else None, duration))

    conn.commit()
    conn.close()

    return {
        "collector": "EventCollector",
        "status": status,
        "items_found": total_found,
        "items_added": total_added,
        "items_updated": total_updated,
        "duration_seconds": duration,
        "errors": errors
    }
