import time
import logging
from datetime import datetime
from database.db import get_db_connection
from automation.deduplication import generate_opportunity_hash
from collectors.scholarships.telangana_sources import TelanganaEPASSCollector, VidyadhanTelanganaCollector
from collectors.scholarships.national_sources import RelianceScholarshipCollector, AICTEPragatiCollector

logger = logging.getLogger("ScholarshipCollector")

def run_scholarship_collector():
    """
    Executes all scholarship collectors, deduplicates records via SHA-256 hash,
    and updates database records & logs.
    """
    start_time = time.time()
    collectors = [
        TelanganaEPASSCollector(),
        VidyadhanTelanganaCollector(),
        RelianceScholarshipCollector(),
        AICTEPragatiCollector()
    ]

    total_found = 0
    total_added = 0
    total_updated = 0
    errors = []

    conn = get_db_connection()
    cursor = conn.cursor()

    for collector in collectors:
        try:
            items = collector.collect()
            total_found += len(items)

            for item in items:
                item_hash = generate_opportunity_hash(
                    item["name"], item["provider"], item["deadline"], item["source_url"]
                )

                cursor.execute("SELECT id FROM scholarships WHERE hash = ?", (item_hash,))
                existing_sch = cursor.fetchone()

                if not existing_sch:
                    cursor.execute("""
                    INSERT INTO scholarships (
                        name, provider, description, eligibility, course_eligibility,
                        year_eligibility, income_criteria, amount, application_start_date,
                        deadline, application_url, source_url, source_name, status,
                        last_verified_at, hash
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
                    """, (
                        item["name"], item["provider"], item["description"], item.get("eligibility"),
                        item.get("course_eligibility"), item.get("year_eligibility"), item.get("income_criteria"),
                        item.get("amount"), item.get("application_start_date"), item.get("deadline"),
                        item["application_url"], item["source_url"], item["source_name"],
                        item.get("status", "ACTIVE"), item_hash
                    ))
                    total_added += 1
                else:
                    cursor.execute("""
                    UPDATE scholarships
                    SET last_verified_at = CURRENT_TIMESTAMP, status = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, (item.get("status", "ACTIVE"), existing_sch["id"]))
                    total_updated += 1

                # Sync to unified opportunities table
                cursor.execute("SELECT id FROM opportunities WHERE title = ? AND organization = ?", (item["name"], item["provider"]))
                existing_opp = cursor.fetchone()
                if not existing_opp:
                    cursor.execute("""
                    INSERT INTO opportunities (
                        title, organization, category, description, eligibility,
                        required_skills, location, mode, deadline, stipend_or_reward,
                        application_url, source, verification_status, status, is_expired, crawled_at
                    ) VALUES (?, ?, 'Scholarships', ?, ?, 'Academic Merit, Regularity', 'Telangana / All India', 'Online', ?, ?, ?, ?, 'Verified ✅', ?, 0, CURRENT_TIMESTAMP)
                    """, (
                        item["name"], item["provider"], item["description"], item.get("eligibility"),
                        item.get("deadline"), item.get("amount"), item["application_url"],
                        item["source_name"], item.get("status", "ACTIVE")
                    ))
                else:
                    cursor.execute("""
                    UPDATE opportunities
                    SET deadline = ?, status = ?, verification_status = 'Verified ✅', updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, (item.get("deadline"), item.get("status", "ACTIVE"), existing_opp["id"]))

        except Exception as e:
            err_msg = f"Scholarship Collector {collector.source_name} failed: {e}"
            logger.error(err_msg)
            errors.append(err_msg)

    duration = round(time.time() - start_time, 2)
    status = "SUCCESS" if not errors else "PARTIAL"

    cursor.execute("""
    INSERT INTO automation_logs (
        collector_name, status, items_found, items_added, items_updated, error_message, duration_seconds, finished_at
    ) VALUES ('ScholarshipCollector', ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (status, total_found, total_added, total_updated, "; ".join(errors) if errors else None, duration))

    conn.commit()
    conn.close()

    return {
        "collector": "ScholarshipCollector",
        "status": status,
        "items_found": total_found,
        "items_added": total_added,
        "items_updated": total_updated,
        "duration_seconds": duration,
        "errors": errors
    }
