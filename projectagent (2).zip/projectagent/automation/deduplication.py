import hashlib
import re

def normalize_text(text):
    """Normalizes string for robust fingerprint generation."""
    if not text:
        return ""
    # Lowercase and remove punctuation/multiple whitespace
    clean = re.sub(r"[^\w\s]", "", str(text).lower())
    return re.sub(r"\s+", " ", clean).strip()

def generate_opportunity_hash(title, organization, deadline, source_url):
    """
    Generates a deterministic SHA-256 fingerprint for deduplication.
    Prevents duplicate entries across multiple web scrapers.
    """
    norm_title = normalize_text(title)
    norm_org = normalize_text(organization)
    norm_deadline = str(deadline or "").strip()
    norm_url = str(source_url or "").strip().lower().rstrip("/")
    
    unique_string = f"{norm_title}|{norm_org}|{norm_deadline}|{norm_url}"
    return hashlib.sha256(unique_string.encode("utf-8")).hexdigest()

def generate_event_hash(event_name, organizer, event_date, source_url):
    """Generates a SHA-256 fingerprint for college events."""
    norm_name = normalize_text(event_name)
    norm_org = normalize_text(organizer)
    norm_date = str(event_date or "").strip()
    norm_url = str(source_url or "").strip().lower().rstrip("/")
    
    unique_string = f"{norm_name}|{norm_org}|{norm_date}|{norm_url}"
    return hashlib.sha256(unique_string.encode("utf-8")).hexdigest()

def generate_notification_fingerprint(user_id, title, target_id):
    """Generates fingerprint to prevent duplicate notifications to the same user."""
    norm_title = normalize_text(title)
    unique_string = f"notif_{user_id}_{norm_title}_{target_id}"
    return hashlib.sha256(unique_string.encode("utf-8")).hexdigest()
