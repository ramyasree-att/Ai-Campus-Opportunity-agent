import time
import logging
from datetime import datetime
from database.db import get_db_connection
from automation.deduplication import generate_opportunity_hash
from collectors.internships.company_sources import (
    GoogleUniversityCollector, MicrosoftUniversityCollector, AmazonScienceCollector, InfosysInStepCollector
)
from collectors.internships.public_sources import AICTEInternshipsCollector, HealthcarePharmaCollector

logger = logging.getLogger("InternshipCollector")

def run_internship_collector():
    """
    Executes all registered internship collectors, deduplicates records via SHA-256 hash,
    updates last_verified_at timestamps, and logs results in automation_logs.
    """
    start_time = time.time()
    collectors = [
        GoogleUniversityCollector(),
        MicrosoftUniversityCollector(),
        AmazonScienceCollector(),
        InfosysInStepCollector(),
        AICTEInternshipsCollector(),
        HealthcarePharmaCollector()
    ]

    total_found = 0
    total_added = 0
    total_updated = 0
    errors = []

    conn = get_db_connection()
    cursor = conn.cursor()

    for collector in collectors:
        try:
            items = collector.collect()
            total_found += len(items)

            for item in items:
                item_hash = generate_opportunity_hash(
                    item["title"], item["organization"], item["deadline"], item["source_url"]
                )

                # Check in specialized internships table
                cursor.execute("SELECT id FROM internships WHERE hash = ?", (item_hash,))
                existing_internship = cursor.fetchone()

                if not existing_internship:
                    cursor.execute("""
                    INSERT INTO internships (
                        title, company, description, eligibility, skills,
                        course_eligibility, location, work_mode, stipend, duration,
                        application_url, source_url, source_name, posted_date,
                        deadline, status, last_verified_at, hash
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
                    """, (
                        item["title"], item["organization"], item["description"], item.get("eligibility"),
                        item.get("required_skills"), item.get("course_eligibility"), item.get("location"),
                        item.get("work_mode", "Remote"), item.get("stipend"), item.get("duration"),
                        item["application_url"], item["source_url"], item["source_name"],
                        item.get("posted_date"), item.get("deadline"), item.get("status", "ACTIVE"),
                        item_hash
                    ))
                    total_added += 1
                else:
                    cursor.execute("""
                    UPDATE internships
                    SET last_verified_at = CURRENT_TIMESTAMP, status = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, (item.get("status", "ACTIVE"), existing_internship["id"]))
                    total_updated += 1

                # Synchronize to unified opportunities table for unified UI views
                cursor.execute("SELECT id FROM opportunities WHERE title = ? AND organization = ?", (item["title"], item["organization"]))
                existing_opp = cursor.fetchone()
                if not existing_opp:
                    cursor.execute("""
                    INSERT INTO opportunities (
                        title, organization, category, description, eligibility,
                        required_skills, location, mode, deadline, stipend_or_reward,
                        application_url, source, verification_status, status, is_expired, crawled_at
                    ) VALUES (?, ?, 'Internships', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Verified ✅', ?, 0, CURRENT_TIMESTAMP)
                    """, (
                        item["title"], item["organization"], item["description"], item.get("eligibility"),
                        item.get("required_skills"), item.get("location"), item.get("work_mode", "Online"),
                        item.get("deadline"), item.get("stipend"), item["application_url"],
                        item["source_name"], item.get("status", "ACTIVE")
                    ))
                else:
                    cursor.execute("""
                    UPDATE opportunities
                    SET deadline = ?, status = ?, verification_status = 'Verified ✅', updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """, (item.get("deadline"), item.get("status", "ACTIVE"), existing_opp["id"]))

        except Exception as e:
            err_msg = f"Collector {collector.source_name} failed: {e}"
            logger.error(err_msg)
            errors.append(err_msg)

    duration = round(time.time() - start_time, 2)
    status = "SUCCESS" if not errors else ("PARTIAL" if total_found > 0 else "FAILED")

    # Record in automation_logs
    cursor.execute("""
    INSERT INTO automation_logs (
        collector_name, status, items_found, items_added, items_updated, error_message, duration_seconds, finished_at
    ) VALUES ('InternshipCollector', ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (status, total_found, total_added, total_updated, "; ".join(errors) if errors else None, duration))

    conn.commit()
    conn.close()

    return {
        "collector": "InternshipCollector",
        "status": status,
        "items_found": total_found,
        "items_added": total_added,
        "items_updated": total_updated,
        "duration_seconds": duration,
        "errors": errors
    }
