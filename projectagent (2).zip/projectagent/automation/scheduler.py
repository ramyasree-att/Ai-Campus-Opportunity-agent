import time
import logging
from datetime import datetime
from config import Config
from automation.internship_collector import run_internship_collector
from automation.scholarship_collector import run_scholarship_collector
from automation.event_collector import run_event_collector
from automation.deadline_checker import run_deadline_checker
from database.db import get_db_connection

logger = logging.getLogger("CampusScheduler")

SCHEDULER_INSTANCE = None
SCHEDULER_STATUS = {
    "is_running": False,
    "last_full_cycle": None,
    "jobs": {}
}

def get_admin_setting_int(key, default_val):
    """Retrieves dynamic scheduler interval from SQLite admin_settings table."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT setting_value FROM admin_settings WHERE setting_key = ?", (key,))
        row = cursor.fetchone()
        conn.close()
        if row and row["setting_value"]:
            return int(row["setting_value"])
    except Exception:
        pass
    return default_val

def scheduled_internship_job():
    logger.info("Scheduler: Running automated internship scan...")
    res = run_internship_collector()
    SCHEDULER_STATUS["jobs"]["internships"] = {"last_run": datetime.now().isoformat(), "result": res}

def scheduled_scholarship_job():
    logger.info("Scheduler: Running automated scholarship scan...")
    res = run_scholarship_collector()
    SCHEDULER_STATUS["jobs"]["scholarships"] = {"last_run": datetime.now().isoformat(), "result": res}

def scheduled_event_job():
    logger.info("Scheduler: Running automated college events scan...")
    res = run_event_collector()
    SCHEDULER_STATUS["jobs"]["events"] = {"last_run": datetime.now().isoformat(), "result": res}

def scheduled_deadline_job():
    logger.info("Scheduler: Running automated deadline expiration check...")
    res = run_deadline_checker()
    SCHEDULER_STATUS["jobs"]["deadlines"] = {"last_run": datetime.now().isoformat(), "result": res}

def run_full_automation_cycle():
    """Runs a complete automation cycle immediately (can be triggered by admin or startup)."""
    SCHEDULER_STATUS["is_running"] = True
    start = time.time()
    
    int_res = run_internship_collector()
    sch_res = run_scholarship_collector()
    ev_res = run_event_collector()
    dl_res = run_deadline_checker()
    
    SCHEDULER_STATUS["last_full_cycle"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    SCHEDULER_STATUS["is_running"] = False
    
    return {
        "internships": int_res,
        "scholarships": sch_res,
        "events": ev_res,
        "deadlines": dl_res,
        "duration_seconds": round(time.time() - start, 2),
        "timestamp": SCHEDULER_STATUS["last_full_cycle"]
    }

def start_background_scheduler():
    """
    Initializes and starts APScheduler in the background.
    Runs completely independently of whether users are active on the website.
    """
    global SCHEDULER_INSTANCE
    if SCHEDULER_INSTANCE and SCHEDULER_INSTANCE.running:
        return SCHEDULER_INSTANCE

    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        
        scheduler = BackgroundScheduler(daemon=True)
        
        internship_hours = get_admin_setting_int("internship_scan_interval_hours", Config.INTERNSHIP_SCAN_HOURS)
        scholarship_hours = get_admin_setting_int("scholarship_scan_interval_hours", Config.SCHOLARSHIP_SCAN_HOURS)
        event_hours = get_admin_setting_int("event_scan_interval_hours", Config.EVENT_SCAN_HOURS)
        deadline_hours = get_admin_setting_int("deadline_check_interval_hours", Config.DEADLINE_CHECK_HOURS)
        
        scheduler.add_job(scheduled_internship_job, 'interval', hours=internship_hours, id='job_internships')
        scheduler.add_job(scheduled_scholarship_job, 'interval', hours=scholarship_hours, id='job_scholarships')
        scheduler.add_job(scheduled_event_job, 'interval', hours=event_hours, id='job_events')
        scheduler.add_job(scheduled_deadline_job, 'interval', hours=deadline_hours, id='job_deadlines')
        
        scheduler.start()
        SCHEDULER_INSTANCE = scheduler
        SCHEDULER_STATUS["is_running"] = True
        logger.info("APScheduler background engine started successfully.")
        return scheduler
    except Exception as e:
        logger.error(f"Failed to start APScheduler: {e}")
        return None

# Aliases for compatibility
init_scheduler = start_background_scheduler
run_all_collectors_cycle = run_full_automation_cycle


def get_scheduler_status():
    return SCHEDULER_STATUS
