import time
import logging
from datetime import date, timedelta
from database.db import get_db_connection

logger = logging.getLogger("DeadlineChecker")

def run_deadline_checker(warning_days=5):
    """
    Automated Deadline Checker:
    Evaluates all internships, scholarships, events, and opportunities against current datetime.
    Transitions statuses:
      - deadline < today: EXPIRED (is_expired = 1)
      - today <= deadline <= today + warning_days: EXPIRING_SOON (is_expired = 0)
      - deadline > today + warning_days: ACTIVE (is_expired = 0)
    Never deletes historical records.
    """
    start_time = time.time()
    today = date.today()
    today_str = today.isoformat()
    warning_cutoff_str = (today + timedelta(days=warning_days)).isoformat()

    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Update Unified Opportunities Table
    # A. Expired
    cursor.execute("""
    UPDATE opportunities
    SET status = 'EXPIRED', is_expired = 1, verification_status = 'Deadline Passed ❌', updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline < ? AND status != 'EXPIRED'
    """, (today_str,))
    opps_expired = cursor.rowcount

    # B. Expiring Soon
    cursor.execute("""
    UPDATE opportunities
    SET status = 'EXPIRING_SOON', is_expired = 0, updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline >= ? AND deadline <= ? AND status NOT IN ('EXPIRED', 'CLOSED')
    """, (today_str, warning_cutoff_str))
    opps_expiring_soon = cursor.rowcount

    # C. Active
    cursor.execute("""
    UPDATE opportunities
    SET status = 'ACTIVE', is_expired = 0, updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline > ? AND status NOT IN ('CLOSED', 'UNVERIFIED')
    """, (warning_cutoff_str,))
    opps_active = cursor.rowcount

    # 2. Update Specialized Internships Table
    cursor.execute("""
    UPDATE internships
    SET status = 'EXPIRED', updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline < ? AND status != 'EXPIRED'
    """, (today_str,))

    cursor.execute("""
    UPDATE internships
    SET status = 'EXPIRING_SOON', updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline >= ? AND deadline <= ? AND status NOT IN ('EXPIRED', 'CLOSED')
    """, (today_str, warning_cutoff_str))

    # 3. Update Specialized Scholarships Table
    cursor.execute("""
    UPDATE scholarships
    SET status = 'EXPIRED', updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline < ? AND status != 'EXPIRED'
    """, (today_str,))

    cursor.execute("""
    UPDATE scholarships
    SET status = 'EXPIRING_SOON', updated_at = CURRENT_TIMESTAMP
    WHERE deadline IS NOT NULL AND deadline != '' AND deadline >= ? AND deadline <= ? AND status NOT IN ('EXPIRED', 'CLOSED')
    """, (today_str, warning_cutoff_str))

    # 4. Update Specialized Events Table
    cursor.execute("""
    UPDATE events
    SET status = 'EXPIRED', updated_at = CURRENT_TIMESTAMP
    WHERE registration_deadline IS NOT NULL AND registration_deadline != '' AND registration_deadline < ? AND status != 'EXPIRED'
    """, (today_str,))

    cursor.execute("""
    UPDATE events
    SET status = 'EXPIRING_SOON', updated_at = CURRENT_TIMESTAMP
    WHERE registration_deadline IS NOT NULL AND registration_deadline != '' AND registration_deadline >= ? AND registration_deadline <= ? AND status NOT IN ('EXPIRED', 'CLOSED')
    """, (today_str, warning_cutoff_str))

    duration = round(time.time() - start_time, 2)

    # Log in automation_logs
    cursor.execute("""
    INSERT INTO automation_logs (
        collector_name, status, items_found, items_added, items_updated, items_expired, duration_seconds, finished_at
    ) VALUES ('DeadlineChecker', 'SUCCESS', ?, 0, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (opps_active + opps_expiring_soon + opps_expired, opps_expiring_soon, opps_expired, duration))

    conn.commit()
    conn.close()

    return {
        "collector": "DeadlineChecker",
        "status": "SUCCESS",
        "expired_count": opps_expired,
        "expiring_soon_count": opps_expiring_soon,
        "active_count": opps_active,
        "duration_seconds": duration
    }

# Alias for compatibility
update_expired_deadlines = run_deadline_checker
