def run_migrations(cursor):
    """Safely adds new columns to tables if they were created under older schemas."""
    # Check users table
    cursor.execute("PRAGMA table_info(users)")
    user_cols = [row["name"] for row in cursor.fetchall()]
    if "role" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'USER'")
    if "city" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN city TEXT")
    if "state" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN state TEXT DEFAULT 'Telangana'")
    if "auth_provider" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN auth_provider TEXT DEFAULT 'local'")
    if "google_id" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN google_id TEXT")
    if "preferred_language" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN preferred_language TEXT DEFAULT 'en'")
    if "avatar_url" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN avatar_url TEXT")
    if "full_name" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN full_name TEXT")
    if "is_active" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1")
    if "last_login_at" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN last_login_at TIMESTAMP")

    # Check profiles table
    cursor.execute("PRAGMA table_info(profiles)")
    profile_cols = [row["name"] for row in cursor.fetchall()]
    if "college_id" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN college_id INTEGER")
    if "course" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN course TEXT DEFAULT 'B.Tech'")
    if "graduation_year" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN graduation_year TEXT")
    if "city" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN city TEXT")
    if "state" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN state TEXT DEFAULT 'Telangana'")
    if "resume_filename" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN resume_filename TEXT")
    if "resume_summary" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN resume_summary TEXT")
    if "preferred_language" not in profile_cols:
        cursor.execute("ALTER TABLE profiles ADD COLUMN preferred_language TEXT DEFAULT 'en'")

    # Check opportunities table
    cursor.execute("PRAGMA table_info(opportunities)")
    opp_cols = [row["name"] for row in cursor.fetchall()]
    if "status" not in opp_cols:
        cursor.execute("ALTER TABLE opportunities ADD COLUMN status TEXT DEFAULT 'ACTIVE'")
    if "is_expired" not in opp_cols:
        cursor.execute("ALTER TABLE opportunities ADD COLUMN is_expired INTEGER DEFAULT 0")
    if "crawled_at" not in opp_cols:
        cursor.execute("ALTER TABLE opportunities ADD COLUMN crawled_at TIMESTAMP")

    # Check notifications table
    cursor.execute("PRAGMA table_info(notifications)")
    notif_cols = [row["name"] for row in cursor.fetchall()]
    if "fingerprint" not in notif_cols:
        cursor.execute("ALTER TABLE notifications ADD COLUMN fingerprint TEXT")
    if "sent_to_contact" not in notif_cols:
        cursor.execute("ALTER TABLE notifications ADD COLUMN sent_to_contact INTEGER DEFAULT 0")
    if "contact_number" not in notif_cols:
        cursor.execute("ALTER TABLE notifications ADD COLUMN contact_number TEXT")
