import os
import json
from database.db import get_db_connection
from config import Config

def init_db():
    """
    Initializes all SQLite database tables, executes migrations, and seeds initial records.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Users Table (with role: USER / ADMIN)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        contact_number TEXT,
        role TEXT DEFAULT 'USER',
        city TEXT,
        state TEXT DEFAULT 'Telangana',
        auth_provider TEXT DEFAULT 'local',
        google_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # 2. Profiles Table (Complete 15 registration fields)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        name TEXT NOT NULL,
        profile_photo TEXT,
        college_name TEXT,
        college_id INTEGER,
        contact_number TEXT,
        father_name TEXT,
        about_college TEXT,
        course TEXT DEFAULT 'B.Tech',
        branch TEXT,
        academic_year TEXT,
        graduation_year TEXT,
        cgpa REAL,
        city TEXT,
        state TEXT DEFAULT 'Telangana',
        career_goal TEXT,
        interests TEXT,
        preferred_location TEXT,
        preferred_opportunity_type TEXT,
        resume_filename TEXT,
        resume_summary TEXT,
        preferred_language TEXT DEFAULT 'en',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 3. Colleges Table (Extendable by Admin)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS colleges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        code TEXT,
        location TEXT,
        district TEXT,
        state TEXT DEFAULT 'Telangana',
        website_url TEXT,
        placement_portal_url TEXT,
        highest_package_lpa REAL DEFAULT 0.0,
        average_package_lpa REAL DEFAULT 0.0,
        placement_rate_pct INTEGER DEFAULT 0,
        total_offers INTEGER DEFAULT 0,
        top_recruiters_json TEXT,
        nirf_rank TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # 4. Resumes Table (Non-public, secure career asset storage)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS resumes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size_bytes INTEGER,
        parsed_skills_json TEXT,
        education_json TEXT,
        experience_json TEXT,
        projects_json TEXT,
        resume_score INTEGER DEFAULT 80,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_active INTEGER DEFAULT 1,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 5. Internships Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS internships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        description TEXT NOT NULL,
        eligibility TEXT,
        skills TEXT,
        course_eligibility TEXT,
        location TEXT,
        work_mode TEXT DEFAULT 'Remote',
        stipend TEXT,
        duration TEXT,
        application_url TEXT NOT NULL,
        source_url TEXT NOT NULL,
        source_name TEXT NOT NULL,
        posted_date DATE,
        deadline DATE,
        status TEXT DEFAULT 'ACTIVE', -- ACTIVE, EXPIRING_SOON, EXPIRED, CLOSED, UNVERIFIED
        last_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        hash TEXT UNIQUE NOT NULL
    )
    """)

    # 6. Scholarships Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS scholarships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        provider TEXT NOT NULL,
        description TEXT NOT NULL,
        eligibility TEXT,
        course_eligibility TEXT,
        year_eligibility TEXT,
        income_criteria TEXT,
        amount TEXT,
        application_start_date DATE,
        deadline DATE,
        application_url TEXT NOT NULL,
        source_url TEXT NOT NULL,
        source_name TEXT NOT NULL,
        status TEXT DEFAULT 'ACTIVE',
        last_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        hash TEXT UNIQUE NOT NULL
    )
    """)

    # 7. Events & Hackathons Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        organizer TEXT NOT NULL,
        college_id INTEGER,
        description TEXT NOT NULL,
        event_type TEXT DEFAULT 'Hackathon',
        event_date DATE,
        start_time TEXT,
        end_time TEXT,
        venue TEXT,
        city TEXT,
        mode TEXT DEFAULT 'Offline',
        registration_deadline DATE,
        registration_url TEXT NOT NULL,
        source_url TEXT NOT NULL,
        source_name TEXT NOT NULL,
        status TEXT DEFAULT 'ACTIVE',
        last_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        hash TEXT UNIQUE NOT NULL
    )
    """)

    # 8. Unified Opportunities Table (for backward compatibility & unified feeds)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS opportunities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        organization TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        eligibility TEXT,
        required_skills TEXT,
        location TEXT,
        mode TEXT DEFAULT 'Online',
        deadline DATE,
        stipend_or_reward TEXT,
        application_url TEXT NOT NULL,
        source TEXT NOT NULL,
        verification_status TEXT DEFAULT 'Verified ✅',
        status TEXT DEFAULT 'ACTIVE',
        is_expired INTEGER DEFAULT 0,
        crawled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # 9. Skills & Programming Languages Tables
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS skills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profile_id INTEGER NOT NULL,
        skill_name TEXT NOT NULL,
        FOREIGN KEY (profile_id) REFERENCES profiles (id) ON DELETE CASCADE
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS programming_languages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        profile_id INTEGER NOT NULL,
        language_name TEXT NOT NULL,
        FOREIGN KEY (profile_id) REFERENCES profiles (id) ON DELETE CASCADE
    )
    """)

    # 10. Saved Opportunities Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS saved_opportunities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        opportunity_id INTEGER,
        opportunity_type TEXT DEFAULT 'opportunity',
        saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 11. Application Tracking Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        opportunity_id INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'Applied',
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        notes TEXT,
        prepared_data_json TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 12. Notifications Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT DEFAULT 'info',
        fingerprint TEXT,
        is_read INTEGER DEFAULT 0,
        sent_to_contact INTEGER DEFAULT 0,
        contact_number TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 13. Smart Notification Preferences Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notification_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        internships_enabled INTEGER DEFAULT 1,
        scholarships_enabled INTEGER DEFAULT 1,
        events_enabled INTEGER DEFAULT 1,
        deadlines_enabled INTEGER DEFAULT 1,
        learning_enabled INTEGER DEFAULT 1,
        frequency TEXT DEFAULT 'IMMEDIATE', -- IMMEDIATE, DAILY, WEEKLY
        email_enabled INTEGER DEFAULT 1,
        sms_enabled INTEGER DEFAULT 1,
        whatsapp_enabled INTEGER DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 14. Source Registry Table (for Admin & Scraper health)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS source_registry (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_name TEXT UNIQUE NOT NULL,
        source_type TEXT NOT NULL, -- 'internship', 'scholarship', 'event'
        url TEXT NOT NULL,
        adapter_name TEXT NOT NULL,
        is_enabled INTEGER DEFAULT 1,
        scan_frequency_hours INTEGER DEFAULT 6,
        last_scanned_at TIMESTAMP,
        status TEXT DEFAULT 'OK'
    )
    """)

    # 15. Automation Logs Table (for Admin dashboard monitoring)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS automation_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        collector_name TEXT NOT NULL,
        status TEXT NOT NULL, -- 'SUCCESS', 'FAILED', 'RUNNING'
        items_found INTEGER DEFAULT 0,
        items_added INTEGER DEFAULT 0,
        items_updated INTEGER DEFAULT 0,
        items_expired INTEGER DEFAULT 0,
        error_message TEXT,
        duration_seconds REAL DEFAULT 0.0,
        started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        finished_at TIMESTAMP
    )
    """)

    # 16. Admin Settings Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS admin_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        setting_key TEXT UNIQUE NOT NULL,
        setting_value TEXT NOT NULL,
        description TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # 17. Learning Plans Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS learning_plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        skill_name TEXT NOT NULL,
        title TEXT NOT NULL,
        duration_days INTEGER DEFAULT 7,
        plan_json TEXT NOT NULL,
        progress_percentage INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 18. Career Roadmaps Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS career_roadmaps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        career_goal TEXT NOT NULL,
        stages_json TEXT NOT NULL,
        current_stage INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 19. SMS / WhatsApp Dispatch Logs Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sms_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        contact_number TEXT NOT NULL,
        title TEXT,
        message TEXT NOT NULL,
        status TEXT DEFAULT 'DELIVERED',
        gateway TEXT DEFAULT 'Simulated Live SMS / Twilio Gateway',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
    )
    """)

    # 20. Chat History Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        sender TEXT NOT NULL,
        message TEXT NOT NULL,
        language TEXT DEFAULT 'en',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 21. Company Application Dispatches Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS company_application_dispatches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id INTEGER,
        user_id INTEGER NOT NULL,
        opportunity_id INTEGER NOT NULL,
        company_name TEXT NOT NULL,
        dispatch_txn_id TEXT UNIQUE NOT NULL,
        status TEXT DEFAULT 'DISPATCHED',
        payload_json TEXT,
        company_endpoint TEXT,
        dispatched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
    """)

    # 22. College Placements Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS college_placements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        college_name TEXT UNIQUE NOT NULL,
        college_code TEXT,
        website_url TEXT,
        highest_package_lpa REAL,
        average_package_lpa REAL,
        placement_rate_pct INTEGER,
        total_offers INTEGER,
        top_recruiters_json TEXT,
        placement_drives_json TEXT,
        nirf_rank TEXT,
        last_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Run column migrations to ensure existing tables have all columns
    from database.migrations import run_migrations
    run_migrations(cursor)

    conn.commit()
    conn.close()

    # Seed initial opportunities, sources, and colleges
    seed_initial_data()

def seed_initial_data():
    """Seeds default admin, default sources, colleges, and opportunities."""
    from services.college_service import auto_update_daily_placements, TELANGANA_COLLEGES
    from werkzeug.security import generate_password_hash

    conn = get_db_connection()
    cursor = conn.cursor()

    # Seed Admin User if not exists (admin@campusagent.org / Admin@2026)
    cursor.execute("SELECT id FROM users WHERE role = 'ADMIN'")
    if not cursor.fetchone():
        admin_pass_hash = generate_password_hash("Admin@2026")
        cursor.execute("""
        INSERT INTO users (email, password_hash, contact_number, role, city, state)
        VALUES ('admin@campusagent.org', ?, '9876543210', 'ADMIN', 'Hyderabad', 'Telangana')
        """, (admin_pass_hash,))
        admin_id = cursor.lastrowid
        cursor.execute("""
        INSERT INTO profiles (user_id, name, college_name, branch, academic_year, career_goal, preferred_language)
        VALUES (?, 'System Administrator', 'JNTUH CEH', 'CSE', 'Faculty / Admin', 'Campus Administrator', 'en')
        """, (admin_id,))

    # Seed Default Sources in source_registry
    default_sources = [
        ("Google University Hiring", "internship", "https://careers.google.com/students", "google_adapter", 6),
        ("Microsoft Engage Portal", "internship", "https://careers.microsoft.com/students", "microsoft_adapter", 6),
        ("Amazon Science Student Portal", "internship", "https://amazonscience.com", "amazon_adapter", 6),
        ("Infosys InStep Careers", "internship", "https://www.infosys.com/instep", "infosys_adapter", 12),
        ("Telangana ePASS Scholarship Portal", "scholarship", "https://telanganaepass.cgg.gov.in", "ts_epass_adapter", 12),
        ("National Scholarship Portal (NSP)", "scholarship", "https://scholarships.gov.in", "nsp_adapter", 12),
        ("Reliance Foundation Scholarships", "scholarship", "https://www.scholarships.reliancefoundation.org", "reliance_adapter", 12),
        ("Vidyadhan Scholarship Portal", "scholarship", "https://www.vidyadhan.org", "vidyadhan_adapter", 12),
        ("TASK Telangana Events Hub", "event", "https://task.telangana.gov.in", "task_adapter", 6),
        ("IEEE Student Chapter Telangana", "event", "https://ieee-campus-events.org", "ieee_adapter", 6),
        ("CBIT Headstart Hackathon Hub", "event", "https://www.cbit.ac.in", "cbit_adapter", 6),
        ("VNR VJIET Convergence Fest", "event", "https://vnrvjiet.ac.in", "vnr_adapter", 6)
    ]

    for s_name, s_type, s_url, s_adapt, s_freq in default_sources:
        cursor.execute("""
        INSERT OR IGNORE INTO source_registry (source_name, source_type, url, adapter_name, scan_frequency_hours, status)
        VALUES (?, ?, ?, ?, ?, 'OK')
        """, (s_name, s_type, s_url, s_adapt, s_freq))

    # Seed Default Admin Settings
    default_settings = [
        ("internship_scan_interval_hours", "6", "Interval in hours for automated internship collection"),
        ("scholarship_scan_interval_hours", "12", "Interval in hours for automated scholarship collection"),
        ("event_scan_interval_hours", "6", "Interval in hours for automated college events collection"),
        ("deadline_check_interval_hours", "1", "Interval in hours for automated deadline checks"),
        ("deadline_warning_days", "5", "Days threshold to mark an opportunity as EXPIRING_SOON"),
        ("auto_sms_notifications", "true", "Enable or disable automatic SMS dispatch on new matches")
    ]

    for k, v, d in default_settings:
        cursor.execute("""
        INSERT OR IGNORE INTO admin_settings (setting_key, setting_value, description)
        VALUES (?, ?, ?)
        """, (k, v, d))

    # Seed Colleges table from TELANGANA_COLLEGES
    for col in TELANGANA_COLLEGES:
        cursor.execute("""
        INSERT OR IGNORE INTO colleges (
            name, code, location, district, state, website_url, placement_portal_url,
            highest_package_lpa, average_package_lpa, placement_rate_pct, total_offers,
            top_recruiters_json, nirf_rank
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            col["name"],
            col.get("code", ""),
            col.get("location", "Telangana"),
            col.get("district", "Telangana"),
            "Telangana",
            col.get("website_url", ""),
            col.get("placement_portal_url", ""),
            col.get("highest_package_lpa", 0.0),
            col.get("average_package_lpa", 0.0),
            col.get("placement_rate_pct", 0),
            col.get("total_offers", 0),
            json.dumps(col.get("top_recruiters", [])),
            col.get("nirf_rank", "State Tier")
        ))

    conn.commit()
    conn.close()

    try:
        auto_update_daily_placements()
    except Exception:
        pass
