import sqlite3
import os
from pathlib import Path
from config import Config

def get_db_connection():
    """
    Returns a thread-safe SQLite database connection with row factory and foreign keys enabled.
    """
    os.makedirs(Config.DATABASE_PATH.parent, exist_ok=True)
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(Config.RESUMES_FOLDER, exist_ok=True)
    
    conn = sqlite3.connect(Config.DATABASE_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn
